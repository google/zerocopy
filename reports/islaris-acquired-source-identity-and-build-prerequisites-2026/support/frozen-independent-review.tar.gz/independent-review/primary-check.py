import pathlib,json,hashlib,re
P=pathlib.Path(__file__).resolve().parent;E=P.parent;S=E/'sail-proof-design/islaris-source-audit'
def need(b,s):
 if not b:raise ValueError(s)
def sha(b):return hashlib.sha256(b).hexdigest()
x=json.loads((S/'inputs.json').read_text());expected=json.loads((E/'islaris-source-acquisition-20261015/input-file-hashes.json').read_text());roots={}
for name in ['main','overlay']:
 a=json.loads((E/'islaris-source-acquisition-20261015'/('copy-'+name+'.json')).read_text());roots[name]=pathlib.Path(a['argv'][2]).resolve();need(roots[name].is_dir(),'physical metadata root')
for path,want in expected.items():
 root,rel=path.split('/',1);p=roots[root]/rel;need(p.is_file() and sha(p.read_bytes())==want,'physical metadata '+path)
# Compare actual acquired JSON, including allowed duplicate-key behavior, to copied raw.
dups=[]
def hook(pairs):
 d={}
 for k,v in pairs:
  if k in d:need(d[k]==v,'conflicting duplicate key');dups.append(k)
  d[k]=v
 return d
raw=(E/'islaris-source-acquisition-20261015/native-acquire-result.json').read_bytes();need(raw.decode()==x['native_acquire_raw'],'acquisition raw bytes copied')
r=json.loads(raw,object_pairs_hook=hook);selected=[(v['install']['name'],v['install']['version']) for v in r['solution']];need(len(selected)==74 and len(set(selected))==74 and set(selected)=={(o['name'],o['version']) for o in x['origins']},'all selected versions');need(r['request']['install']==x['roots']['requests'],'all exact roots');need(r['results']==[],'no install results')
# Bind source declarations to physical exact opam bytes, parse section roles independently.
want=set()
for o in x['origins']:
 text=(roots[o['repository']]/o['metadata_path']).read_text()
 for sec in o['source_sections']:
  need(sec in text,'source section absent from physical opam')
  role=re.match(r'extra-source\s+"([^"]+)"',sec);role=role.group(1) if role else 'source'
  urls=re.findall(r'"((?:git\+)?https?://[^"\n]+)"',sec);need(bool(urls),'source URL')
  checks=tuple(sorted(re.findall(r'"((?:sha256|sha512|md5)=[0-9a-f]+)"',sec)))
  want.add((o['name']+'.'+o['version'],role,urls[0],checks))
def associations(arts):return {(c['package'],c['role'],a['url'],tuple(sorted(a['checksums']))) for a in arts for c in a['consumers']}
arts=x['artifacts']['artifacts'];need(associations(arts)==want,'consumer declarations exact')
# Native MD5 receipt framed after final alternates. Preserve NUL semantics for filenames.
fs=(S/'git-fsck.stdout').read_bytes();last=fs.rindex(b'/solve/opam/download-cache/git/objects')+len(b'/solve/opam/download-cache/git/objects');md5raw=fs[last:];need(md5raw.endswith(b'\0'),'MD5 NUL');md5={}
for line in md5raw[:-1].split(b'\0'):
 need(re.fullmatch(rb'[0-9a-f]{32}  [^\0]+',line),'MD5 framing');md5[line[34:].decode()]=line[:32].decode()
for a in json.loads((S/'http-object-map.json').read_text()):need(md5[a['path']]==a['md5'],'MD5 raw receipt')
import copy
bad=copy.deepcopy(arts);bad[0]['consumers'].pop();rejected=associations(bad)!=want;need(rejected,'missing consumer rejected')
report={'status':'PASS','physical_metadata_roots':{k:str(v) for k,v in roots.items()},'physical_metadata_files_rehashed':len(expected),'raw_acquisition_sha256':sha(raw),'duplicate_keys_identical':dups,'selected_exact_versions':74,'roots_exact_order':35,'consumer_declarations_independently_parsed':len(want),'all_35_md5_objects_bound_to_raw_native_receipt':True,'missing_consumer_rejected_against_physical_declarations':rejected}
(P/'primary-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
