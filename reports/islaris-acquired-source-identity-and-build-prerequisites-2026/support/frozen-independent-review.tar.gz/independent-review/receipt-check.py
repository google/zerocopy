import pathlib,json,hashlib
P=pathlib.Path(__file__).resolve().parent;S=P.parent/'sail-proof-design/islaris-source-audit'
def need(x,s):
 if not x:raise ValueError(s)
def sha(b):return hashlib.sha256(b).hexdigest()
rows=[]
for f in sorted(S.glob('*-receipt.json')):
 phase=f.name[:-13];r=json.loads(f.read_text());code=S/(phase+'.sh')
 if not code.exists():code=S/(phase+'.py')
 need(sha(code.read_bytes())==r['code_sha256'],'phase code '+phase)
 for stream,v in r['streams'].items():
  b=(S/(phase+'.'+stream)).read_bytes();need(len(b)==v['bytes'] and sha(b)==v['sha256'],'phase stream')
 i=json.loads((S/(phase+'-inspect.stdout')).read_text())[0];host=i['HostConfig'];need(i['Id']=='942f3767a54df1f9f327fd17706f007e09c73e4088b8c272063cc20863c0b2a8' and i['Image']=='sha256:1189d6a4a06d068d675121d121999a7a8d3afa35e6d922ee41a0679fc98876ce' and host['NetworkMode']=='none' and host['Memory']==1073741824 and host['NanoCpus']==1000000000 and host['PidsLimit']==128 and i['Mounts']==[],'phase isolation')
 need(r['status']==(127 if phase=='inventory' else 0),'phase status '+phase);rows.append({'phase':phase,'status':r['status'],'isolation_and_code_stream_bindings':True})
(P/'receipt-check.json').write_text(json.dumps({'status':'PASS','phases':rows},indent=2)+'\n');print(len(rows))
