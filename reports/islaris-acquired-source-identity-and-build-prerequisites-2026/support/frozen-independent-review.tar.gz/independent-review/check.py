import pathlib,json,hashlib,gzip,tarfile,re,copy,posixpath
P=pathlib.Path(__file__).resolve().parent
E=P.parent
S=E/'sail-proof-design/islaris-source-audit'
def J(n):return json.loads((S/n).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def need(x,msg):
 if not x:raise ValueError(msg)
report={}
def manifest_check(rows,reader):
 for r in rows:
  b=reader(r['path']);need(len(b)==r['bytes'] and sha(b)==r['sha256'],'manifest '+r['path'])
rows=J('manifest.json')['files'];manifest_check(rows,lambda n:(S/n).read_bytes())
need({r['path'] for r in rows}=={str(p.relative_to(S)) for p in S.rglob('*') if p.is_file() and p.name!='manifest.json'},'manifest coverage')
need(sha((S/'manifest.json').read_bytes())=='836119699026aaefdaa444b01ab7c9ec9ae203e3d29b86dbc1cf28f8697277e3','frozen manifest')
for n,h in [('RESULTS.md','abd0be3a8c21b0ce272ffb99701ce5196141d5873720ab0ceed2984098f26a34'),('RESULTS.json','7fb150c03589c00e4ec6cd3123adef300e00ae7b09f695fb4598e699a659fde7')]:need(sha((S/n).read_bytes())==h,'frozen '+n)
report['frozen_manifest']={'files':len(rows),'bytes':sum(r['bytes'] for r in rows),'sha256':sha((S/'manifest.json').read_bytes()),'all_files_verified':True}
def nul(raw):
 need(raw.endswith(b'\0'),'NUL terminator');return raw[:-1].split(b'\0')
def hashparse(raw,width=64):
 out={}
 for b in nul(raw):
  need(len(b)>width+2 and b[width:width+2]==b'  ' and re.fullmatch(b'[0-9a-f]{'+str(width).encode()+b'}',b[:width]),'hash framing')
  path=b[width+2:].decode();need(path not in out,'duplicate hash path');out[path]=b[:width].decode()
 return out
h=hashparse((S/'hash-before.stdout').read_bytes());parts=nul((S/'entries-before.stdout').read_bytes());need(len(parts)%7==0,'entry fields');ent={}
for i in range(0,len(parts),7):
 typ,mode,uid,gid,size,path,target=[b.decode() for b in parts[i:i+7]];need(path not in ent,'duplicate entry');ent[path]={'type':typ,'mode':int(mode,8),'uid':int(uid),'gid':int(gid),'bytes':int(size),'target':target}
need(set(h)=={k for k,v in ent.items() if v['type']=='f'},'all regular-file coverage')
for a in ['hash','entries']:
 b=(S/(a+'-before.stdout')).read_bytes();need(b==(S/(a+'-after.stdout')).read_bytes(),'before/after');
 for t in ['before','after']:need(gzip.decompress((S/(a+'-'+t+'.stdout.gz')).read_bytes())==b,'gz')
report['unchanged']={'hashes':len(h),'entries':len(ent),'hash_entry_bijection':True,'before_after_identical':True,'gzip_matches':True}
x=J('inputs.json');arts=x['artifacts']['artifacts'];orig=x['origins'];art={a['id']:a for a in arts};need(len(art)==43 and len(orig)==74,'input counts')
need(x['artifacts']==json.loads((E/'sail-proof-design/islaris-realization-plan/ARTIFACTS.json').read_text()),'plan artifacts')
sel=json.loads(x['native_acquire_raw']);report['native_result_keys']=list(sel)
# Independently validate declared consumer/section associations against each selected origin.
consumer=[]
for o in orig:
 package=o['name']+'.'+o['version'];matches=[]
 for a in arts:
  for c in a['consumers']:
   if c['package']==package:matches.append(a);consumer.append((a['id'],package,c['role']))
 need(set(o['source_sections'])=={s for a in matches for s in a['sections'] if s in o['source_sections']},'section coverage '+package)
 need(all(any(s in o['source_sections'] for s in a['sections']) for a in matches),'consumer mismatch')
 need(h['/owned-inputs/'+o['repository']+'/'+o['metadata_path']]==o['input_metadata_sha256'],'selected metadata')
expected=json.loads((E/'islaris-source-acquisition-20261015/input-file-hashes.json').read_text());need({k[len('/owned-inputs/'):]:v for k,v in h.items() if k.startswith('/owned-inputs/')}==expected,'all metadata')
report['selection_consumer_metadata']={'selected':len(orig),'roots':len(x['roots']['requests']),'consumer_associations':len(consumer),'native_metadata_inputs':len(expected)}
# HTTP hashes are retained native SHA512/MD5 streams and the full SHA256 file ledger.
http={r['id']:r for r in J('http-object-map.json')};s512=hashparse((S/'http-hashes.stdout').read_bytes(),128)
comparisons=0;archives=0;archivecopies=0;membercomparisons=0
for a in arts:
 if a['kind']=='fixed-git':continue
 r=http[a['id']];need(r['sha256']==h[r['path']] and r['sha512']==s512[r['path']],'HTTP ledger')
 for c in a['checksums']:
  alg,digest=c.split('=',1);need(r[alg]==digest,'declared checksum');comparisons+=1
 rec=J(a['id']+'-http.json');need(rec['status']==0 and rec['transport_sha256']==r['sha256'] and rec['transport_bytes']==r['bytes'],'HTTP receipt')
 if a['artifact_class']=='extra-file':
  body=(S/(a['id']+'-extra-source')).read_bytes()
  for c in a['checksums']:
   alg,digest=c.split('=',1);need(hashlib.new(alg,body).hexdigest()==digest,'extra-file independent checksum')
  continue
 archives+=1
 for c in a['consumers']:
  archivecopies+=1;base='/solve/opam/islaris-dry/.opam-switch/sources/'+c['package']+'/'
  actual={n[len(base):]:v for n,v in ent.items() if n.startswith(base) and v['type']!='d'};wanted=rec['members']
  allowed={c2['role']:http[a2['id']]['sha256'] for a2 in arts if a2['artifact_class']=='extra-file' for c2 in a2['consumers'] if c2['package']==c['package']}
  need(not(set(wanted)-set(actual)) and not(set(actual)-set(wanted)-set(allowed)),'archive path coverage')
  for name,w in wanted.items():
   v=actual[name];membercomparisons+=1
   if w['type']=='symlink':need(v['type']=='l' and v['target']==w['target'],'archive link')
   else:need(v['type']=='f' and h[base+name]==w['sha256'] and bool(v['mode']&0o100)==bool(int(w['mode'],8)&0o100),'archive file')
  for n in set(actual)-set(wanted):need(h[base+n]==allowed[n],'archive extra-file')
report['http']={'objects':len(http),'declared_comparisons':comparisons,'archives':archives,'archive_copies':archivecopies,'member_comparisons':membercomparisons,'extra_files_rehashed':6,'scope':'transport MD5/SHA512 use frozen native hash receipts; archived compressed bytes not retained; archive members use frozen streamed member SHA256 ledger'}
# Validate raw retained Git receipts without running Git or source code.
t=tarfile.open(S/'git-final-receipts.tar');tr={m.name:t.extractfile(m).read() for m in t if m.isfile()};manifest_check(J('git-final-receipts-manifest.json'),lambda n:tr[n])
trees=J('git-tree-inventory.json');copies=0;objects=0;reconstructed=0
for tree in trees:
 aid=tree['id'];pre='git/'+aid+'/';commit=tr[pre+'commit'];need(hashlib.sha1(b'commit '+str(len(commit)).encode()+b'\0'+commit).hexdigest()==tree['commit'],'Git commit')
 need(commit.startswith(('tree '+tree['tree']+'\n').encode()) and tr[pre+'head'].decode().strip()==tree['commit'] and tr[pre+'shallow']==b'false\n','commit/tree/head')
 raw=[]
 for line in nul(tr[pre+'tree.z']):
  fields,path=line.split(b'\t',1);mode,typ,oid=fields.decode().split(' ');raw.append({'mode':mode,'type':typ,'oid':oid,'path':path.decode()})
 need(raw==tree['entries'],'raw Git tree inventory')
 ledger=J(aid+'-objects.json');obj={v['oid']:v for v in ledger['objects']};wanted={r['oid'] for r in raw}|{tree['commit'],tree['tree']};need(len(obj)==len(ledger['objects']) and set(obj)==wanted and set(tr[pre+'objects'].decode().splitlines())==wanted,'Git object coverage');need(ledger['status']==0,'Git object status');objects+=len(obj)
 # Reconstruct binary current tree objects, checking every recursive tree SHA1 and SHA256.
 for directory,oid in [('',tree['tree'])]+[(r['path'],r['oid']) for r in raw if r['type']=='tree']:
  children=[r for r in raw if posixpath.dirname(r['path'])==directory]
  children.sort(key=lambda r:posixpath.basename(r['path']).encode()+(b'/' if r['type']=='tree' else b''))
  body=b''.join((r['mode'].lstrip('0')+' '+posixpath.basename(r['path'])).encode()+b'\0'+bytes.fromhex(r['oid']) for r in children)
  need(hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()==oid and sha(body)==obj[oid]['sha256'],'reconstructed tree');reconstructed+=1
 for c in art[aid]['consumers']:
  copies+=1;base='/solve/opam/islaris-dry/.opam-switch/sources/'+c['package']+'/'
  actual={n[len(base):]:v for n,v in ent.items() if n.startswith(base) and n!=base[:-1] and n[len(base):].split('/')[0]!='.git'}
  need(set(actual)=={r['path'] for r in raw},'Git complete paths '+c['package'])
  for r in raw:
   v=actual[r['path']];mode=r['mode'];need(mode!='160000','gitlink')
   if r['type']=='tree':need(v['type']=='d','Git directory')
   elif mode=='120000':
    b=v['target'].encode();need(v['type']=='l' and sha(b)==obj[r['oid']]['sha256'],'Git symlink')
   else:need(v['type']=='f' and h[base+r['path']]==obj[r['oid']]['sha256'] and bool(v['mode']&0o100)==(mode=='100755'),'Git blob/mode')
  alt=base+'.git/objects/info/alternates';need(h[alt]==sha(b'/solve/opam/download-cache/git/objects\n'),'alternate')
 need(tr[pre+'fsck.stdout']==b'' and tr[pre+'fsck.stderr']==b'','fsck streams')
report['git']={'repositories':len(trees),'object_ledger_comparisons':objects,'source_copies':copies,'tree_objects_independently_reconstructed':reconstructed,'no_gitlinks_or_extra_worktree_entries':True,'limit':'non-retained blob bodies are independently compared via frozen object SHA256 ledgers, not re-streamed'}
# Independently repeat corrected exact config receipt lookup against all consumer hash ledgers.
raw=(S/'git-fsck.stdout').read_bytes();configcount=0
for a in arts:
 if a['kind']!='fixed-git':continue
 start=raw.index((a['id']+'\n').encode())+len(a['id'])+1;end=raw.index(b'/solve/opam/download-cache/git/objects',start);config=raw[start:end]
 need(not re.search(rb'^\[(?:include|filter|credential)',config,re.M|re.I),'external config')
 for c in a['consumers']:need(h['/solve/opam/islaris-dry/.opam-switch/sources/'+c['package']+'/.git/config']==sha(config),'config receipt');configcount+=1
report['config_receipts']=configcount
for r in J('SOURCE-INSPECTION.json'):
 body=(S/r['retained']).read_bytes();need(sha(body)==r['sha256'] and hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==r['git_blob'],'source inspection binding')
report['snippets_bound']=3
# Negative controls use altered in-memory subjects only, with the same verifier paths.
controls=[]
def reject(label,fn):
 try:fn()
 except (ValueError,FileNotFoundError,KeyError) as e:controls.append({'control':label,'status':'REJECTED','reason':str(e)})
 else:raise ValueError('negative control accepted '+label)
reject('missing artifact',lambda:manifest_check(rows,lambda n:(_ for _ in ()).throw(FileNotFoundError(n)) if n=='A17-objects.json' else (S/n).read_bytes()))
changed=copy.deepcopy(rows);changed[0]['sha256']='0'*64;reject('corrupted hash',lambda:manifest_check(changed,lambda n:(S/n).read_bytes()))
modified=set(consumer);modified.remove(next(iter(modified)));reject('missing consumer',lambda:need(modified==set(consumer),'consumer association coverage'))
reject('truncated NUL hash stream',lambda:hashparse((S/'hash-before.stdout').read_bytes()[:-1]))
for name in ['.github','.github/workflows','.gitignore','.git','.git/config']:
 included=name.split('/')[0]!='.git';need(included==(not(name=='.git' or name.startswith('.git/'))),'exact Git control')
report['controls']=controls;report['exact_git_filter_regression']=True
(P/'checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
