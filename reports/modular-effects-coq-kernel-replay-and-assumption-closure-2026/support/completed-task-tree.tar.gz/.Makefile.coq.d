src/axioms.vo src/axioms.glob src/axioms.v.beautified src/axioms.required_vo: src/axioms.v 
src/axioms.vio: src/axioms.v 
src/axioms.vos src/axioms.vok src/axioms.required_vos: src/axioms.v 
src/choice.vo src/choice.glob src/choice.v.beautified src/choice.required_vo: src/choice.v src/handler.vo src/wpi.vo src/itree.vo src/axioms.vo src/trace.vo src/exec.vo
src/choice.vio: src/choice.v src/handler.vio src/wpi.vio src/itree.vio src/axioms.vio src/trace.vio src/exec.vio
src/choice.vos src/choice.vok src/choice.required_vos: src/choice.v src/handler.vos src/wpi.vos src/itree.vos src/axioms.vos src/trace.vos src/exec.vos
src/angelic_choice.vo src/angelic_choice.glob src/angelic_choice.v.beautified src/angelic_choice.required_vo: src/angelic_choice.v src/handler.vo src/wpi.vo src/itree.vo src/axioms.vo src/exec.vo
src/angelic_choice.vio: src/angelic_choice.v src/handler.vio src/wpi.vio src/itree.vio src/axioms.vio src/exec.vio
src/angelic_choice.vos src/angelic_choice.vok src/angelic_choice.required_vos: src/angelic_choice.v src/handler.vos src/wpi.vos src/itree.vos src/axioms.vos src/exec.vos
src/ub.vo src/ub.glob src/ub.v.beautified src/ub.required_vo: src/ub.v src/handler.vo src/wpi.vo src/itree.vo src/axioms.vo src/trace.vo src/exec.vo
src/ub.vio: src/ub.v src/handler.vio src/wpi.vio src/itree.vio src/axioms.vio src/trace.vio src/exec.vio
src/ub.vos src/ub.vok src/ub.required_vos: src/ub.v src/handler.vos src/wpi.vos src/itree.vos src/axioms.vos src/trace.vos src/exec.vos
src/halt.vo src/halt.glob src/halt.v.beautified src/halt.required_vo: src/halt.v src/handler.vo src/wpi.vo src/itree.vo src/axioms.vo src/trace.vo src/exec.vo
src/halt.vio: src/halt.v src/handler.vio src/wpi.vio src/itree.vio src/axioms.vio src/trace.vio src/exec.vio
src/halt.vos src/halt.vok src/halt.required_vos: src/halt.v src/handler.vos src/wpi.vos src/itree.vos src/axioms.vos src/trace.vos src/exec.vos
src/step.vo src/step.glob src/step.v.beautified src/step.required_vo: src/step.v src/itree.vo src/wpi.vo src/trace.vo src/handler.vo src/exec.vo
src/step.vio: src/step.v src/itree.vio src/wpi.vio src/trace.vio src/handler.vio src/exec.vio
src/step.vos src/step.vok src/step.required_vos: src/step.v src/itree.vos src/wpi.vos src/trace.vos src/handler.vos src/exec.vos
src/handler.vo src/handler.glob src/handler.v.beautified src/handler.required_vo: src/handler.v 
src/handler.vio: src/handler.v 
src/handler.vos src/handler.vok src/handler.required_vos: src/handler.v 
src/itree.vo src/itree.glob src/itree.v.beautified src/itree.required_vo: src/itree.v src/axioms.vo
src/itree.vio: src/itree.v src/axioms.vio
src/itree.vos src/itree.vok src/itree.required_vos: src/itree.v src/axioms.vos
src/state.vo src/state.glob src/state.v.beautified src/state.required_vo: src/state.v src/handler.vo src/wpi.vo src/itree.vo src/axioms.vo src/trace.vo src/exec.vo
src/state.vio: src/state.v src/handler.vio src/wpi.vio src/itree.vio src/axioms.vio src/trace.vio src/exec.vio
src/state.vos src/state.vok src/state.required_vos: src/state.v src/handler.vos src/wpi.vos src/itree.vos src/axioms.vos src/trace.vos src/exec.vos
src/heap.vo src/heap.glob src/heap.v.beautified src/heap.required_vo: src/heap.v src/wpi.vo src/choice.vo src/ub.vo src/handler.vo src/itree.vo src/step.vo src/state.vo
src/heap.vio: src/heap.v src/wpi.vio src/choice.vio src/ub.vio src/handler.vio src/itree.vio src/step.vio src/state.vio
src/heap.vos src/heap.vok src/heap.required_vos: src/heap.v src/wpi.vos src/choice.vos src/ub.vos src/handler.vos src/itree.vos src/step.vos src/state.vos
src/void.vo src/void.glob src/void.v.beautified src/void.required_vo: src/void.v src/wpi.vo src/itree.vo src/handler.vo src/trace.vo
src/void.vio: src/void.v src/wpi.vio src/itree.vio src/handler.vio src/trace.vio
src/void.vos src/void.vok src/void.required_vos: src/void.v src/wpi.vos src/itree.vos src/handler.vos src/trace.vos
src/trace.vo src/trace.glob src/trace.v.beautified src/trace.required_vo: src/trace.v src/axioms.vo src/itree.vo
src/trace.vio: src/trace.v src/axioms.vio src/itree.vio
src/trace.vos src/trace.vok src/trace.required_vos: src/trace.v src/axioms.vos src/itree.vos
src/threadpool/handler.vo src/threadpool/handler.glob src/threadpool/handler.v.beautified src/threadpool/handler.required_vo: src/threadpool/handler.v src/handler.vo src/wpi.vo src/itree.vo
src/threadpool/handler.vio: src/threadpool/handler.v src/handler.vio src/wpi.vio src/itree.vio
src/threadpool/handler.vos src/threadpool/handler.vok src/threadpool/handler.required_vos: src/threadpool/handler.v src/handler.vos src/wpi.vos src/itree.vos
src/threadpool/interleaving.vo src/threadpool/interleaving.glob src/threadpool/interleaving.v.beautified src/threadpool/interleaving.required_vo: src/threadpool/interleaving.v src/handler.vo src/wpi.vo src/itree.vo src/axioms.vo src/threadpool/handler.vo
src/threadpool/interleaving.vio: src/threadpool/interleaving.v src/handler.vio src/wpi.vio src/itree.vio src/axioms.vio src/threadpool/handler.vio
src/threadpool/interleaving.vos src/threadpool/interleaving.vok src/threadpool/interleaving.required_vos: src/threadpool/interleaving.v src/handler.vos src/wpi.vos src/itree.vos src/axioms.vos src/threadpool/handler.vos
src/threadpool/scheduler.vo src/threadpool/scheduler.glob src/threadpool/scheduler.v.beautified src/threadpool/scheduler.required_vo: src/threadpool/scheduler.v src/axioms.vo src/itree.vo src/threadpool/handler.vo src/threadpool/interleaving.vo
src/threadpool/scheduler.vio: src/threadpool/scheduler.v src/axioms.vio src/itree.vio src/threadpool/handler.vio src/threadpool/interleaving.vio
src/threadpool/scheduler.vos src/threadpool/scheduler.vok src/threadpool/scheduler.required_vos: src/threadpool/scheduler.v src/axioms.vos src/itree.vos src/threadpool/handler.vos src/threadpool/interleaving.vos
src/threadpool/ctrace.vo src/threadpool/ctrace.glob src/threadpool/ctrace.v.beautified src/threadpool/ctrace.required_vo: src/threadpool/ctrace.v src/threadpool/handler.vo src/threadpool/interleaving.vo src/threadpool/scheduler.vo src/axioms.vo src/itree.vo src/trace.vo
src/threadpool/ctrace.vio: src/threadpool/ctrace.v src/threadpool/handler.vio src/threadpool/interleaving.vio src/threadpool/scheduler.vio src/axioms.vio src/itree.vio src/trace.vio
src/threadpool/ctrace.vos src/threadpool/ctrace.vok src/threadpool/ctrace.required_vos: src/threadpool/ctrace.v src/threadpool/handler.vos src/threadpool/interleaving.vos src/threadpool/scheduler.vos src/axioms.vos src/itree.vos src/trace.vos
src/threadpool/exec.vo src/threadpool/exec.glob src/threadpool/exec.v.beautified src/threadpool/exec.required_vo: src/threadpool/exec.v src/exec.vo src/threadpool/handler.vo
src/threadpool/exec.vio: src/threadpool/exec.v src/exec.vio src/threadpool/handler.vio
src/threadpool/exec.vos src/threadpool/exec.vok src/threadpool/exec.required_vos: src/threadpool/exec.v src/exec.vos src/threadpool/handler.vos
src/wpi.vo src/wpi.glob src/wpi.v.beautified src/wpi.required_vo: src/wpi.v src/handler.vo src/itree.vo
src/wpi.vio: src/wpi.v src/handler.vio src/itree.vio
src/wpi.vos src/wpi.vok src/wpi.required_vos: src/wpi.v src/handler.vos src/itree.vos
src/interpreter.vo src/interpreter.glob src/interpreter.v.beautified src/interpreter.required_vo: src/interpreter.v src/wpi.vo src/itree.vo src/handler.vo src/void.vo src/axioms.vo
src/interpreter.vio: src/interpreter.v src/wpi.vio src/itree.vio src/handler.vio src/void.vio src/axioms.vio
src/interpreter.vos src/interpreter.vok src/interpreter.required_vos: src/interpreter.v src/wpi.vos src/itree.vos src/handler.vos src/void.vos src/axioms.vos
src/exec.vo src/exec.glob src/exec.v.beautified src/exec.required_vo: src/exec.v src/itree.vo src/wpi.vo src/handler.vo
src/exec.vio: src/exec.v src/itree.vio src/wpi.vio src/handler.vio
src/exec.vos src/exec.vok src/exec.required_vos: src/exec.v src/itree.vos src/wpi.vos src/handler.vos
src/heaplang/definition.vo src/heaplang/definition.glob src/heaplang/definition.v.beautified src/heaplang/definition.required_vo: src/heaplang/definition.v 
src/heaplang/definition.vio: src/heaplang/definition.v 
src/heaplang/definition.vos src/heaplang/definition.vok src/heaplang/definition.required_vos: src/heaplang/definition.v 
src/heaplang/lang.vo src/heaplang/lang.glob src/heaplang/lang.v.beautified src/heaplang/lang.required_vo: src/heaplang/lang.v src/wpi.vo src/choice.vo src/ub.vo src/heap.vo src/handler.vo src/itree.vo src/step.vo src/threadpool/handler.vo src/heaplang/definition.vo
src/heaplang/lang.vio: src/heaplang/lang.v src/wpi.vio src/choice.vio src/ub.vio src/heap.vio src/handler.vio src/itree.vio src/step.vio src/threadpool/handler.vio src/heaplang/definition.vio
src/heaplang/lang.vos src/heaplang/lang.vok src/heaplang/lang.required_vos: src/heaplang/lang.v src/wpi.vos src/choice.vos src/ub.vos src/heap.vos src/handler.vos src/itree.vos src/step.vos src/threadpool/handler.vos src/heaplang/definition.vos
src/heaplang/decide.vo src/heaplang/decide.glob src/heaplang/decide.v.beautified src/heaplang/decide.required_vo: src/heaplang/decide.v src/heaplang/lang.vo
src/heaplang/decide.vio: src/heaplang/decide.v src/heaplang/lang.vio
src/heaplang/decide.vos src/heaplang/decide.vok src/heaplang/decide.required_vos: src/heaplang/decide.v src/heaplang/lang.vos
src/heaplang/program_logic.vo src/heaplang/program_logic.glob src/heaplang/program_logic.v.beautified src/heaplang/program_logic.required_vo: src/heaplang/program_logic.v src/wpi.vo src/choice.vo src/ub.vo src/heap.vo src/handler.vo src/itree.vo src/step.vo src/heaplang/definition.vo src/heaplang/lang.vo src/threadpool/handler.vo
src/heaplang/program_logic.vio: src/heaplang/program_logic.v src/wpi.vio src/choice.vio src/ub.vio src/heap.vio src/handler.vio src/itree.vio src/step.vio src/heaplang/definition.vio src/heaplang/lang.vio src/threadpool/handler.vio
src/heaplang/program_logic.vos src/heaplang/program_logic.vok src/heaplang/program_logic.required_vos: src/heaplang/program_logic.v src/wpi.vos src/choice.vos src/ub.vos src/heap.vos src/handler.vos src/itree.vos src/step.vos src/heaplang/definition.vos src/heaplang/lang.vos src/threadpool/handler.vos
src/heaplang/adequacy.vo src/heaplang/adequacy.glob src/heaplang/adequacy.v.beautified src/heaplang/adequacy.required_vo: src/heaplang/adequacy.v src/wpi.vo src/ub.vo src/itree.vo src/choice.vo src/state.vo src/step.vo src/handler.vo src/void.vo src/heap.vo src/threadpool/ctrace.vo src/threadpool/handler.vo src/threadpool/interleaving.vo src/heaplang/lang.vo src/heaplang/program_logic.vo
src/heaplang/adequacy.vio: src/heaplang/adequacy.v src/wpi.vio src/ub.vio src/itree.vio src/choice.vio src/state.vio src/step.vio src/handler.vio src/void.vio src/heap.vio src/threadpool/ctrace.vio src/threadpool/handler.vio src/threadpool/interleaving.vio src/heaplang/lang.vio src/heaplang/program_logic.vio
src/heaplang/adequacy.vos src/heaplang/adequacy.vok src/heaplang/adequacy.required_vos: src/heaplang/adequacy.v src/wpi.vos src/ub.vos src/itree.vos src/choice.vos src/state.vos src/step.vos src/handler.vos src/void.vos src/heap.vos src/threadpool/ctrace.vos src/threadpool/handler.vos src/threadpool/interleaving.vos src/heaplang/lang.vos src/heaplang/program_logic.vos
src/heaplang/opsem_adequacy.vo src/heaplang/opsem_adequacy.glob src/heaplang/opsem_adequacy.v.beautified src/heaplang/opsem_adequacy.required_vo: src/heaplang/opsem_adequacy.v src/wpi.vo src/ub.vo src/itree.vo src/choice.vo src/state.vo src/heap.vo src/threadpool/ctrace.vo src/heaplang/decide.vo src/step.vo src/handler.vo src/void.vo src/threadpool/handler.vo src/threadpool/interleaving.vo src/heaplang/lang.vo src/heaplang/program_logic.vo src/heaplang/adequacy.vo
src/heaplang/opsem_adequacy.vio: src/heaplang/opsem_adequacy.v src/wpi.vio src/ub.vio src/itree.vio src/choice.vio src/state.vio src/heap.vio src/threadpool/ctrace.vio src/heaplang/decide.vio src/step.vio src/handler.vio src/void.vio src/threadpool/handler.vio src/threadpool/interleaving.vio src/heaplang/lang.vio src/heaplang/program_logic.vio src/heaplang/adequacy.vio
src/heaplang/opsem_adequacy.vos src/heaplang/opsem_adequacy.vok src/heaplang/opsem_adequacy.required_vos: src/heaplang/opsem_adequacy.v src/wpi.vos src/ub.vos src/itree.vos src/choice.vos src/state.vos src/heap.vos src/threadpool/ctrace.vos src/heaplang/decide.vos src/step.vos src/handler.vos src/void.vos src/threadpool/handler.vos src/threadpool/interleaving.vos src/heaplang/lang.vos src/heaplang/program_logic.vos src/heaplang/adequacy.vos
src/heaplang/interpreter.vo src/heaplang/interpreter.glob src/heaplang/interpreter.v.beautified src/heaplang/interpreter.required_vo: src/heaplang/interpreter.v src/wpi.vo src/ub.vo src/itree.vo src/choice.vo src/heap.vo src/handler.vo src/void.vo src/interpreter.vo src/step.vo src/threadpool/handler.vo src/threadpool/interleaving.vo src/threadpool/scheduler.vo src/heaplang/lang.vo src/heaplang/adequacy.vo
src/heaplang/interpreter.vio: src/heaplang/interpreter.v src/wpi.vio src/ub.vio src/itree.vio src/choice.vio src/heap.vio src/handler.vio src/void.vio src/interpreter.vio src/step.vio src/threadpool/handler.vio src/threadpool/interleaving.vio src/threadpool/scheduler.vio src/heaplang/lang.vio src/heaplang/adequacy.vio
src/heaplang/interpreter.vos src/heaplang/interpreter.vok src/heaplang/interpreter.required_vos: src/heaplang/interpreter.v src/wpi.vos src/ub.vos src/itree.vos src/choice.vos src/heap.vos src/handler.vos src/void.vos src/interpreter.vos src/step.vos src/threadpool/handler.vos src/threadpool/interleaving.vos src/threadpool/scheduler.vos src/heaplang/lang.vos src/heaplang/adequacy.vos
src/heaplang/tactics.vo src/heaplang/tactics.glob src/heaplang/tactics.v.beautified src/heaplang/tactics.required_vo: src/heaplang/tactics.v src/heaplang/lang.vo src/heaplang/program_logic.vo
src/heaplang/tactics.vio: src/heaplang/tactics.v src/heaplang/lang.vio src/heaplang/program_logic.vio
src/heaplang/tactics.vos src/heaplang/tactics.vok src/heaplang/tactics.required_vos: src/heaplang/tactics.v src/heaplang/lang.vos src/heaplang/program_logic.vos
src/heaplang/examples/join.vo src/heaplang/examples/join.glob src/heaplang/examples/join.v.beautified src/heaplang/examples/join.required_vo: src/heaplang/examples/join.v src/heaplang/definition.vo src/heaplang/lang.vo src/heaplang/program_logic.vo src/heaplang/tactics.vo src/heap.vo src/step.vo
src/heaplang/examples/join.vio: src/heaplang/examples/join.v src/heaplang/definition.vio src/heaplang/lang.vio src/heaplang/program_logic.vio src/heaplang/tactics.vio src/heap.vio src/step.vio
src/heaplang/examples/join.vos src/heaplang/examples/join.vok src/heaplang/examples/join.required_vos: src/heaplang/examples/join.v src/heaplang/definition.vos src/heaplang/lang.vos src/heaplang/program_logic.vos src/heaplang/tactics.vos src/heap.vos src/step.vos
src/heaplang/examples/spinlock.vo src/heaplang/examples/spinlock.glob src/heaplang/examples/spinlock.v.beautified src/heaplang/examples/spinlock.required_vo: src/heaplang/examples/spinlock.v src/heaplang/definition.vo src/heaplang/lang.vo src/heaplang/program_logic.vo src/heaplang/tactics.vo src/heap.vo src/step.vo
src/heaplang/examples/spinlock.vio: src/heaplang/examples/spinlock.v src/heaplang/definition.vio src/heaplang/lang.vio src/heaplang/program_logic.vio src/heaplang/tactics.vio src/heap.vio src/step.vio
src/heaplang/examples/spinlock.vos src/heaplang/examples/spinlock.vok src/heaplang/examples/spinlock.required_vos: src/heaplang/examples/spinlock.v src/heaplang/definition.vos src/heaplang/lang.vos src/heaplang/program_logic.vos src/heaplang/tactics.vos src/heap.vos src/step.vos
src/examplelang/lang.vo src/examplelang/lang.glob src/examplelang/lang.v.beautified src/examplelang/lang.required_vo: src/examplelang/lang.v src/wpi.vo src/choice.vo src/ub.vo src/heap.vo src/handler.vo src/itree.vo src/threadpool/handler.vo
src/examplelang/lang.vio: src/examplelang/lang.v src/wpi.vio src/choice.vio src/ub.vio src/heap.vio src/handler.vio src/itree.vio src/threadpool/handler.vio
src/examplelang/lang.vos src/examplelang/lang.vok src/examplelang/lang.required_vos: src/examplelang/lang.v src/wpi.vos src/choice.vos src/ub.vos src/heap.vos src/handler.vos src/itree.vos src/threadpool/handler.vos
src/examplelang/program_logic.vo src/examplelang/program_logic.glob src/examplelang/program_logic.v.beautified src/examplelang/program_logic.required_vo: src/examplelang/program_logic.v src/wpi.vo src/choice.vo src/ub.vo src/heap.vo src/handler.vo src/itree.vo src/threadpool/handler.vo src/examplelang/lang.vo
src/examplelang/program_logic.vio: src/examplelang/program_logic.v src/wpi.vio src/choice.vio src/ub.vio src/heap.vio src/handler.vio src/itree.vio src/threadpool/handler.vio src/examplelang/lang.vio
src/examplelang/program_logic.vos src/examplelang/program_logic.vok src/examplelang/program_logic.required_vos: src/examplelang/program_logic.v src/wpi.vos src/choice.vos src/ub.vos src/heap.vos src/handler.vos src/itree.vos src/threadpool/handler.vos src/examplelang/lang.vos
src/examplelang/adequacy.vo src/examplelang/adequacy.glob src/examplelang/adequacy.v.beautified src/examplelang/adequacy.required_vo: src/examplelang/adequacy.v src/wpi.vo src/ub.vo src/itree.vo src/choice.vo src/state.vo src/step.vo src/handler.vo src/void.vo src/heap.vo src/threadpool/ctrace.vo src/threadpool/handler.vo src/threadpool/interleaving.vo src/examplelang/lang.vo src/examplelang/program_logic.vo
src/examplelang/adequacy.vio: src/examplelang/adequacy.v src/wpi.vio src/ub.vio src/itree.vio src/choice.vio src/state.vio src/step.vio src/handler.vio src/void.vio src/heap.vio src/threadpool/ctrace.vio src/threadpool/handler.vio src/threadpool/interleaving.vio src/examplelang/lang.vio src/examplelang/program_logic.vio
src/examplelang/adequacy.vos src/examplelang/adequacy.vok src/examplelang/adequacy.required_vos: src/examplelang/adequacy.v src/wpi.vos src/ub.vos src/itree.vos src/choice.vos src/state.vos src/step.vos src/handler.vos src/void.vos src/heap.vos src/threadpool/ctrace.vos src/threadpool/handler.vos src/threadpool/interleaving.vos src/examplelang/lang.vos src/examplelang/program_logic.vos
islaris/base.vo islaris/base.glob islaris/base.v.beautified islaris/base.required_vo: islaris/base.v 
islaris/base.vio: islaris/base.v 
islaris/base.vos islaris/base.vok islaris/base.required_vos: islaris/base.v 
islaris/adequacy.vo islaris/adequacy.glob islaris/adequacy.v.beautified islaris/adequacy.required_vo: islaris/adequacy.v islaris/ghost_state.vo islaris/lifting.vo
islaris/adequacy.vio: islaris/adequacy.v islaris/ghost_state.vio islaris/lifting.vio
islaris/adequacy.vos islaris/adequacy.vok islaris/adequacy.required_vos: islaris/adequacy.v islaris/ghost_state.vos islaris/lifting.vos
islaris/adequacy_itree.vo islaris/adequacy_itree.glob islaris/adequacy_itree.v.beautified islaris/adequacy_itree.required_vo: islaris/adequacy_itree.v src/itree.vo src/exec.vo src/handler.vo src/wpi.vo src/choice.vo src/state.vo src/step.vo src/halt.vo src/ub.vo islaris/adequacy.vo islaris/opsem.vo islaris/opsem_itree.vo islaris/spec_itree.vo islaris/lifting_itree.vo
islaris/adequacy_itree.vio: islaris/adequacy_itree.v src/itree.vio src/exec.vio src/handler.vio src/wpi.vio src/choice.vio src/state.vio src/step.vio src/halt.vio src/ub.vio islaris/adequacy.vio islaris/opsem.vio islaris/opsem_itree.vio islaris/spec_itree.vio islaris/lifting_itree.vio
islaris/adequacy_itree.vos islaris/adequacy_itree.vok islaris/adequacy_itree.required_vos: islaris/adequacy_itree.v src/itree.vos src/exec.vos src/handler.vos src/wpi.vos src/choice.vos src/state.vos src/step.vos src/halt.vos src/ub.vos islaris/adequacy.vos islaris/opsem.vos islaris/opsem_itree.vos islaris/spec_itree.vos islaris/lifting_itree.vos
islaris/ghost_state.vo islaris/ghost_state.glob islaris/ghost_state.v.beautified islaris/ghost_state.required_vo: islaris/ghost_state.v islaris/opsem.vo islaris/spec.vo
islaris/ghost_state.vio: islaris/ghost_state.v islaris/opsem.vio islaris/spec.vio
islaris/ghost_state.vos islaris/ghost_state.vok islaris/ghost_state.required_vos: islaris/ghost_state.v islaris/opsem.vos islaris/spec.vos
islaris/lifting.vo islaris/lifting.glob islaris/lifting.v.beautified islaris/lifting.required_vo: islaris/lifting.v islaris/opsem.vo islaris/ghost_state.vo
islaris/lifting.vio: islaris/lifting.v islaris/opsem.vio islaris/ghost_state.vio
islaris/lifting.vos islaris/lifting.vok islaris/lifting.required_vos: islaris/lifting.v islaris/opsem.vos islaris/ghost_state.vos
islaris/lifting_itree.vo islaris/lifting_itree.glob islaris/lifting_itree.v.beautified islaris/lifting_itree.required_vo: islaris/lifting_itree.v src/wpi.vo src/choice.vo src/ub.vo src/state.vo src/handler.vo src/itree.vo src/halt.vo src/step.vo islaris/lifting.vo islaris/opsem_itree.vo islaris/ghost_state.vo islaris/spec_itree.vo
islaris/lifting_itree.vio: islaris/lifting_itree.v src/wpi.vio src/choice.vio src/ub.vio src/state.vio src/handler.vio src/itree.vio src/halt.vio src/step.vio islaris/lifting.vio islaris/opsem_itree.vio islaris/ghost_state.vio islaris/spec_itree.vio
islaris/lifting_itree.vos islaris/lifting_itree.vok islaris/lifting_itree.required_vos: islaris/lifting_itree.v src/wpi.vos src/choice.vos src/ub.vos src/state.vos src/handler.vos src/itree.vos src/halt.vos src/step.vos islaris/lifting.vos islaris/opsem_itree.vos islaris/ghost_state.vos islaris/spec_itree.vos
islaris/opsem.vo islaris/opsem.glob islaris/opsem.v.beautified islaris/opsem.required_vo: islaris/opsem.v islaris/isla_lang.vo islaris/base.vo
islaris/opsem.vio: islaris/opsem.v islaris/isla_lang.vio islaris/base.vio
islaris/opsem.vos islaris/opsem.vok islaris/opsem.required_vos: islaris/opsem.v islaris/isla_lang.vos islaris/base.vos
islaris/opsem_itree.vo islaris/opsem_itree.glob islaris/opsem_itree.v.beautified islaris/opsem_itree.required_vo: islaris/opsem_itree.v src/wpi.vo src/choice.vo src/ub.vo src/state.vo src/handler.vo src/itree.vo src/halt.vo src/step.vo islaris/opsem.vo islaris/spec_itree.vo
islaris/opsem_itree.vio: islaris/opsem_itree.v src/wpi.vio src/choice.vio src/ub.vio src/state.vio src/handler.vio src/itree.vio src/halt.vio src/step.vio islaris/opsem.vio islaris/spec_itree.vio
islaris/opsem_itree.vos islaris/opsem_itree.vok islaris/opsem_itree.required_vos: islaris/opsem_itree.v src/wpi.vos src/choice.vos src/ub.vos src/state.vos src/handler.vos src/itree.vos src/halt.vos src/step.vos islaris/opsem.vos islaris/spec_itree.vos
islaris/spec.vo islaris/spec.glob islaris/spec.v.beautified islaris/spec.required_vo: islaris/spec.v islaris/opsem.vo
islaris/spec.vio: islaris/spec.v islaris/opsem.vio
islaris/spec.vos islaris/spec.vok islaris/spec.required_vos: islaris/spec.v islaris/opsem.vos
islaris/spec_itree.vo islaris/spec_itree.glob islaris/spec_itree.v.beautified islaris/spec_itree.required_vo: islaris/spec_itree.v src/handler.vo src/wpi.vo src/itree.vo src/axioms.vo src/trace.vo src/exec.vo islaris/spec.vo islaris/opsem.vo islaris/ghost_state.vo islaris/lifting.vo
islaris/spec_itree.vio: islaris/spec_itree.v src/handler.vio src/wpi.vio src/itree.vio src/axioms.vio src/trace.vio src/exec.vio islaris/spec.vio islaris/opsem.vio islaris/ghost_state.vio islaris/lifting.vio
islaris/spec_itree.vos islaris/spec_itree.vok islaris/spec_itree.required_vos: islaris/spec_itree.v src/handler.vos src/wpi.vos src/itree.vos src/axioms.vos src/trace.vos src/exec.vos islaris/spec.vos islaris/opsem.vos islaris/ghost_state.vos islaris/lifting.vos
islaris/isla_lang.vo islaris/isla_lang.glob islaris/isla_lang.v.beautified islaris/isla_lang.required_vo: islaris/isla_lang.v 
islaris/isla_lang.vio: islaris/isla_lang.v 
islaris/isla_lang.vos islaris/isla_lang.vok islaris/isla_lang.required_vos: islaris/isla_lang.v 
