#!/bin/bash

opam switch create . ocaml-base-compiler.4.14.0 --no-install
eval $(opam env)
opam repo add coq-released "https://coq.inria.fr/opam/released"
opam repo add iris-dev "https://gitlab.mpi-sws.org/iris/opam.git"

cd iris-itree
make builddep OPAMFLAGS="-y"
make -j$(nproc)
