# Program logics à la carte -- Artifact

This is the artifact for ["Program logics à la carte"][paper] (doi: 10.1145/3704847).
See [the git repository][git] for the latest version.

[paper]: https://plf.inf.ethz.ch/research/popl25-itree-program-logic.html
[git]: https://gitlab.mpi-sws.org/iris/itree-program-logic

## List of Claims
The main claim of this artifact is that the description in the paper corresponds
to the Coq development (modulo small simplifications for presentation purposes).
The mapping from concepts in the paper to the Coq development can be found below
under "Mapping between the paper and the Coq development".

An additional claim is that Coq development only depends on the axioms
listed under "Axioms" below.

## Installation instructions and sanity-testing
To install the artifact, we provide two options: (1) using a Docker container that has the implementation installed already (`docker_image.tar.gz`) and (2) installing the artifact locally on your machine.
We recommend the first option, using the Docker container, because it avoids manually installing the dependencies and should make it easier to get started.

### Installation Option 1: Docker container (Recommended)

To use Docker containers for the artifact, please install [Docker](https://www.docker.com) on your machine.
The resources provided to Docker containers (e.g., RAM) can be configured in the Docker settings (e.g., Preferences/Resources in Docker Desktop, see https://stackoverflow.com/a/44533437 ). 
Note that the 2 GB provided by default on MacOS do not suffice to build the Coq development. 
This Docker-based installation was tested on an Linux-based x86 machine and a MacOS-based Arm machine.

To load the image, please execute the following (this may take a while):
```
docker load -i docker_image.tar.gz
```

After importing, you can start running an instance of the image (i.e., a container) with the following command:
```
docker run --rm -it --entrypoint bash irisitree/artifact
```
It will start a bash session in the container, starting in the folder `/home/user/artifact/`—analogous to the root artifact folder containing this Readme.
The container contains an installed version of the Coq development in the folder `iris-itree/`.

Note that on Arm MacOS this can lead to the following warning that can be ignored:
```
WARNING: The requested image's platform (linux/amd64) does not match the detected host platform (linux/arm64/v8) and no specific platform was requested
```

Thanks to the `--rm` flag, the docker container should be removed automatically when you exit the interactive session. If you want to keep the docker container around after exiting the session, you can run
```
docker run -it --entrypoint bash --name irisitree_container irisitree/artifact
```
If you wish to stop the container, you can execute:
```
docker stop irisitree_container
```
If you with to restart it again after stopping, you can execute:
```
docker restart irisitree_container
docker exec -it irisitree_container bash
```

To check that the docker container work correctly, please navigate to the `iris-itree` folder via the following command:
```
cd iris-itree
```
and run
```
make -j4
```
It should output the following as everything is prebuilt:
```
make[1]: Entering directory '/home/user/artifact/iris-itree
make[2]: Nothing to be done for 'real-all'.
make[1]: Leaving directory '/home/user/artifact/iris-itree
```


### **Editor**
As an editor for Coq, we have installed Emacs with Proof General inside the container.
You can open a file with Emacs by executing:
```
emacs path/to/file.v
```

An overview of Emacs key bindings can be found at https://www.gnu.org/software/emacs/refcards/pdf/refcard.pdf
and https://proofgeneral.github.io/doc/master/userman/Basic-Script-Management/#Script-processing-commands.
The most important keybindings for interacting with Coq files in Emacs/Proof General are the following:
(`C-x` refers to simultaneous pressing the Ctrl and the x key. `C-x C-c` means first pressing Ctrl and x together, then pressing Ctrl and c together.)
- `C-x C-c`: Exit emacs
- `C-c RET`: Process the Coq buffer to the current cursor
- `C-c C-n`: Process the next Coq command
- `C-c C-u`: Go back one Coq command

(The editor `nano` is also installed, but has no support for stepping through Coq proofs.)

### Installation Option 2: Local Installation (Alternative)

This installation will install the Coq development locally on your machine using `opam`. It will do so in a new `opam` switch that is stored inside the artifact folder, thereby ensuring that none of your existing Coq developments are affected. Below we provide step-by-step instructions for the installation.

#### **Step 1: Dependencies.**
We require [Opam](https://opam.ocaml.org) (version >= 2.0) to install the Coq development.
To check whether `opam` is installed, you can run `opam --version`.
You will need at least version `2.0.0`.
If you do not already have Opam installed then follow [these instructions](https://opam.ocaml.org/doc/Install.html).
If you have not previously initialized Opam on your system, please run
```
opam init
```

#### **Step 2: Installation.**
To build the artifact in a new opam switch, we provide an installation script, `build_source.sh`.
Please run the following at the root of the artifact folder:
```bash
./build_source.sh
```


The `./build_source.sh` script
1. creates a fresh Opam switch in the artifact directory (i.e., the current directory),
2. installs additional dependencies in the new switch (e.g., Coq and Iris), and
3. builds the Coq implementation.


#### **Step 3: Configuring your Environment**
To make the implementation available in a terminal, please run in the artifact directory:

```
eval $(opam env)
```

When configuring your Coq development environment (e.g., VSCode, Emacs), make sure they use Coq from
this switch:
- Emacs generally picks this up automatically if you start it from within a terminal where the
  switch is active.
- VSCode needs `vscoq.path` to be set to the output of `$(which vscoqtop)` when run inside the
  switch.


## Overview of the Artifact
The artifact mainly contains the following files and folders:
- Folder `iris-itree` contains the Coq development for this paper.
  - Subfolder `iris-itree/src` contains the generic infrastructure for
    defining program logics based on ITrees in the paper.
  - Subfolder `iris-itree/src/examplelang` contains the formalization
    of the example language described in Section 2 of the paper.
  - Subfolder `iris-itree/src/heaplang` contains the reimplementation
    of the HeapLang program logic using the techniques described in the paper.
  - Subfolder `iris-itree/islaris` contains the reimplementation
    of the Islaris program logic using the techniques described in the paper.
- The file `iris-itree/coq_vs_paper.md` describes how the results of the paper map to the Coq
  development. See "Mapping between the paper and the Coq development" below.

The following directories are dependencies that we
provide for easing the installation, **not part of the artifact proper**:
- Folders `iris` and `stdpp` provide the source code of the
  Iris framework for separation logic, and the std++ Coq library.

The remaining files and folders of the directory are less relevant:
- File `build_source.sh` is a script used to build the artifact.
- File `docker_image.tar.gz` contains the Docker image described in
  the installation instructions.
- Folder `_opam` (created during installation) contains a local installation
  of OCaml and the packages required by the artifact.
- File `README.md` is, well, this file.


## Differences to the paper
Before exploring the Coq development, note the following differences between the paper and the mechanization:

- In Coq, we prefer to write `wp` rules in a continuation passing style, so that they are easier to
  apply.
- As mentioned in Section 3.3, side-conditions of the form `↑heapH_inv_name ⊆ E` appear in various
  places because we need to make sure we can access the heap invariant.
- As mentioned in footnote 5, our on-paper theory does not account for later modalities or timeless
  side-conditions on invariant opening rules, but they are necessary in the formalization; e.g.,
  `wpi_open_invariant` and `wpi_open_invariant_timeless`.
- As mentioned in footnote 7, the paper does not account for the possibility of the last thread
  terminating safely, whereas the Coq formalization does. This explains why `last_thread_killed`
  appears various places.
- At various points in the paper, we excise mask-changing updates for clearer exposition. Naturally,
  we cannot do so in the Coq code.
- Various other minor differences are covered in `iris-itree/coq_vs_paper.md`.

## Mapping between the paper and the Coq development
A mapping between what is in the paper and in the Coq development is given in
`iris-itree/coq_vs_paper.md`.

## Axioms
The development relies on the following non-constructive axioms (see `src/axioms.v`):
* Functional form of the (non-extensional) axiom of choice, Choice (`FunctionalChoice` of `Coq.Logic.ChoiceFacts`)
* Invariance by Substitution of Reflexive Equality Proofs, UIP (`Eq_rect_eq` from `Coq.Logic.EqdepFacts`)
* Strong bisimulation implies equality for itrees (`bisimulation_is_eq` from `ITree.Eq.EqAxiom`)

According to [the Coq wiki](https://github.com/coq/coq/wiki/The-Logic-of-Coq#what-axioms-can-be-safely-added-to-coq), the first two axioms can be safely added to Coq.
The last axiom is a standard type of axiom when working with coinductive data types. It is not mentioned in the Coq documentation.
