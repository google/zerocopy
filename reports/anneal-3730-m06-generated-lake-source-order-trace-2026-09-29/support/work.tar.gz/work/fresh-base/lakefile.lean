import Lake
open Lake DSL
require aeneas from "/Users/josh/Codex/Projects/zerocopy/.anneal-local-tools/aeneas-release/backends/lean"
package m06_probe
lean_lib Source
@[default_target]
lean_lib Consumer
