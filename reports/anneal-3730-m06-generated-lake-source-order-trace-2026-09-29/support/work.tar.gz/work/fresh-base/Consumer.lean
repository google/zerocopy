import Source
theorem inc0 : comparator_probe.inc 0#u32 = .ok 1#u32 := by rfl
theorem twice0 : comparator_probe.twice 0#u32 = .ok 2#u32 := by rfl
theorem choose0 : comparator_probe.choose 0#u32 = .ok 3#u32 := by rfl
