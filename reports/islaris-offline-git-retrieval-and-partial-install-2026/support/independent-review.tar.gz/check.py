from pathlib import Path
import json,hashlib,re,collections,operator,copy
E=Path('<HOST_WORKSPACE>/work/execution');S=E/'review-islaris-offline-recovery';R=E/'parent/islaris-opam-download-run-20261015';N=R/'native-run';PREP=E/'sail-proof-design/opam-download-only-gate-v3';assert S.resolve()==S and S.parent.resolve()==E
H=lambda b:hashlib.sha256(b).hexdigest()
def ck(v,m):
 if not v:raise AssertionError(m)
def j(p):return json.loads(p.read_text())
def raw(label):
 ps=sorted(N.glob('[0-9][0-9][0-9]-'+label+'.stdout'));ck(len(ps)==1,'unique label '+label);return ps[0].read_bytes()
def raws(label):return [p.read_bytes() for p in sorted(N.glob('[0-9][0-9][0-9]-'+label+'.stdout'))]
def hashes(b):
 ck(b.endswith(b'\0'),'hash stream framing');o={}
 for r in b[:-1].split(b'\0'):
  ck(len(r)>66 and r[64:66]==b'  ','hash line');p=r[66:].decode();ck(p not in o,'hash duplicate');o[p]=r[:64].decode()
 return o
def entries(b):
 a=b.split(b'\0');ck(a[-1]==b'' and (len(a)-1)%7==0,'entry framing');o={}
 for i in range(0,len(a)-1,7):
  typ,mode,uid,gid,size,p,link=[x.decode() for x in a[i:i+7]];ck(p not in o,'entry duplicate');o[p]={'type':typ,'mode':mode,'uid':uid,'gid':gid,'size':int(size),'link':link}
 return o
# Freeze all primary raw input bytes, streaming large repeated solver outputs.
rows=[]
for p in sorted(R.rglob('*')):
 ck(not p.is_symlink(),'raw symlink')
 if p.is_file():
  h=hashlib.sha256()
  with p.open('rb') as f:
   for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
  rows.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':h.hexdigest()})
(S/'RAW-SUBJECT-MANIFEST.json').write_text(json.dumps({'root':str(R),'files':rows},indent=2)+'\n')
# Pre-executed preparation byte identity and exact primary source-copy lineage.
for p in PREP.rglob('*'):
 if p.is_file():ck(p.read_bytes()==(R/p.relative_to(PREP)).read_bytes(),'frozen prep copy')
for x in j(R/'MANIFEST.json')['files']:
 b=(R/x['path']).read_bytes();ck(len(b)==x['bytes'] and H(b)==x['sha256'],'prep manifest')
for x in j(R/'PRIMARY.json')['files']:
 b=(R/x['path']).read_bytes();ck(H(b)==x['sha256'] and len(b)==x['bytes'],'primary identity');ck(b==(E.parent.parent/x['source_path']).read_bytes(),'primary original bytes')
# Every executed phase argv/status and available raw streams. Object bodies intentionally not retained.
recs=[];stream_count=0
for p in sorted(N.glob('[0-9][0-9][0-9]-*.json')):
 d=j(p)
 if not isinstance(d,dict) or 'argv' not in d:continue
 recs.append((p,d));ck(d['status']==0 and d.get('error') is None,'phase status '+p.name)
 for stream in ['stdout','stderr']:
  sp=N/(p.name.removesuffix('.json').removesuffix('-artifact-stop')+'.'+stream)
  if stream+'_sha256' in d and sp.exists():ck(H(sp.read_bytes())==d[stream+'_sha256'],'stream hash');stream_count+=1
  if stream+'_bytes' in d:ck(sp.stat().st_size==d[stream+'_bytes'],'stream size')
ck(len(recs)==270,'numbered phases')
inv=j(R/'PARENT-INVOCATION.json');ck(inv['status']==1 and inv['seconds']==80.13514670799486,'overall status');failure=j(N/'FAILURE.json');ck(failure['error']=='host native-run artifact threshold','stop reason');ck(not(N/'RESULTS.json').exists() and not(N/'final-inspect.json').exists(),'completion unavailable')
logical=sum(p.stat().st_size for p in N.rglob('*') if p.is_file());ck(logical==274060624 and logical>268435456,'artifact overshoot')
big=[(str(p.relative_to(N)),p.stat().st_size) for p in N.rglob('*') if p.is_file() and p.stat().st_size>7000000];ck(sum(n==64689921 for _,n in big)==3 and sum(n==7498481 for _,n in big)==6,'repeated solver artifact sizes')
stop=j(N/'limit-or-failure-stop.json');cid='47b9311b0cfb478fead61c0dea4c10f41cf6082c3567f3bc889225eb160eb397';ck(stop['status']==0 and stop['argv'][-1]==cid,'stop CID');inspection=j(R/'parent-stopped-inspect.stdout')[0];ck(inspection['Id']==cid and inspection['Image']=='sha256:4a38115e6be661e04182a12c41f0e827477cf703b749a097f96344bbd56ef7b6' and not inspection['State']['Running'] and not inspection['State']['OOMKilled'] and inspection['SizeRw']==447180800,'stopped readback')
# Actual operation, binary identity, hooks and single download slot.
e=j(R/'EXPECTED.json');c=j(R/'CONTEXT.json');cmd=j(R/'COMMANDS.json');actual_rec=j(N/'138-opam-download-only.json');aa=actual_rec['argv'];opi=aa.index('/usr/bin/opam');opam_argv=aa[opi:];ck(opam_argv==cmd['actual_download_only_argv'],'exact opam actual argv');ck('OPAMDOWNLOADJOBS=1' in aa and 'OPAMWITHTEST=false' in aa and 'OPAMWITHDOC=false' in aa and '--jobs=1' in opam_argv,'jobs/filters');ck(raw('download-jobs-query')==b'1\n','current root jobs query')
for label in ['before-root-config','before-switch-config','after-vars-root-config','after-vars-switch-config','after-dry-root-config','after-dry-switch-config','after-download-root-config','after-download-switch-config']:
 b=raw(label);ck(not re.search(rb'(?m)^\s*(?:pre|post|wrap)-[a-z-]+-commands\s*:',b),'hook field')
uid=raw('uid-tools').decode().splitlines();ck(uid[:2]==['1000','1000'] and uid[2].split()[0]=='54af380ba6ca1b36305358e99427a31ae4b0af5dc5cb6d0198c6f2f16e97651d' and uid[3].split()[0]=='8f42016825a9b10fd21802a18c22d37060c95e8c5a1d2be3df5135402c6a494d','actual binary identities')
# Unchanged switch/metadata/config and installed-prefix postconditions, derived directly from framed native streams.
for label in ['before','after-vars','after-dry','after-download']:
 sw=raw(label+'-switch');ck(H(sw)==c['expected_switch_sha256'] and sw==(R/'expected-switch-state').read_bytes(),'switch exact identity');ck(hashes(raw(label+'-protected-inputs'))==e['metadata_files'],'metadata identity');ck(H(raw(label+'-root-config'))==c['original_opam_config_sha256'],'root config identity');ck(raw(label+'-switch-config')==raw('before-switch-config'),'switch config identity')
sw=raw('after-download-switch').decode();parsefield=lambda n:re.findall(r'"([^"\n]+)"',re.search(r'(?m)^'+n+r':\s*\[(.*?)\]',sw,re.S).group(1))
ck(parsefield('installed')==c['installed'] and parsefield('roots')==c['installed_roots'] and 'pin' not in sw,'53/14/0 state');ck(len(c['installed'])==53 and len(c['installed_roots'])==14,'state counts')
ck(raw('installed-prefix-before')==raw('installed-prefix-after') and raw('installed-prefix-entries-before')==raw('installed-prefix-entries-after'),'prefix unchanged')
# Exact cache/provider records, source copies and protected Git refs before and after.
for b in raws('cache-file-hashes'):
 h=hashes(b);root=next(iter(h)).split('/HEAD')[0] if False else ('/solve/offline-git-origin' if next(iter(h)).startswith('/solve/offline-git-origin/') else '/solve/opam/download-cache/git');ck({p[len(root):]:v for p,v in h.items()}==e['cache_files'],'cache file identity')
for b in raws('cache-entries'):
 es=entries(b);root='/solve/offline-git-origin' if '/solve/offline-git-origin' in es else '/solve/opam/download-cache/git';scaled={p[len(root):]:v for p,v in es.items()};ck(set(scaled)==set(e['cache_entries']),'cache entry coverage')
 for p,w in e['cache_entries'].items():
  v=scaled[p];ck(v['type']==w['type'] and v['link']==w['link'] and int(v['mode'],8)==(int(w['mode'],8)&(~0o222 if 'offline-git-origin' in root else 0o7777)) and(v['type']!='f' or v['size']==w['size']),'cache metadata')
objs={o['oid']:o for o in e['objects']};checked=[]
for t in e['trees']:
 for pkg in t['consumers']:
  prefix='/solve/opam/islaris-dry/.opam-switch/sources/'+pkg;expected={x['path']:x for x in t['entries']};pairs=list(zip(raws('source-files-'+pkg),raws('source-entries-'+pkg),raws('source-git-refs-'+pkg),raws('source-head-'+pkg)));ck(len(pairs)==2,'source before/after')
  for hb,eb,gb,sb in pairs:
   hs=hashes(hb);es=entries(eb);es.pop(prefix);relative={p[len(prefix)+1:]:v for p,v in es.items()};ck(set(relative)==set(expected),'source exact paths')
   for p,w in expected.items():
    v=relative[p]
    if w['type']=='tree':ck(v['type']=='d','source dir')
    elif w['mode']=='120000':ck(v['type']=='l' and H(v['link'].encode())==objs[w['oid']]['sha256'],'source link')
    else:ck(v['type']=='f' and hs[prefix+'/'+p]==objs[w['oid']]['sha256'] and bool(int(v['mode'],8)&0o100)==(w['mode']=='100755'),'source bytes/executable')
   git=hashes(gb);rel={p[len(prefix+'/.git'):]:v for p,v in git.items() if p in [prefix+'/.git/'+x for x in ['HEAD','config','packed-refs','objects/info/alternates','shallow']] or p.startswith(prefix+'/.git/refs/')};ck(rel==e['source_ref_files'][pkg],'source refs');ck(sb.decode().splitlines()==[t['commit'],'false'],'source HEAD/nonshallow')
  checked.append(pkg)
ck(len(checked)==21,'21 sources')
for p in N.glob('[0-9][0-9][0-9]-provider-objects.json'):ck(j(p)['objects']==[objs[k] for k in sorted(objs)],'provider complete object ledger')
for p in N.glob('[0-9][0-9][0-9]-provider.json'):ck(j(p)['objects_verified']==4935 and j(p)['raw_bodies_retained'] is False,'provider streamed object count')
# Recompute all .git bookkeeping differences, not just claimed count.
changes=[]
for pkg in checked:
 bs=hashes(raw('git-bookkeeping-before-'+pkg));af=hashes(raw('git-bookkeeping-after-'+pkg));changes += [{'path':p,'before':bs.get(p),'after':af.get(p)} for p in sorted(set(bs)|set(af)) if bs.get(p)!=af.get(p)]
changes.sort(key=lambda r:r['path']);ck(changes==j(N/'GIT-BOOKKEEPING-DELTA.json')['changes'] and len(changes)==21 and all(x['path'].endswith('/.git/FETCH_HEAD') for x in changes),'bookkeeping exact differences')
# Independent duplicate-aware JSON parser and CUDF selection/dependency audit.
def parsejson(b):
 dup=[]
 def pairs(ps):
  d={}
  for k,v in ps:
   if k in d:ck(d[k]==v,'conflicting duplicate');dup.append(k)
   d[k]=v
  return d
 return json.loads(b,object_pairs_hook=pairs),dup
def cudf(b):
 out=[]
 for block in re.split(r'\n\s*\n',b.decode()):
  row={};key=None
  for line in block.splitlines():
   if not line or line.startswith('#'):continue
   if line[0].isspace():ck(key is not None,'CUDF continuation');row[key]+=' '+line.strip()
   else:
    key,v=line.split(':',1);ck(key not in row,'duplicate CUDF field');row[key]=v.strip()
  if row:out.append(row)
 return out
ops={'=':operator.eq,'!=':operator.ne,'>':operator.gt,'<':operator.lt,'>=':operator.ge,'<=':operator.le}
def atom(x):
 m=re.fullmatch(r'([A-Za-z0-9+.%_-]+)(?:\s*(>=|<=|!=|=|<|>)\s*(\d+))?',x.strip());ck(m is not None,'unsupported CUDF atom');return m.groups()
def audit(label,actual):
 nj,dups=parsejson(raw(label+'-json'));ck(dups==['command-line'],'raw duplicate contract');cli=cmd['actual_download_only_argv' if actual else 'dry_argv'];ck(nj['command-line']==cli,'JSON argv');ck(nj['request']['action']=='install' and not nj['request'].get('remove') and not nj['request'].get('upgrade'),'native request');ck(nj.get('results')==[] if actual else ('results' not in nj or nj['results']==[]),'results semantics');ck('download-failures' not in nj and 'conflicts' not in nj,'failure field');ck(len(nj['solution'])==21 and all(set(x)=={'install'} for x in nj['solution']),'solution action');pending={x['install']['name']+'.'+x['install']['version'] for x in nj['solution']};ck(pending==set(c['pending_exact']),'pending exact21');ck(nj['request']['install']==c['roots_ordered'],'native wishes35')
 rec=cudf(raw(label+'-cudf'));rows=[r for r in rec if 'package' in r];request=[r for r in rec if 'request' in r];ck(len(request)==1,'CUDF request');full=set(c['full_exact74']);selected=[r for r in rows if r.get('opam-name','')+'.'+r.get('opam-version','') in full or r.get('opam-name')=='SWITCH_INVARIANT'];ck(len(selected)==75 and len({r['opam-name'] for r in selected})==75,'full74 plus invariant');ck({r['opam-name']+'.'+r['opam-version'] for r in rows if r.get('installed')=='true' and r['opam-name']!='SWITCH_INVARIANT'}==set(c['installed']),'installed53 CUDF');ck({r['opam-name']+'.'+r['opam-version'] for r in rows if r.get('installed-root')=='true'}==set(c['installed_roots']),'root14 CUDF');ck(all(r.get('pinned','false')=='false' for r in rows),'pins0 CUDF');ck(not any(r.get('provides') for r in selected),'provides unsupported');keys={(r['package'],int(r['version'])) for r in selected};deps=conf=0
 def match(a,exclude=None):
  n,op,v=atom(a);return any(k!=exclude and k[0]==n and(op is None or ops[op](k[1],int(v))) for k in keys)
 for r in selected:
  ck(r.get('keep','none') in ['none','package','version'],'unsupported keep')
  for clause in r.get('depends','').split(',') if r.get('depends') else []:ck(any(match(x) for x in clause.split('|')),'unsatisfied selected dependency');deps+=1
  for a in r.get('conflicts','').split(',') if r.get('conflicts') else []:ck(not match(a,(r['package'],int(r['version']))),'selected conflict');conf+=1
 req=request[0];ck(set(req)<={'request','install','remove','upgrade'} and not req.get('remove') and not req.get('upgrade'),'CUDF request schema');bykey={(r['package'],int(r['version'])):r for r in rows};root=[]
 for a in req['install'].split(','):
  n,op,v=atom(a);ck(op=='=' and match(a),'request exact root');r=bykey[(n,int(v))];root.append(r['opam-name']+'.'+r['opam-version'])
 ck(set(root)==set(c['roots_ordered']) and len(root)==35 and len(c['roots_ordered'])==35,'CUDF root wishes');ls=next(r for r in selected if r['opam-name']=='libsail');bis=next(r for r in selected if r['opam-name']=='bisect_ppx');ck(bis['package'] in [atom(a)[0] for cl in ls['depends'].split(',') for a in cl.split('|')],'libsail bisect dev dependency');ck((deps,conf)==(240,104),'dependency/conflict counts')
 return {'status':0,'duplicate_keys':dups,'native_solution_pending':len(pending),'CLI_roots':35,'normalized_wishes':len(root),'full_selected':74,'dependency_clauses':deps,'conflicts':conf,'raw_results':nj.get('results','absent')}
audits={label:audit(label,label=='download') for label in ['dry','download']}
retrieved=re.findall(r'^-> retrieved (\S+)  \(([^\n]+)\)$',raw('opam-download-only').decode(),re.M);ck(len(retrieved)==21 and len({x[0] for x in retrieved})==21 and {x[0] for x in retrieved}==set(c['pending_exact']) and all(x[1]=='no changes' for x in retrieved),'actual retrieval messages')
res={'review_status':'PASS_RAW_CLAIM_AUDIT','experiment_overall_status':1,'experiment_overall_seconds':inv['seconds'],'actual_opam_status':actual_rec['status'],'actual_opam_seconds':actual_rec['seconds'],'raw_files':len(rows),'numbered_native_phases_all_status0':len(recs),'verified_retained_stream_hashes':stream_count,'native_run_final_logical_bytes':logical,'artifact_threshold_bytes':268435456,'large_repeated_outputs':big,'stopped_CID':cid,'stopped_SizeRw':447180800,'no_OOM':True,'installed':53,'installed_roots':14,'pins':0,'actual_retrieval_messages':len(retrieved),'retrieval_messages_all_no_changes':True,'source_consumers':21,'source_trees':8,'provider_object_ledger_count':4935,'protected_metadata_files':len(e['metadata_files']),'Git_bookkeeping_changes':21,'all_changes_FETCH_HEAD':True,'cudf_audits':audits,'collection_completed':False,'scope':'Host-only independent receipt/framing/CUDF/census review; no native replay or rehash of unretained streamed object bodies.'}
(S/'CHECKS.json').write_text(json.dumps(res,indent=2)+'\n');print('PASS raw-claim audit; overall experiment remains status1')
