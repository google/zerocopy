from pathlib import Path
import json,hashlib,copy,re
E=Path('<HOST_WORKSPACE>/work/execution');S=E/'review-islaris-offline-recovery';R=E/'parent/islaris-opam-download-run-20261015';N=R/'native-run';H=lambda b:hashlib.sha256(b).hexdigest()
for r in json.loads((R/'INPUT-BINDINGS.json').read_text()):
 b=(E.parent.parent/r['path']).read_bytes();assert H(b)==r['sha256'] and len(b)==r['bytes']
for r in json.loads((R/'TRANSPORT-BASELINE.json').read_text()).values():assert H((E.parent.parent/r['path']).read_bytes())==r['sha256']
assert (R/'EXPECTED.json').read_bytes()==(E/'parent/islaris-file-transport-run-20261015/EXPECTED.json').read_bytes()
state=(N/'142-after-download-switch.stdout').read_bytes();assert H(state)==json.loads((R/'CONTEXT.json').read_text())['expected_switch_sha256']
j=json.loads((N/'139-download-json.stdout').read_text());expected=json.loads((R/'CONTEXT.json').read_text());output=(N/'138-opam-download-only.stdout').read_bytes()
def accepted(x,b):
 try:
  assert 'results' in x and x['results']==[] and 'download-failures' not in x and 'conflicts' not in x
  assert len(x['solution'])==21 and all(set(a)=={'install'} for a in x['solution'])
  assert {a['install']['name']+'.'+a['install']['version'] for a in x['solution']}==set(expected['pending_exact'])
  lines=[line for line in b.decode().splitlines() if 'retrieved' in line];messages=[re.fullmatch(r'-> retrieved (\S+)  \((.*)\)',line) for line in lines]
  assert all(messages);pkgs=[m[1] for m in messages];assert len(pkgs)==len(set(pkgs))==21 and set(pkgs)==set(expected['pending_exact'])
  return True
 except (AssertionError,KeyError,TypeError):return False
controls={'positive_actual':accepted(j,output)}
for name,mut in [('missing_results',lambda a:a.pop('results')),('invented_Fetch_results',lambda a:a.update(results=[{'action':{'fetch':{'name':'sail','version':'0.17'}},'result':'OK'}])),('present_failure',lambda a:a.update(**{'download-failures':[]})),('extra_solution_action',lambda a:a['solution'].append({'remove':{'name':'coq','version':'8.19.0'}})),('changed_pending_version',lambda a:a['solution'][0]['install'].update(version='wrong'))]:
 a=copy.deepcopy(j);mut(a);controls[name+'_rejected']=not accepted(a,output)
lines=output.splitlines(keepends=True);idx=next(i for i,l in enumerate(lines) if l.startswith(b'-> retrieved '));controls['missing_retrieval_rejected']=not accepted(j,b''.join(lines[:idx]+lines[idx+1:]));controls['duplicate_retrieval_rejected']=not accepted(j,output+lines[idx]);controls['extra_retrieval_rejected']=not accepted(j,output+b'-> retrieved spurious.1  (no changes)\n')
assert all(controls.values())
(S/'CONTROLS.json').write_text(json.dumps({'status':'PASS','accepted_transport_expectations_byte_identical':True,'input_and_baseline_bindings_match':True,'negative_controls':controls,'primary_source_review':'Download-only removes Build/Install/Change/Reinstall/Remove vertices; Fetch not serialized in results; session hooks possible; separate download slot used. Source revision and actual executable/version are separately bound, no build provenance asserted.'},indent=2)+'\n');print('PASS controls and accepted-transport lineage')
