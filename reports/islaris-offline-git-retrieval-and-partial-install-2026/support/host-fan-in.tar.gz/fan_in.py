import pathlib,json,hashlib,importlib.util,re,sys
B=pathlib.Path('work/execution');R=B/'parent/islaris-opam-download-run-20261015';N=R/'native-run';OUT=B/'sail-proof-design/offline-recovery-analysis'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def check(x,msg):
 if not x:raise AssertionError(msg)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
h=module('bound_helper',R/'transport_helpers.py');a=module('bound_audit',R/'audit_download.py');e=load(R/'EXPECTED.json');c=load(R/'CONTEXT.json')
for row in load(R/'MANIFEST.json')['files']:
 b=(R/row['path']).read_bytes();check(len(b)==row['bytes']and sha(b)==row['sha256'],'copied frozen input '+row['path'])
receipts={};streams=0
for p in sorted(N.glob('*.json')):
 j=load(p)
 if 'argv' not in j or 'status'not in j:continue
 check(j['status']==0,'nonzero recorded native phase '+p.name)
 if re.match(r'^\d{3}-',p.name):
  stem=p.name.removesuffix('-artifact-stop.json').removesuffix('.json');label=stem[4:];receipts[label]=(stem,j)
  for suffix,key in [('.stdout','stdout'),('.stderr','stderr')]:
   f=N/(stem+suffix)
   if key+'_sha256'in j:check(sha(f.read_bytes())==j[key+'_sha256'],'stream digest '+f.name);streams+=1
   if key+'_bytes'in j:check(f.stat().st_size==j[key+'_bytes'],'stream size '+f.name)
def data(label):return(N/(receipts[label][0]+'.stdout')).read_bytes()
check(len(receipts)==270,'native phase count')
check(load(R/'PARENT-INVOCATION.json')['status']==1,'overall status')
check(load(N/'FAILURE.json')['error']=='host native-run artifact threshold','stop reason')
check(load(N/'limit-or-failure-stop.json')['status']==0,'stop status')
check(not(N/'RESULTS.json').exists(),'unexpected full-gate success')
for label,prefix,actual in [('opam-dry-download-solve','dry',False),('opam-download-only','download',True)]:
 argv=receipts[label][1]['argv'];start=argv.index('/usr/bin/opam');native_argv=argv[start:]
 got=a.audit(data(prefix+'-json'),data(prefix+'-cudf'),c,native_argv,actual,data(label)if actual else None)
 check(got==load(N/('DOWNLOAD-GATE.json'if actual else 'DRY-GATE.json')),'replayed exported selection audit')
check(data('download-jobs-query')==b'1\n','download slots')
for suffix in ['switch','root-config','switch-config']:
 ref=data('before-'+suffix)
 for moment in ['after-vars','after-dry','after-download']:check(data(moment+'-'+suffix)==ref,'state/config '+moment+suffix)
check(sha(data('before-switch'))==c['expected_switch_sha256'],'state binding')
a.no_hooks(data('before-root-config'),data('before-switch-config'))
for moment in ['before','after-vars','after-dry','after-download']:
 check(h.parse_hashes(data(moment+'-protected-inputs'))==e['metadata_files'],'protected metadata '+moment)
check(data('installed-prefix-before')==data('installed-prefix-after'),'installed hashes')
check(data('installed-prefix-entries-before')==data('installed-prefix-entries-after'),'installed entries')
sourcefiles=sourceentries=0
for t in e['trees']:
 exp={x['path']:x for x in t['entries']};objects={o['oid']:o for o in e['objects']}
 for pkg in t['consumers']:
  label='source-files-'+pkg;stems=sorted(p.name[:-len('.stdout')]for p in N.glob('[0-9]*-'+label+'.stdout'));check(len(stems)==2,'source passes')
  for stem in stems:
   hashes=h.parse_hashes((N/(stem+'.stdout')).read_bytes());entlabel=stem[:4]+'source-entries-'+pkg
   # Entries phase follows file phase, so locate by phase sequence +1.
   entstem='%03d-source-entries-%s'%(int(stem[:3])+1,pkg)
   entries=h.parse_entries((N/(entstem+'.stdout')).read_bytes());root='/solve/opam/islaris-dry/.opam-switch/sources/'+pkg;entries.pop(root);actual={k[len(root)+1:]:v for k,v in entries.items()};check(set(actual)==set(exp),'tree coverage')
   for path,w in exp.items():
    got=actual[path]
    if w['type']=='tree':check(got['type']=='d','dir')
    elif w['mode']=='120000':check(got['type']=='l'and sha(got['link'].encode())==objects[w['oid']]['sha256'],'symlink')
    else:check(got['type']=='f'and hashes[root+'/'+path]==objects[w['oid']]['sha256']and bool(int(got['mode'],8)&0o100)==(w['mode']=='100755'),'file')
   sourcefiles+=len(hashes);sourceentries+=len(actual)
  # Protected refs and actual HEAD assertions are represented twice in recorded commands/streams.
  refs=sorted(N.glob('[0-9]*-source-git-refs-'+pkg+'.stdout'))
  for f in refs:
   d=h.parse_hashes(f.read_bytes());p=root+'/.git';got={k[len(p):]:v for k,v in d.items()if k in[p+'/HEAD',p+'/config',p+'/packed-refs',p+'/objects/info/alternates',p+'/shallow']or k.startswith(p+'/refs/')};check(got==e['source_ref_files'][pkg],'protected ref identity')
  for f in N.glob('[0-9]*-source-head-'+pkg+'.stdout'):check(f.read_bytes().decode().splitlines()==[t['commit'],'false'],'head/nonshallow')
# Provider streamed body ledgers were verified natively by the controller; this fan-in checks their complete expected correspondence, not a second native body stream.
ledgers=sorted(N.glob('[0-9]*-provider-objects.json'));check(len(ledgers)==2,'provider twice')
for f in ledgers:check(load(f)['objects']==sorted(e['objects'],key=lambda x:x['oid']),'provider object correspondence')
delta=load(N/'GIT-BOOKKEEPING-DELTA.json')['changes'];check(len(delta)==21 and all(x['path'].endswith('/.git/FETCH_HEAD')for x in delta),'bookkeeping delta')
inspects=[]
for f in sorted(N.glob('*inspect.stdout'))+sorted(N.glob('monitor-*.stdout')):
 j=json.loads(f.read_bytes())[0];check(j['Id']==h.CID and j['Image']==h.IMAGE and j['HostConfig']['NetworkMode']=='none'and not j['State']['OOMKilled'],'inspection identity');inspects.append(dict(path=f.name,size_rw=j['SizeRw'],running=j['State']['Running'],oom=j['State']['OOMKilled']))
large=[]
for f in sorted(N.rglob('*')):
 if f.is_file()and f.stat().st_size>=7000000:large.append(dict(path=f.relative_to(N).as_posix(),bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
initial=a.raw_json((B/'islaris-offline-build-20261015/native-install-result.json').read_bytes())[0]
ok=[]
for r in initial['results']:
 if set(r['action'])=={'install'}and r['result']=='OK':p=r['action']['install'];ok.append(p['name']+'.'+p['version'])
check(len(ok)==53 and set(ok)==set(c['installed']),'original OK53 versus later state')
check(set(initial['download-failures'])==set(c['pending_exact']),'original failures21')
result=dict(verdict='PASS_HOST_FAN_IN_OF_PARTIAL_OPERATIONAL_OUTCOME',overall_exit=1,overall_seconds=load(R/'PARENT-INVOCATION.json')['seconds'],full_gate_success=False,dry_seconds=receipts['opam-dry-download-solve'][1]['seconds'],actual_download_seconds=receipts['opam-download-only'][1]['seconds'],native_phase_receipts=270,native_phase_statuses_all_zero=True,stream_digests_rehashed=streams,installed53_matches_initial_OK_actions=True,roots14_and_pins0_unchanged=True,protected_metadata_files=19429,source_consumers_checked_twice=21,source_file_hash_comparisons=sourcefiles,source_entry_comparisons=sourceentries,provider_objects_per_pass=4935,provider_ledger_passes=2,provider_raw_body_restreamed_by_fan_in=False,installed_prefix_hash_count=len(h.parse_hashes(data('installed-prefix-before'))),git_bookkeeping_changes=21,git_changes_only_FETCH_HEAD=True,download_outcome=load(N/'DOWNLOAD-GATE.json')['download_outcome'],large_payloads=large,runtime_observations=inspects,artifact_threshold=268435456,artifact_stop_phase='270-copy-output-download.dot',scope='Independent host receipt/hash/formula/tree-ledger review; no new native operation or proof/build claim. Native streamed bodies are bound by preserved controller receipts and ledgers, not re-streamed by this review.')
(OUT/'FAN-IN.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in['download_outcome','large_payloads','runtime_observations']},indent=2))
