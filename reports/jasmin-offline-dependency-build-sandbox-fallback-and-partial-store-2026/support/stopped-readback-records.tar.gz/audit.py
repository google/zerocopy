"""Host stdlib-only stopped-snapshot metadata audit; never executes archive contents."""
from pathlib import Path, PurePosixPath
import datetime, hashlib, json, sqlite3, tarfile
ROOT = Path(__file__).resolve().parent
BASE = ROOT.parents[1]
INPUT = BASE / 'parent/jasmin-stopped-readback-20261015'
TARGETS = ROOT.parent / 'offline-home-analysis/target-18-attrs.json'
def sha(b): return hashlib.sha256(b).hexdigest()
def put(n,j): (ROOT/n).write_text(json.dumps(j,indent=2)+'\n')
def stamp(t): return datetime.datetime.fromtimestamp(t,datetime.timezone.utc).isoformat()
copies=json.loads((INPUT/'copies.json').read_text())
identity=json.loads((INPUT/'identity-gate.json').read_text())
ci=identity['containers'][0]
assert ci['id']=='5444ba00b8675ccd8ad2d5a55c01b6b88785e06642e6e0e5ac7f459e31a46fd5'
assert not ci['running'] and ci['networks']=={} and ci['capdrop']==['ALL']
censuses={}; inputs=[]
for name in ['jasmin-home','jasmin-store-db']:
 p=INPUT/(name+'.tar'); b=p.read_bytes(); receipt=next(x for x in copies if x['name']==name)
 assert receipt['status']==0 and receipt['sha256']==sha(b) and receipt['bytes']==len(b)
 inputs.append({'name':p.name,'bytes':len(b),'sha256':sha(b)})
 rows=[]
 with tarfile.open(p) as tf:
  seen=set()
  for m in tf:
   q=PurePosixPath(m.name)
   assert not q.is_absolute() and '..' not in q.parts and m.name not in seen
   seen.add(m.name)
   assert m.isdir() or m.isfile(), 'Reject all links/devices/special members'
   data=tf.extractfile(m).read() if m.isfile() else None
   rows.append({'name':m.name,'kind':'file' if m.isfile() else 'directory','bytes':m.size,
    'mode':oct(m.mode),'uid':m.uid,'gid':m.gid,'uname':m.uname,'gname':m.gname,
    'mtime':m.mtime,'mtime_utc':stamp(m.mtime),'sha256':sha(data) if data is not None else None,
    'pax_headers':m.pax_headers})
   if name=='jasmin-store-db' and m.name in ['db/db.sqlite','db/db.sqlite-shm','db/db.sqlite-wal','db/schema']:
    dest=ROOT/'snapshot-db'/q.name
    assert dest.is_file() and dest.read_bytes()==data, 'extracted snapshot mismatch'
  censuses[name]=rows
assert all(x['kind']=='directory' for x in censuses['jasmin-home'])
assert (ROOT/'snapshot-db/db.sqlite-wal').stat().st_size==0
# No pending WAL frames: immutable=1 reads the copied main DB without journal writes.
pre={p.name:sha(p.read_bytes()) for p in (ROOT/'snapshot-db').iterdir()}
c=sqlite3.connect((ROOT/'snapshot-db/db.sqlite').as_uri()+'?mode=ro&immutable=1',uri=True)
c.row_factory=sqlite3.Row
c.execute('PRAGMA query_only=ON')
assert c.execute('PRAGMA integrity_check').fetchall()[0][0]=='ok'
def query(sql,args=()): return [dict(r) for r in c.execute(sql,args)]
targets=json.loads(TARGETS.read_text()); assert len(targets)==18
results=[]
for d in targets:
 drv=query('SELECT * FROM ValidPaths WHERE path=?',(d['drv'],));assert len(drv)==1
 mappings=query('SELECT id,path FROM DerivationOutputs WHERE drv=? ORDER BY id',(drv[0]['id'],))
 for output, desc in d['outputs'].items():
  path=desc['path']; path=path if path.startswith('/nix/store/') else '/nix/store/'+path
  assert any(r['id']==output and r['path']==path for r in mappings)
  rows=query('SELECT * FROM ValidPaths WHERE path=?',(path,));assert len(rows)<=1
  refs=query('SELECT v.path FROM Refs r JOIN ValidPaths v ON v.id=r.reference WHERE r.referrer=? ORDER BY v.path',(rows[0]['id'],)) if rows else []
  results.append({'drv':d['drv'],'name':d['name'],'output':output,'path':path,
    'drv_validpath':drv[0],'derivation_output_mappings':mappings,'registered':bool(rows),
    'validpath':rows[0] if rows else None,'references':[r['path'] for r in refs],
    'registration_utc':stamp(rows[0]['registrationTime']) if rows else None})
assert len(results)==19
schema=query("SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name")
summary={'inputs':inputs,'target_derivations':len(targets),'named_output_paths':len(results),
 'registered_output_count':sum(r['registered'] for r in results),
 'absent_output_count':sum(not r['registered'] for r in results),
 'validpath_count':c.execute('SELECT count(*) FROM ValidPaths').fetchone()[0],
 'integrity_check':'ok','wal_bytes':0,'read_mode':'mode=ro&immutable=1; PRAGMA query_only=ON',
 'schema':schema,'home_directory_count':len(censuses['jasmin-home']),
 'home_regular_file_count':0,'limits':'Database metadata only; no independent NAR-content verification, package execution, or theorem replay.'}
c.close()
assert pre=={p.name:sha(p.read_bytes()) for p in (ROOT/'snapshot-db').iterdir()}
put('archive-censuses.json',censuses);put('target-output-census.json',results);put('SUMMARY.json',summary)
put('input-bindings.json',{'snapshots':inputs,'other_inputs':[{'name':str(p.relative_to(BASE)), 'bytes':len(p.read_bytes()),'sha256':sha(p.read_bytes())} for p in [INPUT/'identity-gate.json',INPUT/'copies.json',TARGETS]]})
print(json.dumps({k:v for k,v in summary.items() if k not in ['schema','inputs']},indent=2))
for r in results:
 if r['registered']: print(json.dumps(r,indent=2))
