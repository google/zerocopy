# Stopped Jasmin HOME and store snapshot audit

The stopped-container snapshots establish one registered target output: EasyCrypt 2026.09. The remaining 18 named output paths are absent from the snapshot's ValidPaths table. This is a census of 18 derivations / 19 named output paths, including both Apron dev and out. All 18 derivations themselves are registered and each expected output mapping agrees with DerivationOutputs. See [complete target census](target-output-census.json), [archive metadata](archive-censuses.json), [input bindings](input-bindings.json), and [audit summary](SUMMARY.json).

## Identity and method

Parent's identity observation binds the stopped, non-OOM Jasmin container 5444ba00b8675ccd8ad2d5a55c01b6b88785e06642e6e0e5ac7f459e31a46fd5 to image sha256:71f0139a696ef851a52bebc0b8facfd20e728e0b92f7b0251480979614e24558. Networks={} (detached; HostConfig remains bridge), capdrop ALL and no-new-privileges are observed. Parent copied the two tar snapshots without starting a native program. This audit performed only host Python standard-library operations; no Docker/native/target/package code ran.

Each archive's bytes/hash matches the successful parent copy receipt: HOME 6,656B SHA256 831ca5a8c240ae07c85147e43377c0789b673a09f1d73bf44640577c72f54856; DB 10,462,208B SHA256 7e3667920dc4efa75bc012a4aa0884da85bb927465e10ef2880a2e0360555034. All member paths were checked for absolute paths, traversal, duplicates, and unexpected links/special types. Only exactly selected regular files db.sqlite, db.sqlite-shm, db.sqlite-wal and schema were manually copied into the private snapshot-db directory; no tar extract/extractall or archive code execution was used. The complete HOME census is read directly from its archive, with no extraction necessary.

The copied main SQLite file is 2,035,712B, SHA256 157b596bc074077e6046df576eb4f0798bd07a000a760cda75d489a9f69bccdc. WAL is empty; SHM is retained alongside it. Thus no WAL transactions need replay. The audit uses mode=ro&immutable=1 and query_only=ON; integrity_check returns ok. All copied database-file hashes remain unchanged after querying. The snapshot contains 2,335 ValidPaths entries. SQLite integrity is structural database evidence, not verification of registered filesystem objects.

## HOME observations and causal limit

HOME contains 11 directories and no regular files, symlinks or other objects. The complete hierarchy is homeless-shelter/.cache/dune/db with files/v4, meta/v5, temp, and values/v3 below db. Every directory is mode0755, uid0/gid0, timestamp 2026-10-15T15:38:43+00:00 (mtime; not creation time). No payload bytes or cache records remain in this snapshot.

The Dune-specific layout, the prior observed `dune build --profile=dev`, and timing are consistent with Dune-cache initialization during EasyCrypt's builder. This strengthens the earlier hypothesis but does not identify the process/syscall that created HOME. Names and directory mtimes alone cannot establish that attribution. The earlier source-backed unsandboxed-local-builder diagnosis remains; this snapshot neither observes the failed namespace syscall nor changes sandbox policy. No cleanup or retry occurred.

## Registered output and absent targets

EasyCrypt's expected output /nix/store/6pd3q95qxhypqqrgaiqb6wwc9g0l2609-easycrypt-2026.09 is registered at 2026-10-15T15:39:02+00:00 with the expected deriver /nix/store/bgcg6yj56vad1qvz7z8xwpvff7s0668z-easycrypt-2026.09.drv. Its recorded NAR size is 57,956,152B and stored hash is sha256:5da60afaf1c45459837decd6ce3675be732c45f2d750013a144e0ffac5f50f57. There are 18 recorded references, including self, Why3, OCaml5.4.1 libraries, Bash, libc and Python; the census preserves every exact reference. ultimate=1, signatures=null, ca=null are preserved as metadata, not a signature or independent content-verification claim.

The other 18 output paths (17 derivations, Apron having two outputs) have no ValidPaths entries. Absence means not registered valid in this snapshot; it does not establish physical nonexistence or exclude partial files. The snapshot corroborates EasyCrypt's completed registration after build/fixup, not complete success of the overall failed invocation. It does not identify which next derivation was rejected before opening its builder log. No Coq/EasyCrypt theorem replay or compiler correctness claim follows from successful dependency compilation.

## Minimal remaining observations and recovery boundary

The output-registration census and HOME tree are now resolved; no further observation is needed for those two questions. Identifying the rejected next derivation would require retained goal/debug logs or the retained nix-1093-3578735763 directory's metadata/environment, if available; absence of such evidence should remain an explicit unknown. Exact historical HOME-creator attribution would require existing process/syscall evidence; do not rerun packages merely to create it. Independently validating EasyCrypt output contents would require a separately authorized local NAR-content verification of that exact registered path; this host-only audit does not perform it.

Before any package continuation, the previous analysis's fresh-owned-output probe with sandbox=true and sandbox-fallback=false remains the proposed isolation gate. Reusing an already-valid probe would not test builder startup. These findings grant no start, build, cleanup, capability, network, or native-query action. Preserve the failed subject and HOME evidence.

## Reproduction and retention

[audit.py](audit.py) preserves exact host query logic; [receipt](audit-receipt.json), [stdout](audit.stdout) and [stderr](audit.stderr) retain the actual run. It uses the parent snapshot paths bound in input-bindings.json and the frozen prior exact target attrs; keep those inputs at their recorded locations or adjust only input paths in a separately recorded replay wrapper. The initial extraction is described above; preextracted snapshot bytes are checked against exact archive members on every run. The complete selected SQLite/SHM/WAL/schema copies are retained privately for audit. An eventual report should retain snapshot hashes, member census, query checker and compact results rather than duplicate the full database or reserved allocation file. The prior frozen offline-home-analysis and prebuild report were not edited.
