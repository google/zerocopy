"""Source/metadata materialization only; no opam or network execution."""
import hashlib, json, pathlib, re

ROOT = pathlib.Path(__file__).resolve().parent
WORK = ROOT.parents[2]
SUPPORT = WORK / 'reference-candidate/reports/islaris-logical-dependency-pins-and-offline-solve-gate-2026/support'
MAIN = WORK / 'execution/cross-foundation-runtime/sources/opam-metadata'
assert ROOT.name == 'islaris-solver-inputs' and ROOT.parent.name == 'sail-proof-design'

def save(path, data):
    path = ROOT / path
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, str): data = data.encode()
    path.write_bytes(data)
    return path.relative_to(ROOT).as_posix()

def jwrite(path, data):
    return save(path, json.dumps(data, indent=2, ensure_ascii=False) + '\n')

def ids(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                git_blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())

records = json.loads((SUPPORT/'ISLARIS-primary-files.json').read_text())
jwrite('primary/retained-31-records.json', records)
coordinates = []
for i,r in enumerate(records):
    if r['text'] is None: continue
    data = r['text'].encode()
    if r.get('reported_git_blob'): assert ids(data)['git_blob'] == r['reported_git_blob']
    retained = save(f'primary/retained/{i:02d}-{pathlib.Path(r["path"]).name}', data)
    coordinates.append(dict(record=i, repository=r['owner']+'/'+r['repo'], revision=r['sha'],
                            upstream_path=r['path'], retained=retained, **ids(data)))

new = json.loads((ROOT/'primary/new-sail-responses.json').read_text())
docs = json.loads((ROOT/'primary/opam-tool-responses.json').read_text())
for r in new + docs:
    data=r['content'].encode(); assert ids(data)['git_blob']==r['sha']
    url=r['display_url']; repository,revision,path=url.split('/blob/')[0].removeprefix('https://github.com/'),*url.split('/blob/')[1].split('/',1)
    retained=save('primary/fetched/'+repository.replace('/','--')+'--'+path.replace('/','--'),data)
    coordinates.append(dict(repository=repository,revision=revision,upstream_path=path,retained=retained,**ids(data)))

entries=[]
def package(name,version,text,origin,source_url=None):
    original=text.encode(); derived=text
    if source_url:
        assert not re.search(r'^url\s*\{',text,re.M)
        derived += '\n# Local overlay: immutable source URL added; upstream formulas unchanged.\nurl { src: "'+source_url+'" }\n'
    target=f'repository/packages/{name}/{name}.{version}/opam'
    save(target,derived)
    entries.append(dict(package=name,version=version,path=target,origin=origin,
                        original=ids(original),materialized=ids(derived.encode()),
                        adaptation='append immutable url section only' if source_url else 'byte-identical upstream metadata',
                        added_source_url=source_url))

for i in [0,1,2,3,4,5,7,24,25,26,27,28,29]:
    r=records[i]; nv=r['path'].split('/')[-2]; name=r['path'].split('/')[-3]
    package(name,nv[len(name)+1:],r['text'],{'record':i,'url':r['url'],'git_blob':r['reported_git_blob']})
for i in [6,9,13,8,30]:
    r=records[i]; name=pathlib.Path(r['path']).stem; version='0.17' if i in [6,9,13] else 'dev'
    package(name,version,r['text'],{'record':i,'url':r.get('url','https://github.com/'+r['owner']+'/'+r['repo']+'/blob/'+r['sha']+'/'+r['path']),'git_blob':r['reported_git_blob']},
            'git+https://github.com/'+r['owner']+'/'+r['repo']+'.git#'+r['sha'])
for r in new:
    name=pathlib.Path(r['display_title']).stem
    package(name,'0.17',r['content'],{'url':r['display_url'],'git_blob':r['sha']},
            'git+https://github.com/rems-project/sail.git#b14f649845db850b3673696e2aa90565fa2a60ef')
fragments=json.loads((SUPPORT/'upstream-fragments-manifest.json').read_text())
for r in fragments:
    if r['path'] not in ['coq-sail.opam','coq-sail-riscv.opam']: continue
    data=(SUPPORT.parent/r['retained']).read_bytes(); assert ids(data)['sha256']==r['upstream_sha256']; assert ids(data)['git_blob']==r['upstream_git_blob']
    retained=save('primary/'+r['path'],data)
    coordinates.append(dict(repository=r['repository'],revision=r['revision'],upstream_path=r['path'],retained=retained,**ids(data)))
    name=pathlib.Path(r['path']).stem
    package(name,'0.17' if name=='coq-sail' else '0.5',data.decode(),r,
            'git+https://github.com/'+r['repository']+'.git#'+r['revision'])
assert len(entries)==29 and len({(r['package'],r['version']) for r in entries})==29
save('repository/repo','opam-version: "2.0"\n')
jwrite('package-origins.json',entries); jwrite('primary-identities.json',coordinates)
request=json.loads((SUPPORT/'root-requests.json').read_text())
save('primary/published-root-requests.json',(SUPPORT/'root-requests.json').read_bytes())
requests=[r if r!='ocaml-option-flambda' else 'ocaml-option-flambda.1' for r in request['requests']]
assert (MAIN/'packages/ocaml-option-flambda/ocaml-option-flambda.1/opam').is_file()
jwrite('root-requests.json',dict(role='exact proposed requests, not a solved lock',requests=requests,
    change_from_published='ocaml-option-flambda fixed to version 1 in immutable main snapshot',
    main_revision='56aefa37456aa263913289a4174daca01c4b9339',
    mode='repository entries, no source pins; tests/docs disabled; dev determined by URLs'))
save('root-requests.txt','\n'.join(requests)+'\n')
main_manifest=[]
for p in sorted(MAIN.rglob('*')):
    if p.is_file(): main_manifest.append(dict(path=p.relative_to(MAIN).as_posix(),**ids(p.read_bytes())))
jwrite('main-repository-files.json',dict(revision='56aefa37456aa263913289a4174daca01c4b9339',files=main_manifest))
print(json.dumps(dict(overlay_packages=len(entries),requests=len(requests),main_files=len(main_manifest),
                     fetched_files=len(new)+len(docs),fetched_text_bytes=sum(len(r['content'].encode()) for r in new+docs))))
