set -eu
du -sb /solve/opam
du -sb /solve/opam/download-cache
du -sb /solve/opam/islaris-dry/.opam-switch/sources
du -sB1 /solve/opam
du -sB1 /solve/opam/download-cache
du -sB1 /solve/opam/islaris-dry/.opam-switch/sources
find /solve/opam/islaris-dry/.opam-switch -maxdepth 2 -not -path '*/sources/*' -printf '%y %s %p\n'
find /solve/opam/islaris-dry/bin /solve/opam/islaris-dry/.opam-switch/build /solve/opam/islaris-dry/.opam-switch/install -mindepth 1 -printf '%y %p\n'
sha256sum /usr/bin/git /usr/bin/opam
tar -C /audit -cf /audit/git-final-receipts.tar git
cat /audit/git-final-receipts.tar
