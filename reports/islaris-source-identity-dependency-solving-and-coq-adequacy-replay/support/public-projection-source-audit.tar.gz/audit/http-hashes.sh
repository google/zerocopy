set -eu
find /solve/opam/download-cache/md5 /solve/opam/download-cache/sha256 /solve/opam/download-cache/sha512 -type f -exec sha512sum -z '{}' + > /audit/http.sha512z
cat /audit/http.sha512z
