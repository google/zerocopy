set -eu
export GIT_OPTIONAL_LOCKS=0 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
{ printf "%s\n" 169934e27ceafe393ed4d365985f7b12d974d56e e099866d6eaefae796e59c6d0ca3fc77df53a003; git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail.0.17 ls-tree -r -t --format="%(objectname)" 169934e27ceafe393ed4d365985f7b12d974d56e; } | sort -u > /audit/git/A40/objects
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail.0.17 cat-file --batch < /audit/git/A40/objects
