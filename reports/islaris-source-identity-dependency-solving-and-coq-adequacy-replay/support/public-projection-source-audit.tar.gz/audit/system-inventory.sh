set -eu
printf '%s\n' 'PATH lookup (no Z3 execution):'
command -v z3 || true
printf '%s\n' 'Named executable inventory (no execution):'
find /usr/bin /usr/local/bin /bin -maxdepth 1 -iname '*z3*' -printf '%y %m %s %p %l\n'
printf '%s\n' 'Selected installed-system package records:'
awk 'BEGIN {RS="";FS="\n"} $1 ~ /^Package: (z3|libz3[^ ]*|build-essential|gcc|gcc-12|g[+][+]|g[+][+]-12|make|pkg-config|pkgconf|findutils|libgmp-dev|linux-libc-dev|zlib1g-dev|m4|patch|git|libc6-dev|binutils|ocaml|ocaml-base)$/ {print $0 "\n"}' /var/lib/dpkg/status
