set -eu
export GIT_OPTIONAL_LOCKS=0 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
{ printf "%s\n" a1a12e00fba07f2e41ccd74a8b593b88e48fc2c3 4fde093e8d6ac349c811e852bf381d555d285958; git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-stdpp.dev.2024-09-10.3.a1a12e00 ls-tree -r -t --format="%(objectname)" a1a12e00fba07f2e41ccd74a8b593b88e48fc2c3; } | sort -u > /audit/git/A36/objects
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-stdpp.dev.2024-09-10.3.a1a12e00 cat-file --batch < /audit/git/A36/objects
