set -eu
export GIT_OPTIONAL_LOCKS=0 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
{ printf "%s\n" 7945a29d1647970709a9b5ad2ffc53c757e130cc 115f2f11d456f11b603c571ff0426793ae69ecbd; git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-lithium.dev.2024-09-11.0.7945a29d ls-tree -r -t --format="%(objectname)" 7945a29d1647970709a9b5ad2ffc53c757e130cc; } | sort -u > /audit/git/A41/objects
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-lithium.dev.2024-09-11.0.7945a29d cat-file --batch < /audit/git/A41/objects
