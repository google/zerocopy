set -eu
find /solve/opam /owned-inputs -type f -exec sha256sum -z '{}' + > /audit/all-files-after.sha256z
cat /audit/all-files-after.sha256z
