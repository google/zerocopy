set -eu
id
for t in python3 python git find sha256sum sha512sum stat sort du tar; do command -v "$t" || true; done
find /solve/opam -maxdepth 3 -printf '%y %m %u %g %s %p\n'
find /owned-inputs -maxdepth 1 -printf '%y %m %u %g %s %p\n'
stat -c '%a %u %g' /audit
