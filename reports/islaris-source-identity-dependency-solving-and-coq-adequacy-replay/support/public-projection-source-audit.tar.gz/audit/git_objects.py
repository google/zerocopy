import pathlib,json,subprocess,hashlib,shlex,time,re
ROOT=pathlib.Path(__file__).resolve().parent
CID='942f3767a54df1f9f327fd17706f007e09c73e4088b8c272063cc20863c0b2a8'
x=json.loads((ROOT/'inputs.json').read_text());trees=json.loads((ROOT/'git-tree-inventory.json').read_text())
art={a['id']:a for a in x['artifacts']['artifacts']};results=[]
inspection=subprocess.check_output(['docker','inspect',CID]);(ROOT/'objects-inspect.stdout').write_bytes(inspection);i=json.loads(inspection)[0]
if i['Image']!='sha256:1189d6a4a06d068d675121d121999a7a8d3afa35e6d922ee41a0679fc98876ce' or i['HostConfig']['NetworkMode']!='none' or i['Mounts']:raise ValueError('isolation changed')
for tree in trees:
 aid=tree['id'];src='/solve/opam/islaris-dry/.opam-switch/sources/'+art[aid]['consumers'][0]['package'];base='/audit/git/'+aid
 g='git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C '+shlex.quote(src)
 script='set -eu\nexport GIT_OPTIONAL_LOCKS=0 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null\n{ printf "%s\\n" '+tree['commit']+' '+tree['tree']+'; '+g+' ls-tree -r -t --format="%(objectname)" '+tree['commit']+'; } | sort -u > '+base+'/objects\n'+g+' cat-file --batch < '+base+'/objects\n'
 (ROOT/(aid+'-objects.sh')).write_text(script)
 argv=['docker','exec','--user=1000:1000',CID,'/bin/sh','-c',script];started=time.monotonic();rawhash=hashlib.sha256();total=0;rows=[]
 retain={e['oid']:e['path'] for e in tree['entries'] if e['type']=='blob' and (e['path'] in ['INSTALL.md','README.md','Makefile','.gitmodules'] or re.search(r'^src/.*(?:smt|constraint|solver).*\.(?:ml|mli)$',e['path']))}
 with (ROOT/(aid+'-objects.stderr')).open('wb') as err:
  proc=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=err)
  while True:
   line=proc.stdout.readline()
   if not line:break
   rawhash.update(line);total+=len(line);parts=line.rstrip(b'\n').split()
   if len(parts)!=3:raise RuntimeError('invalid/missing Git object header '+repr(line))
   oid,typ,size=parts;size=int(size);h1=hashlib.sha1(typ+b' '+str(size).encode()+b'\0');h256=hashlib.sha256();left=size;body=[] if oid.decode() in retain else None
   while left:
    b=proc.stdout.read(min(left,65536))
    if not b:raise RuntimeError('short Git object')
    h1.update(b);h256.update(b);rawhash.update(b);total+=len(b);left-=len(b)
    if body is not None:body.append(b)
   newline=proc.stdout.read(1);rawhash.update(newline);total+=1
   if newline!=b'\n' or h1.hexdigest()!=oid.decode():raise RuntimeError('Git object hash/protocol mismatch '+oid.decode())
   rows.append({'oid':oid.decode(),'type':typ.decode(),'bytes':size,'sha256':h256.hexdigest()})
   if body is not None:
    path=ROOT/'inspected-source'/aid/retain[oid.decode()];path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b''.join(body))
  status=proc.wait(timeout=120)
 if status:raise RuntimeError('cat-file failed '+aid+' '+str(status))
 expected={e['oid'] for e in tree['entries']}|{tree['commit'],tree['tree']}
 if {r['oid'] for r in rows}!=expected:raise RuntimeError('Git object coverage mismatch '+aid)
 result={'id':aid,'argv':argv[:-1]+['<exact '+aid+'-objects.sh>'],'status':status,'seconds':time.monotonic()-started,'stdout_bytes':total,'stdout_sha256':rawhash.hexdigest(),'object_count':len(rows),'objects':rows,'raw_blob_stream':'streamed into independent SHA1/SHA256 hashes; not retained as a full dump'}
 (ROOT/(aid+'-objects.json')).write_text(json.dumps(result,indent=2)+'\n');results.append({k:v for k,v in result.items() if k!='objects'});print(aid,len(rows),round(result['seconds'],3),flush=True)
(ROOT/'git-objects-summary.json').write_text(json.dumps(results,indent=2)+'\n')
