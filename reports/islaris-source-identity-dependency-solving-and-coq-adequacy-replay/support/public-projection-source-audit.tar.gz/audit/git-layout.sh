set -eu
export GIT_OPTIONAL_LOCKS=0 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
mkdir /audit/git
mkdir /audit/git/A17
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/sail_manifest.0.17 rev-parse HEAD > /audit/git/A17/head
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/sail_manifest.0.17 rev-parse --is-shallow-repository > /audit/git/A17/shallow
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/sail_manifest.0.17 cat-file commit b14f649845db850b3673696e2aa90565fa2a60ef > /audit/git/A17/commit
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/sail_manifest.0.17 ls-tree -r -t -z --full-tree b14f649845db850b3673696e2aa90565fa2a60ef > /audit/git/A17/tree.z
printf "%s\n" 'A17 sail_manifest.0.17'
cat /audit/git/A17/head
cat /audit/git/A17/shallow
cat /audit/git/A17/commit
printf "\n"
wc -c /audit/git/A17/tree.z
mkdir /audit/git/A35
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/isla-lang.dev rev-parse HEAD > /audit/git/A35/head
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/isla-lang.dev rev-parse --is-shallow-repository > /audit/git/A35/shallow
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/isla-lang.dev cat-file commit bda86c9f0bd28bbaa2481f50ddc986ede342805a > /audit/git/A35/commit
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/isla-lang.dev ls-tree -r -t -z --full-tree bda86c9f0bd28bbaa2481f50ddc986ede342805a > /audit/git/A35/tree.z
printf "%s\n" 'A35 isla-lang.dev'
cat /audit/git/A35/head
cat /audit/git/A35/shallow
cat /audit/git/A35/commit
printf "\n"
wc -c /audit/git/A35/tree.z
mkdir /audit/git/A36
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-stdpp.dev.2024-09-10.3.a1a12e00 rev-parse HEAD > /audit/git/A36/head
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-stdpp.dev.2024-09-10.3.a1a12e00 rev-parse --is-shallow-repository > /audit/git/A36/shallow
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-stdpp.dev.2024-09-10.3.a1a12e00 cat-file commit a1a12e00fba07f2e41ccd74a8b593b88e48fc2c3 > /audit/git/A36/commit
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-stdpp.dev.2024-09-10.3.a1a12e00 ls-tree -r -t -z --full-tree a1a12e00fba07f2e41ccd74a8b593b88e48fc2c3 > /audit/git/A36/tree.z
printf "%s\n" 'A36 coq-stdpp.dev.2024-09-10.3.a1a12e00'
cat /audit/git/A36/head
cat /audit/git/A36/shallow
cat /audit/git/A36/commit
printf "\n"
wc -c /audit/git/A36/tree.z
mkdir /audit/git/A39
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-iris.dev.2024-09-10.1.6f24ed4b rev-parse HEAD > /audit/git/A39/head
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-iris.dev.2024-09-10.1.6f24ed4b rev-parse --is-shallow-repository > /audit/git/A39/shallow
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-iris.dev.2024-09-10.1.6f24ed4b cat-file commit 6f24ed4baa4d61967a95bac834eab2c66f3b76fa > /audit/git/A39/commit
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-iris.dev.2024-09-10.1.6f24ed4b ls-tree -r -t -z --full-tree 6f24ed4baa4d61967a95bac834eab2c66f3b76fa > /audit/git/A39/tree.z
printf "%s\n" 'A39 coq-iris.dev.2024-09-10.1.6f24ed4b'
cat /audit/git/A39/head
cat /audit/git/A39/shallow
cat /audit/git/A39/commit
printf "\n"
wc -c /audit/git/A39/tree.z
mkdir /audit/git/A40
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail.0.17 rev-parse HEAD > /audit/git/A40/head
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail.0.17 rev-parse --is-shallow-repository > /audit/git/A40/shallow
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail.0.17 cat-file commit 169934e27ceafe393ed4d365985f7b12d974d56e > /audit/git/A40/commit
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail.0.17 ls-tree -r -t -z --full-tree 169934e27ceafe393ed4d365985f7b12d974d56e > /audit/git/A40/tree.z
printf "%s\n" 'A40 coq-sail.0.17'
cat /audit/git/A40/head
cat /audit/git/A40/shallow
cat /audit/git/A40/commit
printf "\n"
wc -c /audit/git/A40/tree.z
mkdir /audit/git/A41
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-lithium.dev.2024-09-11.0.7945a29d rev-parse HEAD > /audit/git/A41/head
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-lithium.dev.2024-09-11.0.7945a29d rev-parse --is-shallow-repository > /audit/git/A41/shallow
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-lithium.dev.2024-09-11.0.7945a29d cat-file commit 7945a29d1647970709a9b5ad2ffc53c757e130cc > /audit/git/A41/commit
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-lithium.dev.2024-09-11.0.7945a29d ls-tree -r -t -z --full-tree 7945a29d1647970709a9b5ad2ffc53c757e130cc > /audit/git/A41/tree.z
printf "%s\n" 'A41 coq-lithium.dev.2024-09-11.0.7945a29d'
cat /audit/git/A41/head
cat /audit/git/A41/shallow
cat /audit/git/A41/commit
printf "\n"
wc -c /audit/git/A41/tree.z
mkdir /audit/git/A42
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail-riscv.0.5 rev-parse HEAD > /audit/git/A42/head
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail-riscv.0.5 rev-parse --is-shallow-repository > /audit/git/A42/shallow
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail-riscv.0.5 cat-file commit 837ede9b39fae2aa97849da89c4b3b5a93344890 > /audit/git/A42/commit
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail-riscv.0.5 ls-tree -r -t -z --full-tree 837ede9b39fae2aa97849da89c4b3b5a93344890 > /audit/git/A42/tree.z
printf "%s\n" 'A42 coq-sail-riscv.0.5'
cat /audit/git/A42/head
cat /audit/git/A42/shallow
cat /audit/git/A42/commit
printf "\n"
wc -c /audit/git/A42/tree.z
mkdir /audit/git/A43
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/islaris.dev rev-parse HEAD > /audit/git/A43/head
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/islaris.dev rev-parse --is-shallow-repository > /audit/git/A43/shallow
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/islaris.dev cat-file commit c978e10f50db5c40f0fdf113f5f76a779782c6f9 > /audit/git/A43/commit
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/islaris.dev ls-tree -r -t -z --full-tree c978e10f50db5c40f0fdf113f5f76a779782c6f9 > /audit/git/A43/tree.z
printf "%s\n" 'A43 islaris.dev'
cat /audit/git/A43/head
cat /audit/git/A43/shallow
cat /audit/git/A43/commit
printf "\n"
wc -c /audit/git/A43/tree.z
