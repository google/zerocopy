set -eu
find /solve/opam/islaris-dry/.opam-switch/sources -mindepth 1 -maxdepth 1 -printf '%y %m %s %p\n'
find /solve/opam/islaris-dry/.opam-switch/sources -maxdepth 2 -name .git -printf '%y %p %l\n'
find /solve/opam/download-cache -type f -printf '%s %p\n'
du -sb /solve/opam /solve/opam/download-cache /solve/opam/islaris-dry/.opam-switch/sources
find /solve/opam/islaris-dry/.opam-switch -maxdepth 2 -type f -not -path '*/sources/*' -exec sha256sum '{}' +
cat /solve/opam/islaris-dry/.opam-switch/switch-config
sha256sum /usr/bin/git /usr/bin/opam /usr/bin/sha256sum /usr/bin/sha512sum
git --version
