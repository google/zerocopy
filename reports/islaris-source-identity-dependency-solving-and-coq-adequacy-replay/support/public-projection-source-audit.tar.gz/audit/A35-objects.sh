set -eu
export GIT_OPTIONAL_LOCKS=0 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
{ printf "%s\n" bda86c9f0bd28bbaa2481f50ddc986ede342805a 8470877f5e3eb5b8c3f67cfaaf32bd5d1ddef13d; git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/isla-lang.dev ls-tree -r -t --format="%(objectname)" bda86c9f0bd28bbaa2481f50ddc986ede342805a; } | sort -u > /audit/git/A35/objects
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/isla-lang.dev cat-file --batch < /audit/git/A35/objects
