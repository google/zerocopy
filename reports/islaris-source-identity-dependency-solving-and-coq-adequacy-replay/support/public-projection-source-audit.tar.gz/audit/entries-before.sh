set -eu
find /solve/opam /owned-inputs -printf '%y\0%m\0%U\0%G\0%s\0%p\0%l\0' > /audit/all-entries-before.z
cat /audit/all-entries-before.z
