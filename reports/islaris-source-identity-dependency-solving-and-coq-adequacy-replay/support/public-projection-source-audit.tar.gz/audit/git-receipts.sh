set -eu
tar -C /audit -cf - git
