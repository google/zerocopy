import pathlib,sys,json,subprocess,time,hashlib
ROOT=pathlib.Path(__file__).resolve().parent
CID='942f3767a54df1f9f327fd17706f007e09c73e4088b8c272063cc20863c0b2a8'
phase=sys.argv[1]
if not phase.replace('-','').isalnum():raise ValueError('phase name')
if (ROOT/(phase+'.stdout')).exists():raise ValueError('phase already recorded')
started=time.monotonic()
inspect=subprocess.run(['docker','inspect',CID],capture_output=True)
(ROOT/(phase+'-inspect.stdout')).write_bytes(inspect.stdout);(ROOT/(phase+'-inspect.stderr')).write_bytes(inspect.stderr)
if inspect.returncode:raise RuntimeError('inspect failed')
x=json.loads(inspect.stdout)[0];h=x['HostConfig']
if not(x['Id']==CID and x['Image']=='sha256:1189d6a4a06d068d675121d121999a7a8d3afa35e6d922ee41a0679fc98876ce' and h['NetworkMode']=='none' and h['Memory']==1073741824 and h['NanoCpus']==1000000000 and h['PidsLimit']==128 and x['Mounts']==[] and x['State']['Running']):raise RuntimeError('audit isolation identity mismatch')
prior=[json.loads(p.read_text()) for p in ROOT.glob('*-receipt.json')]
used=sum(p['seconds'] for p in prior)
if used>=900:raise RuntimeError('15-minute native cap')
source=ROOT/(phase+'.py')
if not source.exists():source=ROOT/(phase+'.sh')
code=source.read_text()
payload=json.loads((ROOT/'inputs.json').read_text())
argv=['docker','exec','--user=1000:1000','-i',CID]+(['python3','-I','-B','-c',code] if source.suffix=='.py' else ['/bin/sh','-c',code])
try:
 with (ROOT/(phase+'.stdout')).open('wb') as out,(ROOT/(phase+'.stderr')).open('wb') as err:
  r=subprocess.run(argv,input=json.dumps(payload).encode(),stdout=out,stderr=err,timeout=max(1,900-used))
 status=r.returncode
except subprocess.TimeoutExpired:status=124
receipt={'argv':argv[:-1]+['<exact source in '+source.name+'>'],'code_sha256':hashlib.sha256(code.encode()).hexdigest(),'status':status,'seconds':time.monotonic()-started,'prior_native_seconds':used,'streams':{}}
for name in ['stdout','stderr']:
 b=(ROOT/(phase+'.'+name)).read_bytes();receipt['streams'][name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(ROOT/(phase+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
if status:raise SystemExit(status)
