import pathlib,json,subprocess,hashlib,tarfile,posixpath,time
ROOT=pathlib.Path(__file__).resolve().parent;CID='942f3767a54df1f9f327fd17706f007e09c73e4088b8c272063cc20863c0b2a8'
x=json.loads((ROOT/'inputs.json').read_text());maps={r['id']:r for r in json.loads((ROOT/'http-object-map.json').read_text())}
hashes={z[66:].decode():z[:64].decode() for z in (ROOT/'hash-before.stdout').read_bytes().split(b'\0') if z}
bits=(ROOT/'entries-before.stdout').read_bytes().split(b'\0')[:-1];entries={bits[i+5].decode():{'type':bits[i].decode(),'mode':bits[i+1].decode(),'bytes':int(bits[i+4]),'target':bits[i+6].decode()} for i in range(0,len(bits),7)}
inspection=subprocess.check_output(['docker','inspect',CID]);(ROOT/'http-sources-inspect.stdout').write_bytes(inspection);i=json.loads(inspection)[0]
if i['Image']!='sha256:1189d6a4a06d068d675121d121999a7a8d3afa35e6d922ee41a0679fc98876ce' or i['HostConfig']['NetworkMode']!='none' or i['Mounts']:raise ValueError('isolation changed')
results=[]
class HashedReader:
 def __init__(self,f):self.f=f;self.h=hashlib.sha256();self.n=0
 def read(self,n=-1):
  b=self.f.read(n);self.h.update(b);self.n+=len(b);return b
for art in x['artifacts']['artifacts']:
 if art['kind']=='fixed-git':continue
 obj=maps[art['id']];started=time.monotonic();argv=['docker','exec','--user=1000:1000',CID,'cat',obj['path']]
 expected_checks={k:v for k,v in (s.split('=',1) for s in art['checksums'])};computed={k:hashlib.new(k) for k in expected_checks}
 source={};raw_sections=[]
 with (ROOT/(art['id']+'-http.stderr')).open('wb') as err:
  proc=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=err);reader=HashedReader(proc.stdout)
  if art['artifact_class']=='archive':
   with tarfile.open(fileobj=reader,mode='r|*') as tar:
    for m in tar:
     name=m.name
     if name.startswith('/') or '..' in pathlib.PurePosixPath(name).parts:raise RuntimeError('unexpected archive path '+name)
     name=posixpath.normpath(name.removeprefix('./'))
     if m.isdir():continue
     if name in source:raise RuntimeError('duplicate archive member '+name)
     row={'mode':oct(m.mode),'bytes':m.size,'type':'file' if m.isfile() else 'symlink' if m.issym() else 'hardlink' if m.islnk() else 'UNSUPPORTED','target':m.linkname}
     if row['type']=='UNSUPPORTED':raise RuntimeError('unexpected archive type '+name)
     if m.isfile():
      h=hashlib.sha256();f=tar.extractfile(m)
      while True:
       b=f.read(65536)
       if not b:break
       h.update(b)
      row['sha256']=h.hexdigest()
     source[name]=row
   while reader.read(65536):pass
  else:
   body=bytearray()
   while True:
    b=reader.read(65536)
    if not b:break
    body.extend(b)
   (ROOT/(art['id']+'-extra-source')).write_bytes(body)
   for h in computed.values():h.update(body)
  status=proc.wait(timeout=120)
 if status or reader.h.hexdigest()!=obj['sha256']:raise RuntimeError('HTTP cache stream identity mismatch '+art['id'])
 if art['artifact_class']=='extra-file' and any(h.hexdigest()!=expected_checks[k] for k,h in computed.items()):raise RuntimeError('extra-file checksum mismatch')
 record={'id':art['id'],'argv':argv,'status':status,'seconds':time.monotonic()-started,'transport_bytes':reader.n,'transport_sha256':reader.h.hexdigest(),'consumer_checks':[]}
 if source:
  roots={name.split('/')[0] for name in source};strip=next(iter(roots))+'/' if len(roots)==1 and all('/' in n for n in source) else ''
  wanted={name.removeprefix(strip):r for name,r in source.items()}
  for name,row in list(wanted.items()):
   if row['type']=='hardlink':
    target=posixpath.normpath(row['target'].removeprefix('./')).removeprefix(strip)
    if target not in wanted or wanted[target]['type']!='file':raise RuntimeError('unresolved archive hardlink')
    row['sha256']=wanted[target]['sha256']
  for consumer in art['consumers']:
   base='/solve/opam/islaris-dry/.opam-switch/sources/'+consumer['package']+'/'
   actual={n[len(base):]:r for n,r in entries.items() if n.startswith(base) and r['type']!='d'}
   allowed_extra={}
   for other in x['artifacts']['artifacts']:
    if other['artifact_class']=='extra-file':
     for c in other['consumers']:
      if c['package']==consumer['package']:allowed_extra[c['role']]=maps[other['id']]['sha256']
   missing=set(wanted)-set(actual);extra=set(actual)-set(wanted)
   if missing or extra-set(allowed_extra):raise RuntimeError('archive/worktree path mismatch '+consumer['package']+' '+str(missing)+' '+str(extra))
   for name,row in wanted.items():
    got=actual[name]
    if row['type']=='symlink':
     if got['type']!='l' or got['target']!=row['target']:raise RuntimeError('archive symlink mismatch '+name)
    else:
     if got['type']!='f' or hashes[base+name]!=row['sha256'] or bool(int(got['mode'],8)&0o100)!=bool(int(row['mode'],8)&0o100):raise RuntimeError('archive blob/mode mismatch '+consumer['package']+' '+name)
   if any(hashes[base+n]!=allowed_extra[n] for n in extra):raise RuntimeError('declared extra-file mismatch')
   record['consumer_checks'].append({'package':consumer['package'],'members':len(wanted),'additional_declared_extra_files':sorted(extra),'status':'PASS'})
  record['stripped_archive_root']=strip;record['members']=wanted
 else:record['consumers']=art['consumers']
 (ROOT/(art['id']+'-http.json')).write_text(json.dumps(record,indent=2)+'\n');results.append({k:v for k,v in record.items() if k!='members'});print(art['id'],len(source),len(record['consumer_checks']),flush=True)
(ROOT/'http-sources-summary.json').write_text(json.dumps(results,indent=2)+'\n')
