set -eu
export GIT_OPTIONAL_LOCKS=0 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
{ printf "%s\n" b14f649845db850b3673696e2aa90565fa2a60ef afbe7dc3e0e0784240fda24cac959d42af3e82ef; git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/sail_manifest.0.17 ls-tree -r -t --format="%(objectname)" b14f649845db850b3673696e2aa90565fa2a60ef; } | sort -u > /audit/git/A17/objects
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/sail_manifest.0.17 cat-file --batch < /audit/git/A17/objects
