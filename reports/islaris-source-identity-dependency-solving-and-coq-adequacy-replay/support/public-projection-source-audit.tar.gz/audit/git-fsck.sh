set -eu
export GIT_OPTIONAL_LOCKS=0 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
printf "%s\n" A17
cat /solve/opam/islaris-dry/.opam-switch/sources/sail_manifest.0.17/.git/config
cat /solve/opam/islaris-dry/.opam-switch/sources/sail_manifest.0.17/.git/objects/info/alternates
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/sail_manifest.0.17 fsck --full --strict --no-reflogs --no-dangling > /audit/git/A17/fsck.stdout 2> /audit/git/A17/fsck.stderr
cat /audit/git/A17/fsck.stdout
cat /audit/git/A17/fsck.stderr
printf "%s\n" A35
cat /solve/opam/islaris-dry/.opam-switch/sources/isla-lang.dev/.git/config
cat /solve/opam/islaris-dry/.opam-switch/sources/isla-lang.dev/.git/objects/info/alternates
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/isla-lang.dev fsck --full --strict --no-reflogs --no-dangling > /audit/git/A35/fsck.stdout 2> /audit/git/A35/fsck.stderr
cat /audit/git/A35/fsck.stdout
cat /audit/git/A35/fsck.stderr
printf "%s\n" A36
cat /solve/opam/islaris-dry/.opam-switch/sources/coq-stdpp.dev.2024-09-10.3.a1a12e00/.git/config
cat /solve/opam/islaris-dry/.opam-switch/sources/coq-stdpp.dev.2024-09-10.3.a1a12e00/.git/objects/info/alternates
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-stdpp.dev.2024-09-10.3.a1a12e00 fsck --full --strict --no-reflogs --no-dangling > /audit/git/A36/fsck.stdout 2> /audit/git/A36/fsck.stderr
cat /audit/git/A36/fsck.stdout
cat /audit/git/A36/fsck.stderr
printf "%s\n" A39
cat /solve/opam/islaris-dry/.opam-switch/sources/coq-iris.dev.2024-09-10.1.6f24ed4b/.git/config
cat /solve/opam/islaris-dry/.opam-switch/sources/coq-iris.dev.2024-09-10.1.6f24ed4b/.git/objects/info/alternates
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-iris.dev.2024-09-10.1.6f24ed4b fsck --full --strict --no-reflogs --no-dangling > /audit/git/A39/fsck.stdout 2> /audit/git/A39/fsck.stderr
cat /audit/git/A39/fsck.stdout
cat /audit/git/A39/fsck.stderr
printf "%s\n" A40
cat /solve/opam/islaris-dry/.opam-switch/sources/coq-sail.0.17/.git/config
cat /solve/opam/islaris-dry/.opam-switch/sources/coq-sail.0.17/.git/objects/info/alternates
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail.0.17 fsck --full --strict --no-reflogs --no-dangling > /audit/git/A40/fsck.stdout 2> /audit/git/A40/fsck.stderr
cat /audit/git/A40/fsck.stdout
cat /audit/git/A40/fsck.stderr
printf "%s\n" A41
cat /solve/opam/islaris-dry/.opam-switch/sources/coq-lithium.dev.2024-09-11.0.7945a29d/.git/config
cat /solve/opam/islaris-dry/.opam-switch/sources/coq-lithium.dev.2024-09-11.0.7945a29d/.git/objects/info/alternates
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-lithium.dev.2024-09-11.0.7945a29d fsck --full --strict --no-reflogs --no-dangling > /audit/git/A41/fsck.stdout 2> /audit/git/A41/fsck.stderr
cat /audit/git/A41/fsck.stdout
cat /audit/git/A41/fsck.stderr
printf "%s\n" A42
cat /solve/opam/islaris-dry/.opam-switch/sources/coq-sail-riscv.0.5/.git/config
cat /solve/opam/islaris-dry/.opam-switch/sources/coq-sail-riscv.0.5/.git/objects/info/alternates
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail-riscv.0.5 fsck --full --strict --no-reflogs --no-dangling > /audit/git/A42/fsck.stdout 2> /audit/git/A42/fsck.stderr
cat /audit/git/A42/fsck.stdout
cat /audit/git/A42/fsck.stderr
printf "%s\n" A43
cat /solve/opam/islaris-dry/.opam-switch/sources/islaris.dev/.git/config
cat /solve/opam/islaris-dry/.opam-switch/sources/islaris.dev/.git/objects/info/alternates
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/islaris.dev fsck --full --strict --no-reflogs --no-dangling > /audit/git/A43/fsck.stdout 2> /audit/git/A43/fsck.stderr
cat /audit/git/A43/fsck.stdout
cat /audit/git/A43/fsck.stderr
find /solve/opam/download-cache/md5 /solve/opam/download-cache/sha256 /solve/opam/download-cache/sha512 -type f -exec md5sum -z '{}' + > /audit/http.md5z
cat /audit/http.md5z
