import os,sys,pathlib,json,hashlib,time,stat
x=json.load(sys.stdin);root=pathlib.Path('/audit')
if os.getuid()!=1000 or os.getgid()!=1000 or stat.S_IMODE(root.stat().st_mode)!=0o700:raise RuntimeError('consumer/write-root identity mismatch')
out={'uid':os.getuid(),'gid':os.getgid(),'root':str(root),'paths':{}}
for base in ['/solve/opam','/owned-inputs']:
 rows=[]
 for current,dirs,files in os.walk(base):
  depth=len(pathlib.Path(current).relative_to(base).parts)
  for n in dirs+files:
   p=pathlib.Path(current)/n;s=p.lstat();rows.append({'path':str(p),'mode':oct(s.st_mode),'size':s.st_size,'uid':s.st_uid,'gid':s.st_gid})
  if depth>=2:dirs[:]=[]
 out['paths'][base]=rows
out['tools']={}
for name in ['/usr/bin/git','/usr/bin/opam','/usr/bin/python3']:
 p=pathlib.Path(name);b=p.read_bytes();out['tools'][name]={'resolved':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(root/'inventory.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
