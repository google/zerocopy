set -eu
export GIT_OPTIONAL_LOCKS=0 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
{ printf "%s\n" c978e10f50db5c40f0fdf113f5f76a779782c6f9 fc4d58114da60ae9f2f8a058d4bd77ce6c68f8f4; git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/islaris.dev ls-tree -r -t --format="%(objectname)" c978e10f50db5c40f0fdf113f5f76a779782c6f9; } | sort -u > /audit/git/A43/objects
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/islaris.dev cat-file --batch < /audit/git/A43/objects
