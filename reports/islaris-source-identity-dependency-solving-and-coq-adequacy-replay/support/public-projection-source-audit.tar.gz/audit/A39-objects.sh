set -eu
export GIT_OPTIONAL_LOCKS=0 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
{ printf "%s\n" 6f24ed4baa4d61967a95bac834eab2c66f3b76fa 187b3d8550d70f408aef287172bfc3f9bf26df06; git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-iris.dev.2024-09-10.1.6f24ed4b ls-tree -r -t --format="%(objectname)" 6f24ed4baa4d61967a95bac834eab2c66f3b76fa; } | sort -u > /audit/git/A39/objects
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-iris.dev.2024-09-10.1.6f24ed4b cat-file --batch < /audit/git/A39/objects
