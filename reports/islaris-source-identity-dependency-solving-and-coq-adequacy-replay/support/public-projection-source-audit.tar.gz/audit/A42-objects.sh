set -eu
export GIT_OPTIONAL_LOCKS=0 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
{ printf "%s\n" 837ede9b39fae2aa97849da89c4b3b5a93344890 9810fb69b85f292d441d5d149e0f3913177baf3d; git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail-riscv.0.5 ls-tree -r -t --format="%(objectname)" 837ede9b39fae2aa97849da89c4b3b5a93344890; } | sort -u > /audit/git/A42/objects
git --no-pager -c core.fsmonitor=false -c core.hooksPath=/dev/null -c core.untrackedCache=false -C /solve/opam/islaris-dry/.opam-switch/sources/coq-sail-riscv.0.5 cat-file --batch < /audit/git/A42/objects
