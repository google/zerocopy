"""Bounded guards for this exact 53-installed + 21-pending download experiment."""
import json,re,operator,hashlib

def require(c,m):
 if not c:raise ValueError(m)
def raw_json(b):
 duplicates=[]
 def pairs(ps):
  d={}
  for k,v in ps:
   if k in d:duplicates.append(dict(key=k,identical=d[k]==v));require(d[k]==v,'conflicting duplicate JSON key')
   d[k]=v
  return d
 def bad(x):raise ValueError('non-JSON constant '+x)
 j=json.loads(b,object_pairs_hook=pairs,parse_constant=bad);return j,duplicates

def no_hooks(*configs):
 for b in configs:require(not re.search(rb'(?m)^\s*(?:pre|post|wrap)-[a-z-]+-commands\s*:',b),'opam hook/wrapper field present; review before opam invocation')

def download_outcome(j,stdout,expected,allowed_other=()):
 # opamSolution.ml:677-714 excludes ALL Fetch actions from results.
 require('results'in j and j['results']==[],'successful download-only requires emitted empty results; Fetch records are not produced')
 require('download-failures'not in j and 'conflicts'not in j,'download/solver failure field present')
 require(isinstance(stdout,bytes),'actual stdout bytes required')
 lines=stdout.decode('utf-8').splitlines();retrieved=[];messages=[]
 for line in lines:
  if 'retrieved'not in line:continue
  m=re.fullmatch(r'-> retrieved (\S+)  \((.*)\)',line)
  require(m is not None,'unsupported retrieval stdout syntax')
  retrieved.append(m[1]);messages.append(dict(package=m[1],message=m[2],line=line))
 require(len(retrieved)==len(set(retrieved)),'duplicate retrieval message')
 require(set(expected)<=set(retrieved) and set(retrieved)<=set(expected)|set(allowed_other),'retrieval coverage differs from exact pending source consumers')
 return dict(json_results=[],retrieval_messages=messages,stdout_sha256=hashlib.sha256(stdout).hexdigest(),observed_retrievals=len(retrieved),scope='Successful per-package retrieval messages, not JSON Fetch records or proof of newly transferred bytes. Final full source/commit/tree checks remain mandatory.')

def records(b):
 rows=[];requests=[];preambles=[]
 for block in re.split(r'\n\s*\n',b.decode()):
  d={};last=None
  for line in block.splitlines():
   if not line or line.startswith('#'):continue
   if line[0].isspace():require(last is not None,'CUDF continuation without field');d[last]+=' '+line.strip();continue
   require(':'in line,'CUDF line syntax');k,v=line.split(':',1);require(k not in d,'duplicate CUDF field');d[k]=v.strip();last=k
  if not d:continue
  if 'package'in d:rows.append(d)
  elif 'request'in d:requests.append(d)
  elif 'preamble'in d:preambles.append(d)
  else:raise ValueError('unrecognized CUDF paragraph')
 require(len(requests)==len(preambles)==1,'CUDF request/preamble count');require('pinned: bool = [false]'in preambles[0].get('property','') and 'installed-root: bool = [false]'in preambles[0].get('property',''),'CUDF boolean defaults');return rows,requests[0]

def audit(native,cudf,context,argv,actual,stdout=None):
 j,dups=raw_json(native);require(j['command-line']==argv,'native JSON command line differs from exact invocation')
 req=j['request'];require(req['action']=='install' and not req.get('remove') and not req.get('upgrade'),'native non-install request')
 roots=context['roots_ordered'];pending=set(context['pending_exact']);installed=set(context['installed']);full=set(context['full_exact74'])
 require(installed.isdisjoint(pending) and installed|pending==full and len(full)==74,'host target partition')
 # opam may omit the 14 already-satisfied roots from normalized wishes. Only two whole-list representations are supported.
 wishes=req['install'];pending_order=[x for x in roots if x in pending];require(wishes==roots or wishes==pending_order,'unexpected normalized native root wishes')
 selected=[]
 for a in j['solution']:require(set(a)=={'install'},'unexpected remove/change/reinstall solution action');p=a['install'];selected.append(p['name']+'.'+p['version'])
 require(len(selected)==21 and set(selected)==pending,'native pending solution differs from exact remaining21')
 require(not j.get('download-failures') and 'conflicts'not in j,'native source/solver failure')
 if actual:outcome=download_outcome(j,stdout,pending)
 else:
  require('results'not in j or j['results']==[],'dry-run nonempty results')
  outcome=None
 rows,request=records(cudf);identities={};by_exact={};synthetic=[]
 for r in rows:
  k=(r['package'],int(r['version']));require(k not in identities,'duplicate CUDF package/version');identities[k]=r
  exact=r.get('opam-name','')+'.'+r.get('opam-version','');by_exact.setdefault(exact,[]).append(r)
  if r.get('opam-name')=='SWITCH_INVARIANT':synthetic.append(r)
 require(len(synthetic)==1,'synthetic invariant count');syn=synthetic[0]
 expected_syn={'package':'%3dopam-invariant','version':'1','installed':'true','was-installed':'true','keep':'version','opam-name':'SWITCH_INVARIANT','opam-version':'NULL'}
 require(all(syn.get(k)==v for k,v in expected_syn.items()) and not(set(syn)-set(expected_syn)-{'depends','conflicts'}),'unexpected synthetic invariant structure')
 real=[]
 for x in sorted(full):require(len(by_exact.get(x,[]))==1,'full74 CUDF identity missing/ambiguous');real+=by_exact[x]
 real_installed={r.get('opam-name','')+'.'+r.get('opam-version','') for r in rows if r.get('installed','false')=='true' and r is not syn}
 require(real_installed==installed,'CUDF current installed53 differs from stopped state')
 root_flags={r.get('opam-name','')+'.'+r.get('opam-version','') for r in rows if r.get('installed-root','false')=='true'};require(root_flags==set(context['installed_roots']),'CUDF installed root14 context differs')
 require(all(r.get('pinned','false')=='false' for r in rows),'CUDF pin context differs from pins0')
 selected=real+[syn];keys={(r['package'],int(r['version'])) for r in selected};require(len(keys)==75 and len({r['opam-name'] for r in selected})==75,'selected identity uniqueness')
 require(not any(r.get('provides') for r in selected),'selected provides unsupported')
 atom_rx=re.compile(r'([A-Za-z0-9+.%_-]+)(?:\s*(>=|<=|!=|=|<|>)\s*([0-9]+))?');ops={'=':operator.eq,'!=':operator.ne,'<':operator.lt,'>':operator.gt,'<=':operator.le,'>=':operator.ge}
 def atom(s):
  m=atom_rx.fullmatch(s.strip());require(m is not None,'unsupported CUDF atom '+repr(s));return m.groups()
 def matches(s,exclude=None):
  name,op,v=atom(s);return[(n,x)for n,x in keys if(n,x)!=exclude and n==name and(op is None or ops[op](x,int(v)))]
 clauses=conflicts=0
 for r in selected:
  me=(r['package'],int(r['version']));require(r.get('keep','none')in['none','version','package'],'unsupported selected keep policy')
  if r.get('depends'):
   for c in r['depends'].split(','):require(any(matches(a)for a in c.split('|')),'unsatisfied full74+invariant dependency');clauses+=1
  if r.get('conflicts'):
   for a in r['conflicts'].split(','):require(not matches(a,me),'selected conflict');conflicts+=1
 require(set(request)<={'request','install','remove','upgrade'} and not request.get('remove') and not request.get('upgrade'),'unsupported CUDF request')
 request_exact=[]
 for a in request.get('install','').split(','):
  name,op,v=atom(a);require(op=='=','non-exact CUDF root request');r=identities[(name,int(v))];request_exact.append(r['opam-name']+'.'+r['opam-version']);require(bool(matches(a)),'CUDF root unsatisfied')
 require(len(request_exact)==len(set(request_exact)) and(set(request_exact)==set(roots)or set(request_exact)==pending),'CUDF request is neither exact35 nor normalized pending21')
 # Load-bearing development dependency remains in actual filtered CUDF.
 ls=next(r for r in real if r['opam-name']=='libsail');bis=next(r for r in real if r['opam-name']=='bisect_ppx');ls_atoms=[atom(a)[0] for c in ls.get('depends','').split(',')for a in c.split('|')]
 require(bis['package']in ls_atoms,'libsail dev dependency on bisect_ppx disappeared')
 return dict(status='PASS_EXACT_DOWNLOAD_GATE',native_json_sha256=hashlib.sha256(native).hexdigest(),cudf_sha256=hashlib.sha256(cudf).hexdigest(),raw_duplicate_keys=dups,cli_roots_ordered=roots,native_wishes_ordered=wishes,cudf_root_versions=request_exact,installed53=sorted(installed),installed_root14=sorted(root_flags),pending21=sorted(pending),full74=sorted(full),synthetic_invariant=syn,dependency_clauses=clauses,conflicts_checked=conflicts,all_pins_false=True,libsail_filtered_bisect_ppx_dependency_present=True,download_outcome=outcome,scope='Bounded executable guard of exported CUDF/current state and exact selection; opam metadata/filter translation, checker correctness, builds and theorems remain separate trust boundaries')
