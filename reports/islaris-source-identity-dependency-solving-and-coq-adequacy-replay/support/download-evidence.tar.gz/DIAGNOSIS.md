# Producer-contract correction before execution

The frozen v1 gate was never executed. Its actual-result guard incorrectly required 21 successful JSON Fetch entries. That guard would reject a successful opam 2.1.6 download-only run after the source operation. This is a host controller contract defect, not a source/cache/compiler failure; it changes no earlier acquisition, transport, partial-install or theorem result. The original v1 directory and manifest remain unchanged. No native process was started for this investigation.

## Exact producer evidence

The retained original successful acquisition `primary/prior-success.json` has 74 planned solution actions, 35 request roots, and **present, empty `results: []`**. Its duplicated `command-line` values are identical. Its raw stdout has 65 distinct successful `-> retrieved package.version  (message)` lines; all 21 current pending fixed-Git consumers occur exactly once. The receipt is historical empty-switch evidence, not a replacement for a new current-53 solve.

Official opam 2.1.6 source revision `dfbe6a0b3a386376780bf68d35e4ce107072079d` explains this schema:

- `primary/opamSolution.ml:454–472`: after expanding the solution graph, download-only removes Install/Reinstall/Change/Remove/Build vertices and retains Fetch vertices.
- `primary/opamSolution.ml:560–566`: a Fetch executes `OpamAction.download_package`.
- `primary/opamSolution.ml:677–714`: download failures have their separate JSON field; **every Fetch is excluded** from the `results` array. The array reports remaining non-Fetch actions. Thus the successful download-only producer emits an empty results array; inventing Fetch entries would violate the observed producer contract.
- `primary/opamAction.ml:240–296`: dry-run/fake bypass download; pinned-source fast path can bypass retrieval but this switch must have pins zero. Successful main-source Result/Up_to_date paths print the retrieval line. Each of the 21 pending consumers has an actual main Git URL, so the supported successful path supplies a per-package line. A line means retrieval success, including an already-current source; it does not measure newly transferred bytes or expose the internal Fetch object itself.
- `primary/opamSolution.ml:1235–1268`: pre/post-session hooks remain possible around download-only. Therefore root/switch hook/wrapper-field rejection remains mandatory before every opam action. The operation is not inferred safe solely from its JSON.

The executable is bound to its actual retained hash/version, separately from these official source semantics. This is not a reproducible-build proof connecting the executable to that source revision. Planned `solution` install actions and printed solution plans are requests, not observed Build/Install execution. The v2 conclusion combines the trusted download-only branch and exact CLI, successful process status, empty non-Fetch report, absent failure fields, zero hooks, retrieval messages, and unchanged installed/source/provider/metadata postconditions. None alone constitutes a general proof against a malicious opam executable.

## Revised exact checks

V2 requires actual `results` to be present and exactly `[]`; rejects even fabricated successful Fetch entries; rejects present download-failures/conflicts fields; and requires exactly one supported ASCII retrieval line for each of the exact 21 pending consumers, with no extras or duplicates. Unsupported formatting stops rather than being silently stripped/normalized. Full source bytes, commit/tree/ref identities and installed 53/root 14/pins zero remain required before and after. Current-state request/CUDF guards, all 74 identities, 35 ordered CLI roots, libsail's development bisect_ppx dependency and immutable metadata remain unchanged. Dry-run may omit results or emit the empty array, and cannot produce a nonempty array. Ordinary normal Git bookkeeping is recorded separately from protected source semantics.

If a future successful client emits a different stdout/schema, v2 will stop and preserve the result; it will not infer 21 Fetch observations from a planned solution. No claim of current-53 successful retrieval exists yet. Regressions cover actual historical producer bytes and rejected changed/extra actions, versions, hooks, missing/duplicate/extra retrievals, failure fields, absent results and conflicting JSON duplicate keys. The full current-state positive audit awaits a separate native grant and genuine current-state output.

## Download concurrency

`--jobs=1` alone controls a different resource. `primary/opamSolution.ml:655` uses the separate `dl_jobs` pool for fetches. The exact installed help documents `OPAMDOWNLOADJOBS`, and `primary/opamArg.ml:228–229` maps DOWNLOADJOBS to the maximum simultaneous downloads. No `--download-jobs` install flag is assumed.

The historical acquisition explicitly set the global download-jobs field to 1 and queried `1\n` (both raw receipts retained). That does not assert a fresh observation of the currently idle container. V2 adds a **read-only** identical global-option query, requiring `1\n` before either solve/download, and explicitly sets `OPAMDOWNLOADJOBS=1` for every proposed opam command, including BOTH dry and actual invocations. This disclosed resource-only environment addition leaves versions, roots, source URLs, pins, dev/test/doc filters and solver flags intact. The root configuration's existing exact hash still must match; no config update is performed. Retrievals are therefore proposed to have a single fetch slot, subject to the trusted client implementation, rather than being inferred serial from build jobs.

## New prospective effects and limits

V2 uses a distinct, absent-until-granted output directory `/solve/opam-download-gate-v2`; all other permitted effects and strict source/provider/config/cache checks are those in PLAN.md. A later grant must name the v2 hashes. This preparation made only host files, parsed primary bytes, and executed its own bounded host guard regressions. No Docker/opam/Git subject invocation, package build/install, network operation or source mutation occurred. V1's unexecuted failure guard remains available for comparison; no frozen evidence was repaired in place.
