"""Host-only resource arithmetic and artifact predicate tests; no Docker calls."""
import ast,importlib.util,json,pathlib
R=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('resource_helper',R/'transport_helpers.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
assert h.MIN_FREE==12*1024**3 and h.MAX_ARTIFACT_BYTES==256*1024**2
assert h.MAX_WRITABLE==1024**3 and h.MAX_SECONDS==900
original_limit=h.MAX_ARTIFACT_BYTES;fixture=R/'resource-test-fixture';fixture.mkdir(exist_ok=False);(fixture/'one').write_bytes(b'123');(fixture/'child').mkdir();(fixture/'child/two').write_bytes(b'45')
h.MAX_ARTIFACT_BYTES=5;assert h.artifact_bytes(fixture)==5
h.MAX_ARTIFACT_BYTES=4
try:h.artifact_bytes(fixture)
except RuntimeError as e:reason=str(e)
else:raise AssertionError('whole-tree over-limit accepted')
assert reason=='host native-run artifact threshold'
h.MAX_ARTIFACT_BYTES=original_limit
for filename in ['controller.py','audit_download.py','transport_helpers.py','regression.py','resource-regression.py']:ast.parse((R/filename).read_text())
assert not(R/'native-run').exists()
result=dict(status='PASS_HOST_ONLY_RESOURCE_CONTROLS',minimum_free_bytes=h.MIN_FREE,max_native_run_logical_bytes=original_limit,max_writable_layer_bytes=h.MAX_WRITABLE,total_seconds=h.MAX_SECONDS,whole_tree_sum_at_boundary_accepted=5,one_byte_over_boundary_rejected=True,rejection=reason,native_invocations=0,scope='Small owned host fixture; no subject/native execution or physical-space/peak-memory claim')
(R/'RESOURCE-REGRESSION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
