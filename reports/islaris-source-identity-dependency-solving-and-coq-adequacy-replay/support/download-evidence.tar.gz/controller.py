#!/usr/bin/env python3
"""Exact-current-state opam dry-solve and download-only gate; later native grant required."""
import argparse,hashlib,json,pathlib,re,threading,time,importlib.util
ROOT=pathlib.Path(__file__).resolve().parent
# Load only manifest-bound helper files, including under Python -I.
def own_module(name):
 spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
h=own_module('transport_helpers')
a=own_module('audit_download')
audit=a.audit
OUT='/solve/opam-download-gate-v2'
STATE='/solve/opam/islaris-dry/.opam-switch/switch-state'
SWITCH_CONFIG='/solve/opam/islaris-dry/.opam-switch/switch-config'
PREFIX='/solve/opam/islaris-dry'
UNSET=['OPAMCONFIRMLEVEL','OPAMERRLOGLEN','OPAMPRECISETRACKING','OPAMYES']
BASE_ENV={'OPAMYES':'1','OPAMCONFIRMLEVEL':'unsafe-yes','OPAMERRLOGLEN':'0','OPAMPRECISETRACKING':'1'}

def require(c,m):h.require(c,m)
def snapshot_prefix(g,label):
 files=g.hashes('installed-prefix-'+label,[PREFIX],PREFIX+'/.opam-switch');entries=g.entries('installed-prefix-entries-'+label,[PREFIX],PREFIX+'/.opam-switch');return files,entries

def invoke(g,label,args):
 env=['/usr/bin/env']
 for v in UNSET:env+=['-u',v]
 env+=['OPAMWITHTEST=false','OPAMWITHDOC=false','OPAMJOBS=1','OPAMDOWNLOADJOBS=1','TMPDIR='+OUT+'/tmp']
 return g.run(label,env+args,mapped=True)

def capture_solver(g,label):
 native=g.run(label+'-json',['/usr/bin/cat',OUT+'/'+label+'.json']);b=g.run(label+'-cudf-paths',['/usr/bin/find',OUT,'-maxdepth','1','-type','f','-name',label+'-*.cudf','-print0'])
 require(b.endswith(b'\0'),'missing CUDF output');names=b[:-1].split(b'\0');require(len(names)==1 and re.fullmatch(re.escape(OUT+'/'+label)+r'-[0-9]+\.cudf',names[0].decode()),'unexpected CUDF output count/path');cudf=g.run(label+'-cudf',['/usr/bin/cat',names[0].decode()]);return native,cudf

def check_context(g,e,c,label):
 require(h.sha(g.run(label+'-switch',['/usr/bin/cat',STATE]))==c['expected_switch_sha256'],'installed53/roots14/pins0 switch-state changed')
 require(g.hashes(label+'-protected-inputs',['/owned-inputs'])==e['metadata_files'],'protected metadata changed')
 root=g.run(label+'-root-config',['/usr/bin/cat','/solve/opam/config']);require(h.sha(root)==c['original_opam_config_sha256'],'root opam configuration changed')
 switch=g.run(label+'-switch-config',['/usr/bin/cat',SWITCH_CONFIG])
 # Even download-only runs opam pre/post-session hooks. Do not allow any hook field here.
 a.no_hooks(root,switch)
 return root,switch

def check_provider(g,e):
 h.check_cache(g,h.PROVIDER,e,readonly=True)
 require(g.run('provider-cached-object-list',['/usr/bin/cat',h.CONTROLS+'/provider.objects'])==(ROOT/'objects.list').read_bytes(),'existing object-ID control changed')
 require(g.run('transport-config-bytes',['/usr/bin/cat',h.CONTROLS+'/offline-git.config'])==(ROOT/'offline-git.config').read_bytes(),'existing transport config changed')
 require(g.run('transport-config-values',['/usr/bin/git','config','--global','--get-all','url.file:///solve/offline-git-origin.insteadOf'],mapped=True).decode().splitlines()==[t['url']for t in e['trees']],'parsed URL map changed')
 # The unchanged helper reads provider.objects for label provider; use it for either repository.
 g.closure('provider',h.PROVIDER,{x['oid']:x for x in e['objects']})
 require(not g.run('provider-strict-fsck',['/usr/bin/git','-C',h.PROVIDER,'fsck','--full','--strict','--no-progress']).strip(),'provider fsck output')

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute-granted',action='store_true');args=p.parse_args();require(args.execute_granted,'HOST-ONLY preparation; no native grant yet')
 e=json.loads((ROOT/'EXPECTED.json').read_text());c=json.loads((ROOT/'CONTEXT.json').read_text());g=h.Gate();before=g.inspect('preflight-inspect')
 inherited={x.split('=',1)[0]:x.split('=',1)[1]for x in before['Config']['Env'] if x.startswith('OPAM')};require(inherited==BASE_ENV,'unexpected inherited OPAM filter/control environment')
 require(before['SizeRw']>=302514176,'unexpected reset/loss of accepted transport state');watch=threading.Thread(target=g.watch,daemon=True);watch.start()
 try:
  uid=g.shell('uid-tools','id -u\nid -g\nsha256sum /usr/bin/git /usr/bin/opam\ntest ! -e '+OUT+'\ntest ! -L '+OUT);lines=uid.decode().splitlines();require(lines[:2]==['1000','1000']and lines[2].split()[0]=='54af380ba6ca1b36305358e99427a31ae4b0af5dc5cb6d0198c6f2f16e97651d'and lines[3].split()[0]=='8f42016825a9b10fd21802a18c22d37060c95e8c5a1d2be3df5135402c6a494d','UID/tool identities')
  configs=check_context(g,e,c,'before');h.check_cache(g,h.CACHE,e);check_provider(g,e);h.source_check(g,e);prefix=snapshot_prefix(g,'before')
  # Capture all source .git file hashes, including normal fetch bookkeeping, separately from important refs.
  gitbefore={}
  for t in e['trees']:
   for pkg in t['consumers']:
    path=PREFIX+'/.opam-switch/sources/'+pkg+'/.git';gitbefore.update(g.hashes('git-bookkeeping-before-'+pkg,[path]))
  g.shell('prepare-output','mkdir -m 700 '+OUT+'\nmkdir -m 700 '+OUT+'/tmp')
  # Read-only opam variable listings capture this 53-installed switch context, rather than assuming the empty-switch context.
  download_jobs=invoke(g,'download-jobs-query',['/usr/bin/opam','option','--root=/solve/opam','--no-self-upgrade','--global','download-jobs']);require(download_jobs==b'1\n','root download-jobs is not recorded1')
  vars_global=invoke(g,'filter-vars-global',['/usr/bin/opam','var','--root=/solve/opam','--no-self-upgrade','--global'])
  vars_switch=invoke(g,'filter-vars-switch',['/usr/bin/opam','var','--root=/solve/opam','--no-self-upgrade','--switch=islaris-dry'])
  require(check_context(g,e,c,'after-vars')==configs,'configuration changed during variable listing')
  base=c['original_argv_without_output_paths'];require(base[:3]==['/usr/bin/opam','install','--download-only']and not any(x in base for x in ['--working-dir','--inplace-build','--reuse-build-dir','--fake']),'unexpected opam command')
  dry=base[:3]+['--dry-run','--json='+OUT+'/dry.json','--cudf='+OUT+'/dry']+base[3:]
  invoke(g,'opam-dry-download-solve',dry);native,cudf=capture_solver(g,'dry');drycheck=audit(native,cudf,c,dry,False);h.save(g.out/'DRY-GATE.json',drycheck)
  require(check_context(g,e,c,'after-dry')==configs,'configuration/state changed during dry solve')
  # Only reach actual source fetching if current installed context and exact pending/full selection passed.
  actual=base[:3]+['--json='+OUT+'/download.json','--cudf='+OUT+'/download']+base[3:]
  actual_stdout=invoke(g,'opam-download-only',actual);native2,cudf2=capture_solver(g,'download');actualcheck=audit(native2,cudf2,c,actual,True,actual_stdout);h.save(g.out/'DOWNLOAD-GATE.json',actualcheck)
  require(check_context(g,e,c,'after-download')==configs,'configuration/state changed during download-only')
  h.source_check(g,e);h.check_cache(g,h.CACHE,e);check_provider(g,e);require(snapshot_prefix(g,'after')==prefix,'installed package-prefix material changed')
  gitafter={}
  for t in e['trees']:
   for pkg in t['consumers']:
    path=PREFIX+'/.opam-switch/sources/'+pkg+'/.git';gitafter.update(g.hashes('git-bookkeeping-after-'+pkg,[path]))
  changes=[dict(path=p,before=gitbefore.get(p),after=gitafter.get(p))for p in sorted(set(gitbefore)|set(gitafter)) if gitbefore.get(p)!=gitafter.get(p)]
  h.save(g.out/'GIT-BOOKKEEPING-DELTA.json',dict(changes=changes,scope='All .git regular-file hash differences recorded; important refs/config/alternates and full source trees separately required unchanged. Normal FETCH_HEAD/index/log bookkeeping may differ.'))
  h.save(g.out/'FILTER-CONTEXT.json',dict(installed53=c['installed'],installed_roots14=c['installed_roots'],pins=[],test=False,doc=False,cli_roots_ordered35=c['roots_ordered'],global_vars_sha256=h.sha(vars_global),switch_vars_sha256=h.sha(vars_switch),root_config_sha256=h.sha(configs[0]),switch_config_sha256=h.sha(configs[1]),cudf_current_installed_context_verified=True,libsail_dev_bisect_ppx_present=True,scope='Current switch/runtime listings and actual filtered CUDF, not an assertion that empty-switch formulas or numerical CUDF IDs are unchanged'))
  # Preserve complete native JSON/CUDF/DOT outputs; only direct regular files under the new gate directory are read.
  allpaths=g.run('native-output-paths',['/usr/bin/find',OUT,'-maxdepth','1','-type','f','-print0']);require(not allpaths or allpaths.endswith(b'\0'),'output framing');dest=g.out/'native-solver-output';dest.mkdir()
  for pb in allpaths.rstrip(b'\0').split(b'\0') if allpaths else []:
   path=pb.decode();name=path.rsplit('/',1)[1];require(re.fullmatch(r'(?:dry|download)[A-Za-z0-9_.-]*',name)is not None,'unexpected output file');(dest/name).write_bytes(g.run('copy-output-'+name,['/usr/bin/cat',path]))
  final=g.inspect('final-inspect');h.save(g.out/'RESULTS.json',dict(status='PASS_OPAM_DOWNLOAD_ONLY_CURRENT53',installed_packages_unchanged=53,roots_unchanged=14,pins=0,pending_source_consumers=21,observed_retrieval_messages=actualcheck['download_outcome']['observed_retrievals'],full_selection=74,provider_objects=4935,source_consumers=21,git_bookkeeping_differences=len(changes),initial_size_rw=before['SizeRw'],final_size_rw=final['SizeRw'],nonfetch_json_results=[],download_only_controlflow_bound=True,seconds=time.monotonic()-g.started,scope='Exact-current-state opam dry-solve/download-only source readiness; no package build, installation or theorem result'))
 except Exception as error:
  g.stop('download gate stopped before retry: '+str(error));h.save(g.out/'FAILURE.json',dict(error=str(error),seconds=time.monotonic()-g.started));raise
 finally:g.end.set();watch.join(timeout=35)

if __name__=='__main__':main()
