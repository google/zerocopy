"""Host-only bounded producer-contract regressions; no native invocation."""
import ast,copy,hashlib,importlib.util,json,pathlib,re
R=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('guard',R/'audit_download.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
c=json.loads((R/'CONTEXT.json').read_text());raw=(R/'primary/prior-success.json').read_bytes();stdout=(R/'primary/prior-success.stdout').read_bytes();j,duplicates=a.raw_json(raw)
checks=[]
def reject(name,fn):
 try:fn()
 except (ValueError,KeyError) as e:checks.append(dict(control=name,rejected=True,reason=str(e)));return
 raise AssertionError('negative control accepted: '+name)
# Actual producer receipt, not fabricated Fetch result arrays. This historical run had 74 planned installs and 65 source retrieval messages.
assert len(j['solution'])==74 and len(j['request']['install'])==35 and j['results']==[]
retrieved=re.findall(rb'^-> retrieved (\S+)  \((.*)\)$',stdout,re.M);names={p.decode()for p,_ in retrieved}
assert len(retrieved)==len(names)==65 and set(c['pending_exact'])<=names
out=a.download_outcome(j,stdout,set(c['pending_exact']),names-set(c['pending_exact']))
for action in ['build','install','remove','fetch']:
 bad=copy.deepcopy(j);bad['results']=[{'action':{action:{'name':'sail','version':'0.17'}},'result':'OK'}]
 reject('unexpected-result-'+action,lambda b=bad:a.download_outcome(b,stdout,names))
for field in ['download-failures','conflicts']:
 bad=copy.deepcopy(j);bad[field]={};reject('present-'+field,lambda b=bad:a.download_outcome(b,stdout,names))
bad=copy.deepcopy(j);del bad['results'];reject('absent-results',lambda:a.download_outcome(bad,stdout,names))
reject('missing-retrieval',lambda:a.download_outcome(j,b'',set(c['pending_exact'])))
reject('extra-retrieval',lambda:a.download_outcome(j,b'-> retrieved extra.1  (no changes)\n',set()))
reject('duplicate-retrieval',lambda:a.download_outcome(j,b'-> retrieved sail.0.17  (no changes)\n'*2,{'sail.0.17'}))
reject('conflicting-duplicate-json',lambda:a.raw_json(b'{"results":[],"results":[1]}'))
assert a.raw_json(b'{"results":[],"results":[]}')[1]==[{'key':'results','identical':True}]
for field in ['pre-session-commands','post-session-commands','wrap-build-commands']:
 reject('hook-'+field,lambda f=field:a.no_hooks((f+': []\n').encode()))
a.no_hooks(b'opam-version: "2.0"\n')
# Full current-state auditor rejects changed/extra solution actions before CUDF parsing. No fabricated positive current-state receipt is accepted.
base=copy.deepcopy(j);base['command-line']=c['original_argv_without_output_paths'];base['request']['install']=c['roots_ordered'];base['solution']=[{'install':{'name':x.split('.',1)[0],'version':x.split('.',1)[1]}}for x in c['pending_exact']]
for mode in ['change-action','extra-action','wrong-version']:
 bad=copy.deepcopy(base)
 if mode=='change-action':bad['solution'][0]={'remove':bad['solution'][0]['install']}
 elif mode=='extra-action':bad['solution'].append({'install':{'name':'extra','version':'1'}})
 else:bad['solution'][0]['install']['version']='0.invalid'
 reject(mode,lambda b=bad:a.audit(json.dumps(b).encode(),b'',c,c['original_argv_without_output_paths'],True,stdout))
for f in ['controller.py','transport_helpers.py','audit_download.py','regression.py']:ast.parse((R/f).read_text(),filename=f)
assert not(R/'native-run').exists()
report=dict(status='PASS_HOST_ONLY_PRODUCER_REGRESSIONS',actual_prior_results=j['results'],actual_prior_solution74=len(j['solution']),actual_prior_request35=len(j['request']['install']),actual_prior_retrieval_messages65=len(retrieved),pending21_git_consumers_all_have_prior_retrieval_message=True,prior_raw_duplicate_keys=duplicates,negative_controls=checks,current_state_positive_not_executed=True,native_run_exists=False,scope='Actual prior producer JSON/stdout schema and bounded guard negative controls. Does not substitute old empty-switch acquisition for current53 selection or run opam/native.')
(R/'REGRESSION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
