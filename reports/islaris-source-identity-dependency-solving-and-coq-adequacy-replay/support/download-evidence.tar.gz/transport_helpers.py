#!/usr/bin/env python3
"""Single experiment controller. Requires a later explicit native grant; inert without --execute-granted."""
import argparse, hashlib, json, os, pathlib, re, shlex, stat, subprocess, threading, time
ROOT = pathlib.Path(__file__).resolve().parent
CID = '47b9311b0cfb478fead61c0dea4c10f41cf6082c3567f3bc889225eb160eb397'
IMAGE = 'sha256:4a38115e6be661e04182a12c41f0e827477cf703b749a097f96344bbd56ef7b6'
DOCKER = '<HOST_TOOLS>/docker'
CACHE = '/solve/opam/download-cache/git'
PROVIDER = '/solve/offline-git-origin'
CONTROLS = '/solve/recovery-controls'
PROBES = '/solve/transport-gate'
STATE = '/solve/opam/islaris-dry/.opam-switch/switch-state'
MAX_SECONDS, MAX_WRITABLE, MIN_FREE = 900, 1073741824, 12884901888
MAX_ARTIFACT_BYTES = 268435456
GIT_ENV = dict(PATH='/usr/bin:/bin', GIT_OPTIONAL_LOCKS='0', GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1', GIT_TERMINAL_PROMPT='0', GIT_CONFIG_COUNT='6', GIT_CONFIG_KEY_0='core.hooksPath', GIT_CONFIG_VALUE_0='/dev/null', GIT_CONFIG_KEY_1='core.fsmonitor', GIT_CONFIG_VALUE_1='false', GIT_CONFIG_KEY_2='core.untrackedCache', GIT_CONFIG_VALUE_2='false', GIT_CONFIG_KEY_3='protocol.allow', GIT_CONFIG_VALUE_3='never', GIT_CONFIG_KEY_4='protocol.file.allow', GIT_CONFIG_VALUE_4='always', GIT_CONFIG_KEY_5='pack.threads', GIT_CONFIG_VALUE_5='1')

def sha(b): return hashlib.sha256(b).hexdigest()
def save(p, j): p.write_text(json.dumps(j, indent=2)+'\n')
def require(c, why):
    if not c: raise RuntimeError(why)
def parse_hashes(b):
    require(b.endswith(b'\0'), 'truncated sha256sum stream'); out={}
    for line in b[:-1].split(b'\0'):
        require(len(line)>=67 and line[64:66]==b'  ', 'sha256sum framing')
        h,p=line[:64].decode(),line[66:].decode();require(re.fullmatch('[0-9a-f]{64}',h) and p not in out, 'hash/path duplicate');out[p]=h
    return out

def parse_entries(b):
    parts=b.split(b'\0');require(parts[-1]==b'' and (len(parts)-1)%7==0,'entry framing');out={}
    for i in range(0,len(parts)-1,7):
        typ,mode,uid,gid,size,p,link=[x.decode() for x in parts[i:i+7]]
        require(p not in out,'duplicate entry');out[p]=dict(type=typ,mode=mode,uid=uid,gid=gid,size=int(size),link=link)
    return out

def artifact_bytes(root):
    # Logical bytes in the entire host native-run tree; no object bodies retained.
    total=0
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in dirs:
            require(stat.S_ISDIR(os.lstat(pathlib.Path(parent)/name).st_mode), 'unexpected host artifact directory type')
        for name in files:
            info=os.lstat(pathlib.Path(parent)/name)
            require(stat.S_ISREG(info.st_mode), 'unexpected host artifact file type')
            total+=info.st_size
    require(total<=MAX_ARTIFACT_BYTES, 'host native-run artifact threshold')
    return total

class Gate:
    def __init__(self):
        self.out=ROOT/'native-run';require(not self.out.exists(),'native-run already exists; no overwrite/retry');self.out.mkdir();self.n=0;self.started=time.monotonic();self.end=threading.Event();self.failure=None;self.stop_lock=threading.Lock();self.stopped=False
    def stop(self, reason):
        self.failure=reason
        with self.stop_lock:
            if self.stopped:return
            self.stopped=True
            argv=[DOCKER,'stop','--time','5',CID];t=time.monotonic()
            r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
            (self.out/'limit-or-failure-stop.stdout').write_bytes(r.stdout);(self.out/'limit-or-failure-stop.stderr').write_bytes(r.stderr);save(self.out/'limit-or-failure-stop.json',dict(argv=argv,status=r.returncode,seconds=time.monotonic()-t,reason=reason))
    def inspect(self, label):
        argv=[DOCKER,'inspect','--size',CID];t=time.monotonic();r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
        (self.out/(label+'.stdout')).write_bytes(r.stdout);(self.out/(label+'.stderr')).write_bytes(r.stderr);save(self.out/(label+'.json'),dict(argv=argv,status=r.returncode,seconds=time.monotonic()-t));require(r.returncode==0,'inspect failed')
        items=json.loads(r.stdout);require(len(items)==1,'inspect count');j=items[0];h=j['HostConfig']
        require(j['Id']==CID and j['Image']==IMAGE,'container/image mismatch')
        require(not any(v.split('=',1)[0].startswith('GIT_') for v in j['Config'].get('Env',[])),'unexpected inherited GIT_* container environment')
        require(h['NetworkMode']=='none' and not j['Mounts'] and h['NanoCpus']==1000000000 and h['Memory']==2147483648 and h['MemorySwap']==2147483648 and h['PidsLimit']==128 and h['SecurityOpt']==['no-new-privileges'] and j['Config']['User']=='1000:1000','runtime isolation mismatch')
        require(j['State']['Running'] and not j['State']['OOMKilled'],'container not running or OOM')
        require(j['SizeRw']<=MAX_WRITABLE,'writable layer threshold')
        st=os.statvfs(ROOT);free=st.f_bavail*st.f_frsize;size=artifact_bytes(self.out)
        save(self.out/(label+'-host-resource.json'),dict(host_free_bytes=free,native_run_logical_bytes=size,min_host_free_bytes=MIN_FREE,max_native_run_logical_bytes=MAX_ARTIFACT_BYTES,scope='Sampled observations, not filesystem quotas or memory measurements'))
        require(free>=MIN_FREE,'host-free floor')
        require(time.monotonic()-self.started<=MAX_SECONDS,'total wall cap');return j
    def watch(self):
        k=0
        while not self.end.wait(5):
            try:self.inspect('monitor-%03d'%k);k+=1
            except Exception as e:self.stop('watchdog: '+str(e));return
    def argv(self, native, mapped=False, stdin=False):
        env=dict(GIT_ENV)
        if mapped:env['GIT_CONFIG_GLOBAL']=CONTROLS+'/offline-git.config'
        a=[DOCKER,'exec']+(['-i'] if stdin else [])+['--user=1000:1000']
        for k,v in env.items():a+=['--env',k+'='+v]
        return a+[CID,'/usr/bin/timeout','--signal=TERM','--kill-after=5','120']+native
    def run(self, label, native, mapped=False, data=None):
        require(not self.failure,'watchdog failure');self.n+=1;stem='%03d-%s'%(self.n,label);a=self.argv(native,mapped,data is not None);t=time.monotonic()
        status=None;error=None
        try:
            with (self.out/(stem+'.stdout')).open('wb') as so, (self.out/(stem+'.stderr')).open('wb') as se:
                status=subprocess.run(a,input=data,stdout=so,stderr=se,timeout=135).returncode
        except Exception as ex:
            error=repr(ex)
        try:artifact_bytes(self.out)
        except Exception as ex:
            save(self.out/(stem+'-artifact-stop.json'),dict(argv=a,status=status,error=error,seconds=time.monotonic()-t,artifact_error=str(ex),stdout_bytes=(self.out/(stem+'.stdout')).stat().st_size,stderr_bytes=(self.out/(stem+'.stderr')).stat().st_size,scope='Phase status preserved without loading over-threshold output; raw streams retained'))
            raise
        b=(self.out/(stem+'.stdout')).read_bytes();e=(self.out/(stem+'.stderr')).read_bytes();save(self.out/(stem+'.json'),dict(argv=a,status=status,error=error,seconds=time.monotonic()-t,stdin_sha256=sha(data) if data is not None else None,stdout_sha256=sha(b),stderr_sha256=sha(e),stdout_bytes=len(b),stderr_bytes=len(e)))
        require(error is None and status==0,'native error '+stem+': '+str(error));require(not self.failure,'watchdog failure');return b
    def shell(self,label,script,**kw):
        # Every script is fixed controller text; source paths are shell-quoted.
        return self.run(label,['/bin/sh','-c','set -eu\n'+script],**kw)
    def hashes(self,label,paths,prune=None):
        args=['find']+paths
        if prune is not None:args+=['-path',prune,'-prune','-o']
        args+=['-type','f','-exec','sha256sum','-z','{}','+'];return parse_hashes(self.run(label,args))
    def entries(self,label,paths,prune=None):
        args=['find']+paths
        if prune is not None:args+=['-path',prune,'-prune','-o']
        args+=['-printf','%y\0%m\0%U\0%G\0%s\0%p\0%l\0'.replace('\0','\\0')];return parse_entries(self.run(label,args))
    def closure(self,label,repo,expected):
        self.n+=1;stem='%03d-%s'%(self.n,label);a=self.argv(['/usr/bin/git','-C',repo,'cat-file','--batch']);t=time.monotonic();raw=hashlib.sha256();count=0;seen={}
        # The controller uploads the selected OID list first; this command reads it natively.
        script='exec /usr/bin/git -C '+shlex.quote(repo)+' cat-file --batch < '+shlex.quote(CONTROLS+'/'+label+'.objects')
        a=self.argv(['/bin/sh','-c',script]);proc=None
        with (self.out/(stem+'.stderr')).open('wb') as se:
            proc=subprocess.Popen(a,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=se)
            try:
                while True:
                    line=proc.stdout.readline()
                    if not line:break
                    raw.update(line);parts=line.rstrip(b'\n').split();require(len(parts)==3,'object header/missing object');oid,typ,n=parts;oid=oid.decode();typ=typ.decode();n=int(n)
                    require(oid in expected and oid not in seen,'object set mismatch');want=expected[oid];require(typ==want['type'] and n==want['bytes'],'object header identity')
                    h1=hashlib.sha1(typ.encode()+b' '+str(n).encode()+b'\0');h2=hashlib.sha256();left=n
                    while left:
                        b=proc.stdout.read(min(65536,left));require(bool(b),'short object');raw.update(b);h1.update(b);h2.update(b);left-=len(b)
                    end=proc.stdout.read(1);raw.update(end);require(end==b'\n' and h1.hexdigest()==oid and h2.hexdigest()==want['sha256'],'object body identity');seen[oid]=dict(want);count+=1
                status=proc.wait(timeout=135);require(status==0,'cat-file process failure');require(set(seen)==set(expected),'closure coverage')
            except Exception:
                self.stop('object stream identity/protocol failure');raise
            finally:
                save(self.out/(stem+'.json'),dict(argv=a,status=proc.poll(),seconds=time.monotonic()-t,objects_verified=count,raw_stream_sha256=raw.hexdigest(),stderr_sha256=sha((self.out/(stem+'.stderr')).read_bytes()),raw_bodies_retained=False))
        save(self.out/(stem+'-objects.json'),dict(objects=[seen[k] for k in sorted(seen)]));require(not self.failure,'watchdog failure')
    def upload(self,name,b):
        require(re.fullmatch('[A-Za-z0-9_.-]+',name),'control name')
        self.shell('upload-'+name,'test ! -e '+shlex.quote(CONTROLS+'/'+name)+'\ncat > '+shlex.quote(CONTROLS+'/'+name)+'\nchmod 444 '+shlex.quote(CONTROLS+'/'+name),data=b)

def check_cache(g, root, expected, readonly=False):
    files=g.hashes('cache-file-hashes',[root]);entries=g.entries('cache-entries',[root]);rf={p[len(root):]:v for p,v in files.items()};recs={p[len(root):]:v for p,v in entries.items()}
    require(rf==expected['cache_files'],'cache complete content/path identity')
    require(set(recs)==set(expected['cache_entries']),'cache exact entry coverage')
    for p,w in expected['cache_entries'].items():
        r=recs[p];require(r['type']==w['type'] and r['link']==w['link'],'cache type/link identity')
        mode=int(w['mode'],8)&(~0o222 if readonly else 0o7777)
        require(int(r['mode'],8)==mode,'cache mode mismatch')
        if r['type']=='f':require(r['size']==w['size'],'cache file length')
        require(r['type'] in ['d','f'],'unexpected cache symlink/special/external object input')
    return files

def source_check(g,e,initial=True):
    objects={r['oid']:r for r in e['objects']};checked=[]
    for t in e['trees']:
        exp={x['path']:x for x in t['entries']};require(not any(x['mode']=='160000' for x in t['entries']),'gitlink in expected source')
        for package in t['consumers']:
            p='/solve/opam/islaris-dry/.opam-switch/sources/'+package
            files=g.hashes('source-files-'+package,[p],p+'/.git');entries=g.entries('source-entries-'+package,[p],p+'/.git');entries.pop(p);actual={k[len(p)+1:]:v for k,v in entries.items()};require(set(actual)==set(exp),'source exact path coverage '+package)
            for path,w in exp.items():
                a=actual[path]
                if w['type']=='tree':require(a['type']=='d','source directory type')
                elif w['mode']=='120000':require(a['type']=='l' and sha(a['link'].encode())==objects[w['oid']]['sha256'],'source symlink')
                else:require(a['type']=='f' and files[p+'/'+path]==objects[w['oid']]['sha256'] and bool(int(a['mode'],8)&0o100)==(w['mode']=='100755'),'source bytes/mode')
            # Preserve all loose refs / packed-refs and config semantics; fetch bookkeeping is not a ref.
            gitfiles=g.hashes('source-git-refs-'+package,[p+'/.git']);selected={k[len(p+'/.git'):]:v for k,v in gitfiles.items() if k in [p+'/.git/HEAD',p+'/.git/config',p+'/.git/packed-refs',p+'/.git/objects/info/alternates',p+'/.git/shallow'] or k.startswith(p+'/.git/refs/')};require(selected==e['source_ref_files'][package],'source ref/config identity '+package)
            state=g.shell('source-head-'+package,'/usr/bin/git -C '+shlex.quote(p)+' rev-parse HEAD\n/usr/bin/git -C '+shlex.quote(p)+' rev-parse --is-shallow-repository\n/usr/bin/git -C '+shlex.quote(p)+' diff --quiet\n/usr/bin/git -C '+shlex.quote(p)+' diff --cached --quiet')
            require(state.decode().splitlines()==[t['commit'],'false'],'source HEAD/shallow/diff');checked.append(package)
    require(len(checked)==21,'source consumer count');return checked

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--execute-granted',action='store_true');args=parser.parse_args()
    require(args.execute_granted,'HOST-ONLY preparation; later exact native grant required before this flag may be used')
    e=json.loads((ROOT/'EXPECTED.json').read_text());g=Gate();g.inspect('preflight-inspect');watch=threading.Thread(target=g.watch,daemon=True);watch.start()
    try:
        uid=g.shell('uid-tools','id -u\nid -g\nsha256sum /usr/bin/git /usr/bin/opam\nfor p in '+PROVIDER+' '+CONTROLS+' '+PROBES+'; do test ! -e "$p"; test ! -L "$p"; done')
        lines=uid.decode().splitlines();require(lines[:2]==['1000','1000'],'native UID/GID');require(lines[2].split()[0]=='54af380ba6ca1b36305358e99427a31ae4b0af5dc5cb6d0198c6f2f16e97651d' and lines[3].split()[0]=='8f42016825a9b10fd21802a18c22d37060c95e8c5a1d2be3df5135402c6a494d','tool executable identity')
        require(sha(g.run('switch-before',['cat',STATE]))==e['stopped_state_sha256'],'stopped switch-state mismatch')
        require(g.hashes('protected-metadata-before',['/owned-inputs'])==e['metadata_files'],'protected metadata mismatch')
        check_cache(g,CACHE,e);source_check(g,e)
        g.shell('prepare-provider-controls','mkdir -m 700 '+CONTROLS+' '+PROBES+'\nmkdir -m 700 '+CONTROLS+'/empty-template\ncp -a '+CACHE+' '+PROVIDER)
        check_cache(g,PROVIDER,e);g.shell('provider-readonly','chmod -R a-w '+PROVIDER)
        check_cache(g,PROVIDER,e,readonly=True)
        bare=g.shell('provider-layout','/usr/bin/git -C '+PROVIDER+' rev-parse --is-bare-repository\n/usr/bin/git -C '+PROVIDER+' rev-parse --is-shallow-repository\ntest ! -e '+PROVIDER+'/objects/info/alternates\ntest ! -e '+PROVIDER+'/objects/info/http-alternates\ntest ! -e '+PROVIDER+'/shallow\n/usr/bin/git -C '+PROVIDER+' config --local --list\n/usr/bin/git -C '+PROVIDER+' for-each-ref --format="%(objectname) %(refname)"')
        require(bare.decode().splitlines()[:2]==['true','false'],'provider bare/shallow identity')
        # Exact cache config bytes matched original; external includes/promisor/alternates cannot be introduced.
        require(not re.search(rb'(?i)(include|promisor|partialclone|worktree|alternates)',bare),'unexpected provider configuration')
        fsck=g.run('provider-fsck',['/usr/bin/git','-C',PROVIDER,'fsck','--full','--strict','--no-progress']);require(not fsck.strip(),'unexpected provider fsck output; review before any probe')
        allobjects={r['oid']:r for r in e['objects']};g.upload('provider.objects',(ROOT/'objects.list').read_bytes());g.closure('provider',PROVIDER,allobjects)
        g.upload('offline-git.config',(ROOT/'offline-git.config').read_bytes())
        parsed=g.run('mapped-config',['/usr/bin/git','config','--global','--get-all','url.file:///solve/offline-git-origin.insteadOf'],mapped=True);require(parsed.decode().splitlines()==[t['url'] for t in e['trees']],'exact eight URL rewrite rules')
        probes=[]
        for t in e['trees']:
            aid=t['artifact'];repo=PROBES+'/'+aid
            g.run('init-'+aid,['/usr/bin/git','init','--bare','--template='+CONTROLS+'/empty-template',repo],mapped=True)
            g.run('fetch-'+aid,['/usr/bin/git','-C',repo,'fetch','-q','--no-tags',t['url'],'+'+t['commit']+':refs/transport-gate/'+aid],mapped=True)
            state=g.shell('probe-refs-'+aid,'/usr/bin/git -C '+repo+' rev-parse refs/transport-gate/'+aid+'\n/usr/bin/git -C '+repo+' rev-parse refs/transport-gate/'+aid+'^{tree}\n/usr/bin/git -C '+repo+' rev-parse --is-shallow-repository\n/usr/bin/git -C '+repo+' for-each-ref --format="%(objectname) %(refname)"\ntest ! -e '+repo+'/objects/info/alternates\ntest ! -e '+repo+'/objects/info/http-alternates',mapped=True)
            require(state.decode().splitlines()==[t['commit'],t['tree'],'false',t['commit']+' refs/transport-gate/'+aid],'probe exact commit/tree/ref semantics')
            oids={t['commit'],t['tree']}|{x['oid'] for x in t['entries']};expected={oid:allobjects[oid] for oid in oids};g.upload(aid+'.objects',''.join(x+'\n' for x in sorted(oids)).encode());g.closure(aid,repo,expected)
            require(not g.run('fsck-'+aid,['/usr/bin/git','-C',repo,'fsck','--full','--strict','--no-progress'],mapped=True).strip(),'unexpected probe fsck output');probes.append(aid)
        # Provider/cache/state/metadata are immutable experimental inputs, not whole partial-root identity.
        check_cache(g,PROVIDER,e,readonly=True);check_cache(g,CACHE,e)
        require(sha(g.run('switch-after',['cat',STATE]))==e['stopped_state_sha256'],'switch state changed')
        require(g.hashes('protected-metadata-after',['/owned-inputs'])==e['metadata_files'],'protected metadata changed')
        source_check(g,e,initial=False);g.inspect('final-inspect')
        save(g.out/'RESULTS.json',dict(status='PASS_OFFLINE_FILE_TRANSPORT_ONLY',probes=probes,source_consumers=21,provider_objects=4935,probe_object_comparisons=sum(len({t['commit'],t['tree']}|{x['oid'] for x in t['entries']}) for t in e['trees']),installed_or_downloaded_packages=False,package_code_or_builds=False,seconds=time.monotonic()-g.started))
    except Exception as error:
        g.stop('gate stopped before retry: '+str(error));save(g.out/'FAILURE.json',dict(error=str(error),seconds=time.monotonic()-g.started));raise
    finally:g.end.set();watch.join(timeout=35)

if __name__=='__main__': main()
