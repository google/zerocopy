import json
class OperationalObservationError(ValueError): pass
def parse_inspect(status, raw):
 if status != 0: raise OperationalObservationError('Docker inspect failed; no resource sample')
 try: rows=json.loads(raw)
 except (ValueError,TypeError) as e: raise OperationalObservationError('invalid inspect JSON') from e
 if not isinstance(rows,list) or len(rows)!=1 or not isinstance(rows[0],dict): raise OperationalObservationError('expected exactly one inspect object')
 d=rows[0]
 if not isinstance(d.get('SizeRw'),int) or d['SizeRw']<0: raise OperationalObservationError('missing/invalid SizeRw')
 return d
