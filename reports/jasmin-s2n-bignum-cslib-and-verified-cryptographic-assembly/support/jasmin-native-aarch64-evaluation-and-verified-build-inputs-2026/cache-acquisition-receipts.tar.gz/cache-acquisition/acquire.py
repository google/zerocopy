from runner import *
import collections
paths=json.loads((H/'cache-fetch-191.json').read_text())['paths']
assert len(paths)==191 and len(set(paths))==191
caches=['https://cache.nixos.org','https://jasmin.cachix.org']
chosen={};metadata={};remaining=paths[:]
for index,cache in enumerate(caches):
 if not remaining:break
 r=native('cache-roots-'+str(index),[N+'nix','path-info','--store',cache,'--json','--json-format','1']+remaining,120)
 if r.returncode:raise SystemExit('metadata command failed; no fallback/copy')
 records=json.loads(r.stdout)
 if set(records)!=set(remaining):raise SystemExit('unexpected metadata membership; stop')
 absent=[]
 for path,record in records.items():
  if record is None:absent.append(path);continue
  if not isinstance(record,dict) or not record.get('narHash') or not isinstance(record.get('references'),list):raise SystemExit('metadata schema mismatch')
  if not any(s.startswith(('cache.nixos.org-1:','jasmin.cachix.org-1:')) for s in record.get('signatures',[])):raise SystemExit('no expected trusted signature; stop')
  chosen[path]=cache;metadata[path]=record
 remaining=absent
 if absent:(H/('positive-absences-'+str(index)+'.json')).write_text(json.dumps(absent,indent=2)+'\n')
if remaining:raise SystemExit('positively absent from both caches; stop')
closures={}
for index,cache in enumerate(caches):
 group=[p for p in paths if chosen[p]==cache]
 if not group:continue
 r=native('cache-closure-'+str(index),[N+'nix','path-info','--store',cache,'--recursive','--json','--json-format','1']+group,120)
 if r.returncode:raise SystemExit('closure metadata failed; stop')
 records=json.loads(r.stdout)
 if any(v is None for v in records.values()):raise SystemExit('missing closure metadata; stop')
 for path,record in records.items():
  if not any(s.startswith(('cache.nixos.org-1:','jasmin.cachix.org-1:')) for s in record.get('signatures',[])):raise SystemExit('closure lacks expected trusted signature; stop')
  if any(ref not in records for ref in record['references']):raise SystemExit('reference closure incomplete; stop')
 closures[cache]=records
(H/'selected-cache-metadata.json').write_text(json.dumps({'chosen':chosen,'roots':metadata,'closures':closures},indent=2)+'\n')
print('METADATA_PASS',json.dumps({'roots':len(chosen),'caches':dict(collections.Counter(chosen.values())),'closure_counts':{c:len(r) for c,r in closures.items()}}),flush=True)
for index,cache in enumerate(caches):
 group=[p for p in paths if chosen[p]==cache]
 if not group:continue
 r=native('copy-'+str(index),[N+'nix','copy','--from',cache]+group,600)
 if r.returncode:raise SystemExit('partial copy retained; stop, no fallback')
r=native('store-after',[N+'nix','path-info','--all','--json','--json-format','1'],120)
if r.returncode:raise SystemExit('post-copy census failed; preserve partial state')
print('ACQUISITION_COMPLETE',flush=True)
