from pathlib import Path
import subprocess,time,json,hashlib,shutil,sys,tarfile,io,os
H=Path(__file__).resolve().parent
ROOT=H.parents[1]
C='5444ba00b8675ccd8ad2d5a55c01b6b88785e06642e6e0e5ac7f459e31a46fd5'
N='/nix/store/zfhxqasf3afhlpjkjkiq32s3856hfyxn-nix-2.34.8/bin/'
U='/nix/store/j6xmasfc9kn1f8yhiy9mj46s9c3szzi8-coreutils-full-9.8/bin/'
POL=(H/'effective-evaluation-policy.txt').read_text()
ENV=['NIX_CONFIG='+POL,'NIX_PATH=','NIX_REMOTE=local','NIX_CONF_DIR=/work/config','NIX_USER_CONF_FILES=/dev/null']
FLAGS=['--arg','pinned-nixpkgs','true','--arg','inCI','false','--arg','coqMaster','false','--arg','coqDeps','true','--arg','ocamlDeps','true','--arg','safetyDeps','true','--arg','devTools','false','--arg','testDeps','false','--arg','pyDeps','false','--arg','runDeps','false','--arg','opamDeps','false','--argstr','ecRef','release']
def run(name,argv):
    start=time.monotonic();r=subprocess.run(argv,capture_output=True)
    (H/(name+'.stdout')).write_bytes(r.stdout);(H/(name+'.stderr')).write_bytes(r.stderr)
    rec={'argv':argv,'status':r.returncode,'seconds':time.monotonic()-start,'streams':{k:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in [('stdout',r.stdout),('stderr',r.stderr)]}}
    (H/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({'name':name,'status':r.returncode,'seconds':rec['seconds'],'stdout_bytes':len(r.stdout),'stderr':r.stderr.decode(errors='replace')[:3000]}),flush=True)
    return r

def native(name,argv,seconds=120):
    cmd=['docker','exec','--workdir=/work/source']
    for e in ENV:cmd+=['--env',e]
    return run(name,cmd+[C,U+'timeout','--signal=TERM','--kill-after=5',str(seconds)]+argv)
