# Native Jasmin evaluation/cache gate — PASS, realization not run

The exact pinned Jasmin environment instantiated on native aarch64-linux under Nix 2.34.8. Parse 0/0.105s, instantiate 0/48.114s, recursive derivation metadata 0/0.356s, shell dependency/cache dry-run 0/2.912s. These are evaluator/cache-planning observations, not dependency builds, proof replay or target execution. All Nix invocations used the exact evaluation-policy.txt bytes via docker exec --env, with IFD/unsafe-native false, max-jobs0, cores1, sandbox true, empty builders/build-users-group and explicit root arguments. No build/realize/install verb or nix-shell without --dry-run ran.

The root derivation is recorded in instantiate.stdout. Full exact stdout/stderr and status/argv/stream hashes are in each named receipt. derivations.stdout preserves all 1,485 schema4 records; derivation-inventory.json extracts native systems, check flags, requirements, URLs/fixed-output hashes and outputs, including structuredAttrs. The graph has 1,404 aarch64-linux and 81 builtin derivations, zero x86 host derivations. Root Jasmin and EasyCrypt have no enabled doCheck; Z3 inherits doCheck=1. LLVM/Clang big-parallel requirements occur in the recursive graph, but not in the 19 proposed uncached derivations. Do not interpret the entire graph as planned source builds.

## Exact dry-run frontier

Dry-run proposes **191 fetched paths, 988.1 MiB download, 3.0 GiB unpacked**, plus **19 uncached derivations**. Values are rounded Nix estimates, not acquired sizes or build temporary costs. cache-fetch-191.json preserves the entire fetched-path list; dry-run.stderr is the unmodified primary action text. uncached-19.json binds every proposed build to its exact drv path/output, type, system, source path, declared URLs and fixed-output hashes.

| Name | Kind | Primary-source disposition |
| --- | --- | --- |
| ocaml4.14.4-elpi-2.0.7 | package-build | cached-fetch-plan |
| rocq-core9.0-elpi-2.5.2 | package-build | cached-fetch-plan |
| rocq-core9.0-hierarchy-builder-1.9.1 | package-build | cached-fetch-plan |
| coq9.0-mathcomp-boot-2.4.0 | package-build | cached-fetch-plan |
| coq9.0-mathcomp-fingroup-2.4.0 | package-build | cached-fetch-plan |
| coq9.0-mathcomp-order-2.4.0 | package-build | cached-fetch-plan |
| coq9.0-mathcomp-algebra-2.4.0 | package-build | cached-fetch-plan |
| rocq-core9.0-stdlib-9.0.0 | package-build | cached-fetch-plan |
| coq9.0-mathcomp-ssreflect-2.4.0 | package-build | cached-fetch-plan |
| source | fixed-output-fetch | fixed-output-fetch-itself |
| coq9.0-mathcomp2.4-word-3.5-git-86ed49ae | package-build | uncached-derivation-output |
| coq9.0-coq-ext-lib-0.13.1 | package-build | cached-fetch-plan |
| setupHook.sh | generated-support-text | generated-support-text |
| easycrypt-2026.09 | package-build | cached-fetch-plan |
| ocaml4.14.4-camlidl-1.12 | package-build | cached-fetch-plan |
| ocaml4.14.4-mlgmpidl-1.3.0 | package-build | cached-fetch-plan |
| ocaml4.14.4-apron-0.9.15 | package-build | cached-fetch-plan |
| coq9.0-paco-4.2.3 | package-build | cached-fetch-plan |
| coq9.0-InteractionTrees-5.2.1 | package-build | cached-fetch-plan |

The 19 comprise 17 package builds, one generated setupHook.sh support-text derivation and one coqword fixed-output fetch/unpack derivation. Sixteen of the 17 package-build source uses correspond to 12 unique fixed-output source paths among the 191 fetched paths (MathComp shares its source across five components). Those source URLs are GitHub releases/archives for LPCIC/elpi2.0.7, LPCIC/coq-elpi2.5.2, math-comp/hierarchy-builder1.9.1, math-comp/math-comp2.4.0, rocq-prover/stdlib9.0.0, coq-community/coq-ext-lib0.13.1, easycrypt/easycrypt r2026.09, xavierleroy/camlidl112, nberth/mlgmpidl1.3.0, antoinemine/apron0.9.15, snu-sf/paco4.2.3 and DeepSpec/InteractionTrees5.2.1. Exact URLs/hash encodings are retained in uncached-19.json rather than inferred from versions.

**The 191 paths do not contain all source inputs.** coqword's source is still an uncached fixed-output derivation: https://github.com/jasmin-lang/coqword/archive/86ed49aeca65a8d32e81bb386778f49b45ee505b.tar.gz, normalized unpacked NAR hash sha256-TdjMp/4Eo9uEcUWhV3OSy/eX1GzQO2nhym3MNTzNvwY=. This hash is not a compressed tarball SHA256. Its source output path is /nix/store/bvl5ajwrawal0hq40hdh2q3vwvbi0lpq-source. The setupHook is generated text, not an upstream archive. Further, substituting a cached binary does not imply acquiring that binary's own source closure. Direct input srcs/generator scripts already registered by evaluation are distinct from the 191 future cache acquisitions; the full recursive metadata preserves these dependencies.

## Bootstrap, actual minimum and identity

Runtime identity and all resource/security settings rechecked against parent bootstrap receipts. The image manifest 71f0139a696ef851a52bebc0b8facfd20e728e0b92f7b0251480979614e24558 and config 42e5940896b215eb0fb4a0ec3705e7e09b195428636af98294d1b50120d46a87 retain their distinct roles. Nix executable SHA256 20d14cac461d9a879b9058ed1e5b5ce8112afb05dcee8f33ece9181f7e265842 matched. The /etc/group regular-file overlay remains identical 330-byte image content. Empty build-users-group is the explicitly recorded evaluation policy; this is not an unmodified-image experiment.

Pinned nixpkgs source was fetched/unpacked by evaluation. Its actual default.nix gates lib/minfeatures.nix, which requires the nixVersion builtin and reported Nix version **at least 2.18**. Nix 2.34.8 passes. Raw default/minfeatures text and read receipts are retained. The historical lib/minver.nix name was absent: that readonly cat returned 1, after which the actual source-directed minfeatures file was read. This was no package/build failure. Two host-only parser/path mistakes were diagnosed and retained, with no native source/policy alteration; no unexpected native panic/assertion/invariant occurred.

All 1,689 files/6,749,844B and modes matched fresh-source manifest/Git blobs before action; after evaluation all native files/modes and host source SHA256 values still matched. Final SizeRw 460,443,648B and host free 46,957,707,264B, no OOM. Observed samples stayed within 4 GiB writable/16 GiB free thresholds. Acquisition of pinned nixpkgs, evaluator caches/registered derivations and source copies account for writable growth; do not call these realized compiler dependencies.

## Proposed next gates — no authority to execute here

**Cache-only acquisition is practical.** With a new explicit acquisition grant, iterate exactly cache-fetch-191.json paths; query each path with `nix path-info --store https://cache.nixos.org --json PATH`, using https://jasmin.cachix.org only when the first cache reports absence. Retain the chosen cache, signed narinfo/NAR hash/reference closure and command status for every path. Then `nix copy --from CHOSEN_CACHE PATH` copies its closure without evaluating/building the 19 derivations. Use the same exact NIX_CONFIG and trust keys; never disable signature checks. This is a command template, not an executed acquisition script. It may download referenced closure paths; account for them and freeze the resulting complete cache-only path/NAR census. Missing/bad-signature/hash paths stop the gate; no source-build fallback. Do not use nix-store --realise or nix-shell as a “cache-only” substitute: preferLocalBuild makes max-jobs0 insufficient.

Suggested next cache-only allocation: unchanged CPU 1/RAM 2 GiB/PIDs 256/cap-drop-ALL/NNP/sandbox policy, 15 min, an explicitly renewed **6 GiB total SizeRw ceiling** and the existing 16 GiB host-free reserve. This is a proposed increase from the current 4 GiB gate, not granted authority. The 3.0 GiB unpack estimate plus the existing 460 MB and possible compressed/temp staging make the present 4 GiB ceiling too tight for a conservative full acquisition. Recheck estimates/signatures/reference closure first; stop at either bound. These remain observational limits unless the parent provisions a real quota; no storage consumption is claimed measured beyond the recorded observers.

**Offline-build gate comes later.** A cache-only copy of 191 paths still lacks coqword. Before network is disabled, separately authorize obtaining that exact source and verifying/registering its normalized output identity, or a narrowly reviewed fixed-output fetch realization. The current grant does not authorize that fetch/build. GitHub archive redirects may require codeload; a release archive may use release-assets hosts, but cached source acquisition avoids those upstream requests for the 12 cached source paths. No network allowlist expansion occurred here.

Then freeze all actual inputs and outputs; inspect a separate build sandbox under an expressly reviewed grant. Current cap-drop-ALL and empty build-users-group may not support Nix's inner sandbox/user setup. This is an unresolved operational prerequisite; do not loosen sandbox/capabilities or try a compiler build to discover it automatically. Offline building of the 17 packages plus generated support text must preserve exact derivations and stop on the first ordinary failure/panic with its diagnosis. Source builds/checks (including EasyCrypt and Coq dependencies) have unmeasured peak memory/time/temporary disk. Recommend a separate reviewed build allocation up to 2 CPU/12 GiB, one build at a time and a parent-enforced additional-disk/free reserve; no claim that these values suffice. EasyCrypt uses OCaml 5.4.1 while the Jasmin/Coq compiler family uses OCaml 4.14.4, so preserve both runtime closures and executable identities.

The x86-64/Linux pilot target remains explicit and independent of the native AArch64 environment. Actual Coq/checker/EC replay, compiler output, assembly bytes, theorem configuration instantiation and Rust/ABI bridge are not advanced by this evaluation-only success.
