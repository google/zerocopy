from pathlib import Path
import subprocess,time,json,hashlib,shutil,sys,tarfile,io,os
H=Path(__file__).resolve().parent
ROOT=H.parents[1]
C='5444ba00b8675ccd8ad2d5a55c01b6b88785e06642e6e0e5ac7f459e31a46fd5'
N='/nix/store/zfhxqasf3afhlpjkjkiq32s3856hfyxn-nix-2.34.8/bin/'
U='/nix/store/j6xmasfc9kn1f8yhiy9mj46s9c3szzi8-coreutils-full-9.8/bin/'
POL=(ROOT/'jasmin-eval-20261015/evaluation-policy.txt').read_text()
ENV=['NIX_CONFIG='+POL,'NIX_PATH=','NIX_REMOTE=local','NIX_CONF_DIR=/work/config','NIX_USER_CONF_FILES=/dev/null']
FLAGS=['--arg','pinned-nixpkgs','true','--arg','inCI','false','--arg','coqMaster','false','--arg','coqDeps','true','--arg','ocamlDeps','true','--arg','safetyDeps','true','--arg','devTools','false','--arg','testDeps','false','--arg','pyDeps','false','--arg','runDeps','false','--arg','opamDeps','false','--argstr','ecRef','release']
def run(name,argv):
    start=time.monotonic();r=subprocess.run(argv,capture_output=True)
    (H/(name+'.stdout')).write_bytes(r.stdout);(H/(name+'.stderr')).write_bytes(r.stderr)
    rec={'argv':argv,'status':r.returncode,'seconds':time.monotonic()-start,'streams':{k:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in [('stdout',r.stdout),('stderr',r.stderr)]}}
    (H/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({'name':name,'status':r.returncode,'seconds':rec['seconds'],'stdout_bytes':len(r.stdout),'stderr':r.stderr.decode(errors='replace')[:3000]}),flush=True)
    return r

def native(name,argv,seconds=120):
    cmd=['docker','exec','--workdir=/work/source']
    for e in ENV:cmd+=['--env',e]
    return run(name,cmd+[C,U+'timeout','--signal=TERM','--kill-after=5',str(seconds)]+argv)
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='preflight':
    r=run('inspect',['docker','inspect','--size',C]);assert r.returncode==0
    d=json.loads(r.stdout)[0];hc=d['HostConfig'];assert d['Image']=='sha256:71f0139a696ef851a52bebc0b8facfd20e728e0b92f7b0251480979614e24558' and not d['Mounts'] and hc['CapDrop']==['ALL'] and hc['Memory']==2147483648 and hc['MemorySwap']==2147483648 and hc['PidsLimit']==256 and hc['NanoCpus']==1000000000 and hc['NetworkMode']=='bridge' and 'no-new-privileges' in hc['SecurityOpt']
    assert d['SizeRw']<=4294967296 and shutil.disk_usage(H).free>=17179869184
    r=run('image',['docker','image','inspect',d['Image']]);assert r.returncode==0
    im=json.loads(r.stdout)[0];assert im['Architecture']=='arm64' and im['Os']=='linux'
    m=json.loads((ROOT/'jasmin-runtime/source-manifest.json').read_text());rows=m['files'];assert len(rows)==1689
    r=run('source-readback',['docker','cp',C+':/work/source','-']);assert r.returncode==0
    expected={x['path']:x for x in rows};seen=set()
    with tarfile.open(fileobj=io.BytesIO(r.stdout)) as t:
      for x in t:
       if x.isdir():continue
       assert x.isfile();rel=x.name.removeprefix('source/');row=expected[rel];raw=t.extractfile(x).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob'];assert x.mode==int(row['mode'],8)&0o777;seen.add(rel)
    assert seen==set(expected)
    r=native('binary-hash',[U+'sha256sum',N+'nix']);assert r.returncode==0 and r.stdout.decode().split()[0]=='20d14cac461d9a879b9058ed1e5b5ce8112afb05dcee8f33ece9181f7e265842'
    r=native('policy',[N+'nix','config','show','--json']);assert r.returncode==0
    settings=json.loads(r.stdout)
    for key,val in [('allow-import-from-derivation',False),('allow-unsafe-native-code-during-evaluation',False),('max-jobs',0),('cores',1),('sandbox',True),('build-users-group',''),('builders','')]:assert settings[key]['value']==val,(key,settings[key])
    r=native('system',[N+'nix','eval','--impure','--raw','--expr','builtins.currentSystem']);assert r.returncode==0 and r.stdout==b'aarch64-linux'
    (H/'preflight-PASS.json').write_text(json.dumps({'source_files':len(seen),'source_bytes':sum(x['bytes'] for x in rows),'policy_sha256':hashlib.sha256(POL.encode()).hexdigest(),'size_rw':d['SizeRw'],'host_free':shutil.disk_usage(H).free,'overlays':'group regular-file overlay and explicit empty build-users-group policy retained'},indent=2)+'\n')
 elif mode=='parse':native('parse',[N+'nix-instantiate','--parse','/work/source/default.nix'])
 elif mode=='instantiate':native('instantiate',[N+'nix-instantiate','/work/source/default.nix']+FLAGS,180)
 elif mode=='dry-run':native('dry-run',[N+'nix-shell','/work/source/default.nix']+FLAGS+['--pure','--dry-run'],180)

 if mode=='derivations':
    drv=(H/'instantiate.stdout').read_text().strip();assert drv.startswith('/nix/store/') and drv.endswith('.drv')
    native('derivations',[N+'nix','derivation','show','--recursive',drv],120)
