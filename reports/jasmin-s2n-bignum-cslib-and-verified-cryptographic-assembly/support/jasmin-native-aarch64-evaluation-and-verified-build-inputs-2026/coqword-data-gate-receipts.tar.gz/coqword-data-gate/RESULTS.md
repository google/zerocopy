# Jasmin data-only gate — PASS

All 191 acquired roots passed **full local NAR content and trusted-signature verification offline**, status 0 in 10.355530708s. This invocation omitted the earlier `--no-contents`; it used no repair and no network cache input. Exact argv, effective policy, complete checking transcript/status and stream hashes are preserved in full-content-signature-verify.*. The 14 preexisting content-addressed evaluator scripts remain distinct from the 191 signed acquired roots and were not assigned a false local-signature requirement.

The built-in Nix 2.34.8 `store prefetch-file --json --unpack --name source --hash-type sha256 --expected-hash ...` fetched only the authorized GitHub coqword archive for 86ed49aeca65a8d32e81bb386778f49b45ee505b. Status0 in 0.56210475s; the required normalized recursive NAR hash is exactly `sha256-TdjMp/4Eo9uEcUWhV3OSy/eX1GzQO2nhym3MNTzNvwY=` and the resulting path exactly `/nix/store/bvl5ajwrawal0hq40hdh2q3vwvbi0lpq-source`. A separate offline `nix hash path --type sha256` recomputed the same NAR hash. No normalization change, route fallback, source build script or FOD realization was used.

The helper debug log records the exact requested URL, curl 0/HTTP 200 and 21,431-byte body. It does not expose the effective redirected URL/redirect chain; no codeload or other host is claimed observed. Command help was inspected before choosing flags. Prefetch/unpack uses Nix's built-in data path rather than realizing the fixed-output derivation.

The newly registered tree contains 14 regular files/81,808 source bytes, normalized NAR 85,112 bytes, no references. coqword-file-manifest.json and the raw readback tar preserve file names/modes/SHA256/Git blob hashes and actual bytes. This locally produced content-addressed tree has no signatures; its identity is the explicitly required normalized NAR hash, independently recomputed, not a claim of binary-cache signing or Git-tree completeness authenticated through a separate Git API.

## State and resource checks

Local store census changed 2,331→2,332 paths, with **only** the expected coqword source added. All 1,689 Jasmin source files/modes remain unchanged; effective Nix config JSON is byte-identical before/after, including signature enforcement, IFD/unsafe-native false, max-jobs0, cores1, sandboxtrue, empty builders/build-users-group and pinned trusted keys. CPU 1, 2 GiB memory/swap, 256 PIDs, cap-drop-ALL, no-new-privileges and no mounts were rechecked unchanged. Every invocation supplied exact evaluation-policy bytes through docker exec --env. No package executable or source code ran.

Final quiescent resource observation succeeded: SizeRw**3,705,384,960B**, host free**42,556,002,304B**, no OOM, within the 6 GiB/16 GiB bounds. No observer/parser/hash failure, panic, invariant, retry, cleanup or policy/capability change occurred in this new gate. Prior evidence directories remain frozen.

## Exact next decision

The data prerequisites from the earlier 19-item uncached frontier are now complete: its one coqword fixed-output **data output** exists without executing that derivation. The other 18 outputs—17 package builds plus generated setupHook.sh—remain absent by the before/after census. This is not dependency compilation, actual Coq/EasyCrypt theorem replay, target execution, ABI proof or Rust composition.

Parent should disconnect network, freeze the complete selected input/path/NAR census, then grant only a separate bounded offline sandbox-feasibility test before any dependency/compiler build. Current cap-drop-ALL and empty build-users-group have not been demonstrated adequate for Nix's inner sandbox/namespace/user setup; do not infer build feasibility from data registration. First build-setup error must stop for diagnosis, with no automatic sandbox/capability relaxation. The exact source/derivation pins need not change. Any stronger runtime allocation/isolation decision belongs to that separate gate; none is authorized or attempted here.
