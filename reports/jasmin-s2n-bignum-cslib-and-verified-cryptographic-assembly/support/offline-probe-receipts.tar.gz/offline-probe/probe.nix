builtins.derivation {
  name = "anneal-owned-offline-sandbox-probe";
  system = "aarch64-linux";
  builder = "/nix/store/pbjg9k27s3v1wp5s8c6pb23s0m69yjwz-bash-5.3p9/bin/bash";
  args = [ "-c" "printf 'anneal-owned-probe\\n' > \"$out\"" ];
}
