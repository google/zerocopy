#include "riscv_model_impl.h"
#include <algorithm>
#include <cassert>
#include <random>
#include <set>
#include <unistd.h>

#include "config_utils.h"
#include "riscv_callbacks_if.h"
#include "symbol_table.h"

void ModelImpl::register_callback(std::shared_ptr<callbacks_if> cb) {
  if (std::find(m_callbacks.begin(), m_callbacks.end(), cb) == m_callbacks.end()) {
    m_callbacks.push_back(cb);
  }
}

void ModelImpl::remove_callback(std::shared_ptr<callbacks_if> cb) {
  m_callbacks.erase(std::remove(m_callbacks.begin(), m_callbacks.end(), cb), m_callbacks.end());
}

void ModelImpl::call_pre_step_callbacks(bool is_waiting) {
  for (auto c : m_callbacks) {
    c->pre_step_callback(*this, is_waiting);
  }
}

void ModelImpl::call_post_step_callbacks(bool is_waiting) {
  for (auto c : m_callbacks) {
    c->post_step_callback(*this, is_waiting);
  }
}

void ModelImpl::set_enable_experimental_extensions(bool en) {
  m_enable_experimental_extensions = en;
}

void ModelImpl::set_reservation_set_size_exp(uint64_t exponent) {
  m_reservation_set_addr_mask = ~((1 << exponent) - 1);
}

void ModelImpl::set_reservation_require_exact_addr_match(bool require_exact_addr) {
  m_reservation_require_exact_addr = require_exact_addr;
}

void ModelImpl::set_reservation_invalidate_on_same_hart_store(bool invalidate_on_same_hart_store) {
  m_reservation_invalidate_on_same_hart_store = invalidate_on_same_hart_store;
}

unit ModelImpl::fetch_callback(sbits opcode) {
  for (auto c : m_callbacks) {
    c->fetch_callback(*this, opcode);
  }
  return UNIT;
}

unit ModelImpl::mem_write_callback(const char *type, sbits paddr, int64_t width, lbits value) {
  for (auto c : m_callbacks) {
    c->mem_write_callback(*this, type, paddr, width, value);
  }
  if (m_reservation_invalidate_on_same_hart_store && match_reservation(paddr)) {
    cancel_reservation(UNIT);
  };
  return UNIT;
}
unit ModelImpl::mem_read_callback(const char *type, sbits paddr, int64_t width, lbits value) {
  for (auto c : m_callbacks) {
    c->mem_read_callback(*this, type, paddr, width, value);
  }
  return UNIT;
}

unit ModelImpl::mem_exception_callback(sbits paddr, uint64_t num_of_exception) {
  for (auto c : m_callbacks) {
    c->mem_exception_callback(*this, paddr, num_of_exception);
  }
  return UNIT;
}

unit ModelImpl::xreg_full_write_callback(const_sail_string abi_name, sbits reg, sbits value) {
  for (auto c : m_callbacks) {
    c->xreg_full_write_callback(*this, abi_name, reg, value);
  }
  return UNIT;
}

unit ModelImpl::freg_write_callback(unsigned reg, sbits value) {
  for (auto c : m_callbacks) {
    c->freg_write_callback(*this, reg, value);
  }
  return UNIT;
}

unit ModelImpl::csr_full_write_callback(const_sail_string csr_name, unsigned reg, sbits value) {
  for (auto c : m_callbacks) {
    c->csr_full_write_callback(*this, csr_name, reg, value);
  }
  return UNIT;
}

unit ModelImpl::csr_full_read_callback(const_sail_string csr_name, unsigned reg, sbits value) {
  for (auto c : m_callbacks) {
    c->csr_full_read_callback(*this, csr_name, reg, value);
  }
  return UNIT;
}

unit ModelImpl::vreg_write_callback(unsigned reg, lbits value) {
  for (auto c : m_callbacks) {
    c->vreg_write_callback(*this, reg, value);
  }
  return UNIT;
}

unit ModelImpl::pc_write_callback(sbits new_pc) {
  for (auto c : m_callbacks) {
    c->pc_write_callback(*this, new_pc);
  }
  return UNIT;
}

unit ModelImpl::redirect_callback(sbits new_pc) {
  for (auto c : m_callbacks) {
    c->redirect_callback(*this, new_pc);
  }
  return UNIT;
}

unit ModelImpl::trap_callback(bool is_interrupt, fbits cause) {
  for (auto c : m_callbacks) {
    c->trap_callback(*this, is_interrupt, cause);
  }
  return UNIT;
}

unit ModelImpl::xret_callback(bool is_mret) {
  for (auto c : m_callbacks) {
    c->xret_callback(*this, is_mret);
  }
  return UNIT;
}

unit ModelImpl::instret_callback(unit) {
  for (auto c : m_callbacks) {
    c->instret_callback(*this);
  }
  return UNIT;
}

unit ModelImpl::trigger_match_callback(sail_int index) {
  for (auto c : m_callbacks) {
    c->trigger_match_callback(*this, index);
  }
  return UNIT;
}

unit ModelImpl::trigger_fire_callback(sail_int index) {
  for (auto c : m_callbacks) {
    c->trigger_fire_callback(*this, index);
  }
  return UNIT;
}

unit ModelImpl::ptw_start_callback(
  TranslationStage stage,
  int64_t level,
  uint64_t vpn,
  MemoryAccessType access_type,
  Privilege privilege
) {
  for (auto c : m_callbacks) {
    c->ptw_start_callback(*this, stage, level, vpn, access_type, privilege);
  }
  return UNIT;
}

unit ModelImpl::ptw_step_callback(TranslationStage stage, int64_t level, sbits pte_addr, uint64_t pte) {
  for (auto c : m_callbacks) {
    c->ptw_step_callback(*this, stage, level, pte_addr, pte);
  }
  return UNIT;
}

unit ModelImpl::ptw_success_callback(TranslationStage stage, int64_t level, uint64_t final_ppn) {
  for (auto c : m_callbacks) {
    c->ptw_success_callback(*this, stage, level, final_ppn);
  }
  return UNIT;
}

unit ModelImpl::ptw_fail_callback(TranslationStage stage, int64_t level, PTW_Error error_type, sbits pte_addr) {
  for (auto c : m_callbacks) {
    c->ptw_fail_callback(*this, stage, level, error_type, pte_addr);
  }
  return UNIT;
}

unit ModelImpl::tlb_add_callback(TLB tlb, uint64_t index) {
  for (auto c : m_callbacks) {
    c->tlb_add_callback(*this, tlb, index);
  }
  return UNIT;
}

unit ModelImpl::tlb_flush_begin_callback(unit) {
  for (auto c : m_callbacks) {
    c->tlb_flush_begin_callback(*this);
  }
  return UNIT;
}

unit ModelImpl::tlb_flush_callback(uint64_t index) {
  for (auto c : m_callbacks) {
    c->tlb_flush_callback(*this, index);
  }
  return UNIT;
}

unit ModelImpl::tlb_flush_end_callback(TLB tlb) {
  for (auto c : m_callbacks) {
    c->tlb_flush_end_callback(*this, tlb);
  }
  return UNIT;
}

// Provides entropy for the scalar cryptography extension.
mach_bits ModelImpl::plat_get_16_random_bits(unit) {
  // This function can be changed to support deterministic sequences of
  // pseudo-random bytes. This is useful for testing.
  return m_gen64() & 0xFFFF;
}

// Note: Store-Conditionals are allowed to spuriously fail. If you want
// that to happen you can spuriously set `reservation_valid = false`
// either directly in `load_reservation()` or by calling
// `cancel_reservation()`.

unit ModelImpl::load_reservation(sbits addr, uint64_t width) {
  m_reservation_addr = addr.bits;
  m_reservation = addr.bits & m_reservation_set_addr_mask;
  m_reservation_valid = true;

  // Ensure the reservation set subsumes the reserved bytes.
  assert((width > 0) && (((addr.bits + width - 1) & m_reservation_set_addr_mask) == m_reservation));

  return UNIT;
}

bool ModelImpl::match_reservation(sbits addr) {
  return m_reservation_valid && (m_reservation_require_exact_addr ? (addr.bits == m_reservation_addr)
                                                                  : (m_reservation & m_reservation_set_addr_mask) ==
                                                                      (addr.bits & m_reservation_set_addr_mask));
}

unit ModelImpl::cancel_reservation(unit) {
  m_reservation_valid = false;
  return UNIT;
}

bool ModelImpl::valid_reservation(unit) {
  return m_reservation_valid;
}

bool ModelImpl::validate_event_selectors(unit) {
  std::set<EventSelector> selectors;
  std::map<Event, EventSelector> event_map;

  // The event values here have not been legalized by the model's
  // event legalizers, so handle it here.
  int64_t selector_width = zevent_selector_width(UNIT);
  uint64_t event_mask = selector_width == 64 ? -1 : (1ULL << selector_width) - 1;

  // Since this is called from Sail by `validate_config.sail`, use the
  // same print function when logging errors, i.e. `print_endline()`.
  int idx = 0;
  for (const auto *ent = zplatform_event_selectors; ent != nullptr; ent = ent->tl) {
    auto event = ent->hd.zevent;
    auto sel = ent->hd.zselector;

    std::ostringstream msg;
    std::ostringstream event_buf;
    event_buf << "event #" << idx << " (i.e. " << name_of_event(event) << ")";

    bool valid = true;
    if (sel == 0) {
      valid = false;
      msg << "The selector for " << event_buf.str()
          << " in `platform.event_selectors` is 0; selector 0 is reserved for 'no event'." << std::endl;
      print_endline(msg.str().c_str());
    }
    if ((sel & event_mask) != sel) {
      valid = false;
      msg << "The selector for " << event_buf.str() << " in `platform.event_selectors` is 0x" << std::hex << sel
          << " which does not fit in " << std::dec << selector_width << " bits." << std::endl;
      print_endline(msg.str().c_str());
    }
    if (selectors.find(sel) != selectors.end()) {
      valid = false;
      msg << "The selector 0x" << std::hex << sel << " for " << event_buf.str()
          << " in `platform.event_selectors` is repeated; event selectors need to be unique." << std::endl;
      print_endline(msg.str().c_str());
    }
    if (event_map.find(event) != event_map.end()) {
      valid = false;
      msg << "The " << event_buf.str() << " in `platform.event_selectors` repeats an event; events need to be unique."
          << std::endl;
      print_endline(msg.str().c_str());
    }

    if (!valid) {
      return false;
    }

    selectors.insert(sel);
    event_map[event] = sel;
    ++idx;
  }

  m_event_to_selector = event_map;
  return true;
}

// TODO: This code implements an exact match on selectors.
// Implementations could use a bitmask match (e.g. a bit per event).
// This could be extended to support such common cases.
unit ModelImpl::event_csr_write_callback(HpmIdx index, EventSelector old_selector, EventSelector new_selector) {
  // Unregister index for its previous selector.  `old_selector` could be
  // zero, but if so it should not be found.
  auto sel_ent = m_selector_to_hpmidxs.find(old_selector);
  if (sel_ent != m_selector_to_hpmidxs.end()) {
    sel_ent->second.erase(index);
  }

  if (new_selector == 0) {
    // No event.
    return UNIT;
  }

  auto ev_ent = std::find_if(m_event_to_selector.begin(), m_event_to_selector.end(), [&new_selector](const auto &elem) {
    return elem.second == new_selector;
  });
  if (ev_ent == m_event_to_selector.end()) {
    // TODO: this could be used as a legalizer by
    // `zihpm.sail:legalize_hpmevent()`: `new_selector` is legal only if it
    // is registered in the config.
    return UNIT;
  }

  // Register index for the new selector.
  auto &idxs = m_selector_to_hpmidxs[new_selector];
  idxs.insert(index);
  return UNIT;
}

unit ModelImpl::event_callback(Event ev, Privilege priv) {
  m_generated_events.push_back(std::make_pair(ev, priv));
  return UNIT;
}

unit ModelImpl::dispatch_events(unit) {
  for (const auto &[ev, priv] : m_generated_events) {
    auto event_ent = m_event_to_selector.find(ev);
    if (event_ent == m_event_to_selector.end()) {
      // No selector specified for this event.
      continue;
    }
    auto selector_ent = m_selector_to_hpmidxs.find(event_ent->second);
    if (selector_ent == m_selector_to_hpmidxs.end()) {
      // This selector was not written to any `mhpmevent`.
      continue;
    }
    for (const auto &idx : selector_ent->second) {
      zdispatchEventCounter(idx, priv);
    }
  }

  m_generated_events.clear();
  return UNIT;
}

unit ModelImpl::plat_term_write(mach_bits s) {
  char c = static_cast<char>(s);
  if (write(m_term_fd, &c, sizeof(c)) < 0) {
    fprintf(stderr, "Unable to write to terminal!\n");
  }
  return UNIT;
}

bool ModelImpl::sys_enable_experimental_extensions(unit) {
  return m_enable_experimental_extensions;
}

unit ModelImpl::print_string(const_sail_string prefix, const_sail_string msg) {
  printf("%s%s\n", prefix, msg);
  return UNIT;
}

unit ModelImpl::print_log(const_sail_string s) {
  fprintf(m_trace_log, "%s\n", s);
  return UNIT;
}

unit ModelImpl::print_log_instr(const_sail_string s, uint64_t pc) {
  auto maybe_symbol = symbolize_address(m_symbols, pc);
  if (maybe_symbol.has_value()) {
    fprintf(m_trace_log, "%-80s    %s+%" PRIu64 "\n", s, maybe_symbol->second.c_str(), pc - maybe_symbol->first);
  } else {
    fprintf(m_trace_log, "%s\n", s);
  }
  return UNIT;
}

unit ModelImpl::print_step(unit) {
  if (m_config_print_step) {
    fprintf(m_trace_log, "\n");
  }
  return UNIT;
}

bool ModelImpl::get_config_print_instr(unit) {
  return m_config_print_instr;
}

bool ModelImpl::get_config_print_clint(unit) {
  return m_config_print_clint;
}

bool ModelImpl::get_config_print_exception(unit) {
  return m_config_print_exception;
}

bool ModelImpl::get_config_print_interrupt(unit) {
  return m_config_print_interrupt;
}

bool ModelImpl::get_config_print_trigger(unit) {
  return m_config_print_trigger;
}

bool ModelImpl::get_config_print_htif(unit) {
  return m_config_print_htif;
}

bool ModelImpl::get_config_print_pma(unit) {
  return m_config_print_pma;
}

bool ModelImpl::get_config_print_pmp(unit) {
  return m_config_print_pmp;
}

bool ModelImpl::get_config_rvfi(unit) {
  return m_config_rvfi;
}

bool ModelImpl::get_config_use_abi_names(unit) {
  return m_config_use_abi_names;
}

mach_bits ModelImpl::get_initramfs_base(unit) {
  if (m_initramfs_region.has_value()) {
    return m_initramfs_region.value().base;
  }
  return 0;
}

mach_bits ModelImpl::get_initramfs_size(unit) {
  if (m_initramfs_region.has_value()) {
    return m_initramfs_region.value().size;
  }
  return 0;
}

void ModelImpl::set_config_print_instr(bool on) {
  m_config_print_instr = on;
}

void ModelImpl::set_config_print_clint(bool on) {
  m_config_print_clint = on;
}

void ModelImpl::set_config_print_exception(bool on) {
  m_config_print_exception = on;
}

void ModelImpl::set_config_print_interrupt(bool on) {
  m_config_print_interrupt = on;
}

void ModelImpl::set_config_print_trigger(bool on) {
  m_config_print_trigger = on;
}

void ModelImpl::set_config_print_htif(bool on) {
  m_config_print_htif = on;
}

void ModelImpl::set_config_print_pma(bool on) {
  m_config_print_pma = on;
}

void ModelImpl::set_config_print_pmp(bool on) {
  m_config_print_pmp = on;
}

void ModelImpl::set_config_rvfi(bool on) {
  m_config_rvfi = on;
}

void ModelImpl::set_config_use_abi_names(bool on) {
  m_config_use_abi_names = on;
}

void ModelImpl::set_config_print_step(bool on) {
  m_config_print_step = on;
}

void ModelImpl::set_initramfs_location(uint64_t ramfs_start, uint64_t ramfs_size) {
  m_initramfs_region = {ramfs_start, ramfs_size};
}

void ModelImpl::set_elf_symbols(std::map<uint64_t, std::string> symbols) {
  m_symbols = std::move(symbols);
}

void ModelImpl::set_term_fd(int fd) {
  m_term_fd = fd;
}

void ModelImpl::set_trace_log(FILE *log) {
  assert(log != nullptr);
  m_trace_log = log;
}

void ModelImpl::init_platform_constants() {
  set_reservation_set_size_exp(get_config_uint64({"platform", "reservation", "reservation_set_size_exp"}));
  set_reservation_require_exact_addr_match(
    get_config_bool({"platform", "reservation", "require_exact_reservation_addr"})
  );
  set_reservation_invalidate_on_same_hart_store(
    get_config_bool({"platform", "reservation", "invalidate_on_same_hart_store"})
  );

  m_supports_hypervisor = get_config_bool({"extensions", "H", "supported"});
  m_supports_D_extension = get_config_bool({"extensions", "D", "supported"});
  m_has_float_registers = get_config_bool({"extensions", "F", "supported"});
}

void ModelImpl::init_sail(
  uint64_t elf_entry,
  const char *config_file,
  const std::optional<uint64_t> &htif_tohost_address
) {
  m_elf_entry = elf_entry;
  m_config_file = config_file != nullptr ? config_file : "";
  m_htif_tohost_address = htif_tohost_address;

  init_sail_impl();
}

void ModelImpl::init_sail_impl() {
  // zset_pc_reset_address must be called before zinit_model
  // because reset happens inside init_model().
  zset_pc_reset_address(m_elf_entry);
  if (m_htif_tohost_address.has_value()) {
    zenable_htif(m_htif_tohost_address.value());
  }
  zinit_model(m_config_file.c_str());
  zinit_boot_requirements(UNIT);
}

void ModelImpl::reinit_sail() {
  model_fini();
  model_init();
  init_sail_impl();
}

void ModelImpl::model_init() {
  hart::Model::model_init();
}

void ModelImpl::model_fini() {
  m_generated_events.clear();
  m_selector_to_hpmidxs.clear();
  hart::Model::model_fini();
}

bool ModelImpl::config_is_valid() {
  return zconfig_is_valid(UNIT);
}

bool ModelImpl::dtb_within_configured_pma_memory(uint64_t addr, uint64_t size) {
  return zdtb_within_configured_pma_memory(addr, size);
}

std::vector<MemoryRegion> ModelImpl::memory_regions() const {
  std::vector<MemoryRegion> regions;
  for (const auto *region = zpma_regions; region != nullptr; region = region->tl) {
    regions.push_back({region->hd.zbase, region->hd.zsizze});
  }
  return regions;
}

std::vector<MemoryRegion> ModelImpl::main_memory_regions() const {
  std::vector<MemoryRegion> regions;
  for (const auto *region = zpma_regions; region != nullptr; region = region->tl) {
    if (region->hd.zattributes.zmem_type == hart::zMainMemory) {
      regions.push_back({region->hd.zbase, region->hd.zsizze});
    }
  }
  return regions;
}

std::string ModelImpl::generate_dts() {
  char *c_dts = nullptr;
  zgenerate_dts(&c_dts, UNIT);
  std::string dts(c_dts);
  KILL(sail_string)(&c_dts);
  return dts;
}

std::string ModelImpl::generate_isa_string() {
  char *c_isa = nullptr;
  zgenerate_canonical_isa_string(&c_isa, UNIT);
  std::string isa(c_isa);
  KILL(sail_string)(&c_isa);
  return isa;
}

std::string ModelImpl::name_of_event(Event ev) {
  sail_string str = nullptr;
  CREATE(sail_string)(&str);
  zname_of_event(&str, ev);
  std::string name(str);
  KILL(sail_string)(&str);
  return name;
}

std::optional<std::string> ModelImpl::string_of_current_exception() {
  // `current_exception` is initialized to a non-NULL value in `model_init()`.
  // So `have_exception` needs to be checked first to see if `current_exception` has
  // a valid value.
  if (!have_exception) {
    return std::nullopt;
  }
  sail_string str = nullptr;
  CREATE(sail_string)(&str);
  zstring_of_exception(&str, *current_exception);
  std::string exception_str(str);
  KILL(sail_string)(&str);
  return exception_str;
}

std::string ModelImpl::memory_access_type_to_string(MemoryAccessType access_type) {
  sail_string sstr = nullptr;
  CREATE(sail_string)(&sstr);
  zaccessType_to_str(&sstr, access_type);
  std::string str(sstr);
  KILL(sail_string)(&sstr);
  return str;
}

std::string ModelImpl::privilege_to_string(Privilege privilege) {
  sail_string sstr = nullptr;
  CREATE(sail_string)(&sstr);
  zprivLevel_to_str(&sstr, privilege);
  std::string str(sstr);
  KILL(sail_string)(&sstr);
  return str;
}

std::string ModelImpl::ptw_error_to_string(PTW_Error error_type) {
  sail_string sstr = nullptr;
  CREATE(sail_string)(&sstr);
  zptw_error_to_str(&sstr, error_type);
  std::string str(sstr);
  KILL(sail_string)(&sstr);
  return str;
}

std::string ModelImpl::translation_stage_to_string(TranslationStage stage) {
  sail_string sstr = nullptr;
  CREATE(sail_string)(&sstr);
  ztranslationStage_to_str(&sstr, stage);
  std::string str(sstr);
  KILL(sail_string)(&sstr);
  return str;
}

void ModelImpl::tick_clock() {
  ztick_clock(UNIT);
}

bool ModelImpl::try_step(int64_t step_no, bool exit_wait) {
  sail_int sail_step;
  CREATE(sail_int)(&sail_step);
  CONVERT_OF(sail_int, mach_int)(&sail_step, static_cast<mach_int>(step_no));
  bool is_waiting = ztry_step(sail_step, exit_wait);
  KILL(sail_int)(&sail_step);
  return is_waiting;
}

int64_t ModelImpl::xlen() const {
  return zxlen;
}

int64_t ModelImpl::flen() const {
  assert(m_has_float_registers);

  return zflen;
}

int64_t ModelImpl::vlen() const {
  assert(has_vector_registers());

  return zvlen;
}

int64_t ModelImpl::physaddrbits_len() const {
  return zphysaddrbits_len;
}

uint64_t ModelImpl::pc() const {
  return zPC.bits;
}

uint64_t ModelImpl::mepc() const {
  return zmepc.bits;
}

uint64_t ModelImpl::sepc() const {
  return zsepc.bits;
}

uint64_t ModelImpl::fcsr() const {
  assert(m_has_float_registers);

  return zfcsr.zbits;
}

uint64_t ModelImpl::htif_exit_code() const {
  return zhtif_exit_code;
}

bool ModelImpl::htif_done() const {
  return zhtif_done;
}

bool ModelImpl::had_exception() const {
  return have_exception;
}

uint64_t ModelImpl::xreg(int64_t reg) {
  // For the E base ISA, this assert should use 16.
  assert(0 <= reg && reg < 32);

  const sbits val = zrX(reg);
  return val.bits;
}

uint64_t ModelImpl::freg(int64_t reg) {
  // For the E base ISA, this assert should use 16.
  assert(0 <= reg && reg < 32);
  assert(m_has_float_registers);

  const sbits val = zrF(reg);
  return val.bits;
}

void ModelImpl::set_xreg(int64_t reg, uint64_t val) {
  // For the E base ISA, this assert should use 16.
  assert(0 <= reg && reg < 32);

  sbits sail_val;
  sail_val.len = zxlen;
  sail_val.bits = val;
  (void)zwX(reg, sail_val);
}

void ModelImpl::set_freg(int64_t reg, uint64_t val) {
  assert(0 <= reg && reg < 32);
  assert(m_has_float_registers);

  sbits sail_val;
  sail_val.len = zflen;
  sail_val.bits = val;
  (void)zwF(reg, sail_val);
}

void ModelImpl::set_pc(uint64_t val) {
  sbits sail_val;
  sail_val.len = zPC.len;
  sail_val.bits = val;
  (void)zset_next_pc(sail_val);
}

void ModelImpl::set_fcsr(uint64_t val) {
  assert(m_has_float_registers);

  // Split this into the FRM (val[7..5]) and FFLAGS (val[4..0]) fields.
  uint64_t frm = (val >> 5) & UINT64_C(0x7);
  uint64_t fflags = val & UINT64_C(0x1F);

  // Writing this CSR has side-effects: it dirties the FD context.
  zwrite_fcsr(frm, fflags);
}
