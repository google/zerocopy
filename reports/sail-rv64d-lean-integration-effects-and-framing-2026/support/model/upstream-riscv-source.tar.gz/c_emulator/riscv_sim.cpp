#include "riscv_sim.h"
#include "CLI11.hpp"
#include "cli_options.h"
#include "config_utils.h"
#include "elf_loader.h"
#include "file_utils.h"
#include "jsoncons/config/version.hpp"
#include "jsoncons/json.hpp"
#include "riscv_callbacks_rvfi.h"
#include "riscv_callbacks_stop_at_pc.h"
#include "riscv_model_impl.h"
#ifdef SAILCOV
#include "sail_coverage.h"
#endif
#include "gdb/target_regs.h"
#include "sail_riscv_version.h"
#include "symbol_table.h"
#include "traploop_detector.h"

#include <asio.hpp>
#include <fcntl.h>

using std::chrono::duration_cast;
using std::chrono::milliseconds;

// Internal utilities.

namespace {

void print_build_info() {
  std::cout << "Sail RISC-V release: " << version_info::release_version() << std::endl;
  std::cout << "Sail RISC-V git: " << version_info::git_version() << std::endl;
  std::cout << "Sail: " << version_info::sail_version() << std::endl;
  std::cout << "C++ compiler: " << version_info::cxx_compiler_version() << std::endl;
  std::cout << "CLI11: " << CLI11_VERSION << std::endl;
  std::cout << "ELFIO: " << ELFIO_VERSION << std::endl;
  std::cout << "JSONCONS: " << jsoncons::version() << std::endl;
  std::cout << "ASIO: " << ASIO_VERSION << std::endl;
}

jsoncons::json parse_json_or_exit(const std::string &json_text, const std::string &source_desc) {
  try {
    return jsoncons::json::parse(json_text);
  } catch (const jsoncons::json_exception &e) {
    std::cerr << "JSON parse error in " << source_desc << ":\n" << e.what() << "\n\n";
    exit(EXIT_FAILURE);
  }
}

std::string make_path_string(const std::vector<std::string> &path) {
  // This uses '/' separators for the path elements to be consistent
  // with the error messages from the jsoncons schema validator.
  if (path.empty()) {
    return "/";
  }

  std::ostringstream buf;
  for (const auto &seg : path) {
    buf << "/" << seg;
  }
  return buf.str();
}

// Merge a JSON object `json_override` into an existing JSON object `base`. The
// algorithm is as follows:
//
// 1. If both `json_override` and `base` are objects we merge them as
//    follows:
//   a) If both objects have a single field and that key has a
//      different name, this must be a union whose variant is being
//      changed (e.g. `None` to `Some`). In this case we replace the
//      entire `base` with `json_override`.
//      Note: the key might be different due to a typo in the override,
//      but that will be caught by the schema validation check.
//   b) Otherwise this is a struct, or a union with an unchanged
//      variant. In this case we loop through the keys of
//      `json_override` and recurse for each one, merging into the
//      corresponding key of `base` which must exist or an error is
//      thrown (you cannot create new keys with this function).
//
// 2. If either are not objects, then we replace `base` with
//    `json_override`. Additionally we check for type errors,
//    e.g. replacing an object with an array.

void deep_merge_json(jsoncons::json &base, const jsoncons::json &json_override, std::vector<std::string> &path) {
  if (base.type() == jsoncons::json_type::object && json_override.type() == jsoncons::json_type::object) {
    // If both are objects with size 1 this must be a union that is
    // changing its variant.  Replace the entire object.  See above
    // for the effects of a typo.
    if (base.size() == 1 && json_override.size() == 1 &&
        base.object_range().begin()->key() != json_override.object_range().begin()->key()) {
      base = json_override;
      return;
    }

    // Otherwise this is a struct or a union with the same
    // variant. Merge each key as long as it exists in the base.
    for (const auto &entry : json_override.object_range()) {
      const auto &key = entry.key();
      const auto &value = entry.value();

      path.emplace_back(key);

      if (!base.contains(key)) {
        std::ostringstream msg;
        msg << "Cannot merge override: key at path '" << make_path_string(path)
            << "' does not exist in base object; config overrides cannot add new keys to the configuration.";
        throw std::runtime_error(msg.str());
      }

      deep_merge_json(base[key], value, path);
      path.pop_back();
    }
    return;
  }

  // At least one of the arguments is not an object. Replace the base
  // with the override, but as long as the types are consistent.
  auto base_type = base.type();
  auto override_type = json_override.type();

  if (base_type != override_type) {
    std::ostringstream msg;
    msg << "Cannot override config at path '" + make_path_string(path) + "' of type '" << base_type
        << "' with incompatible type '" << override_type << "'.";
    throw std::runtime_error(msg.str());
  }

  base = json_override;
}

void write_dtb_to_rom(ModelImpl &model, const std::string &filename, elf_info &elf_info) {
  std::vector<uint8_t> dtb = read_file(filename);
  uint64_t addr = get_config_uint64({"memory", "dtb_address"});
  uint64_t size = static_cast<uint64_t>(dtb.size());

  // Overflow check for addr + size - 1
  uint64_t end = addr + size - 1;
  if (end < addr) {
    fprintf(stderr, "DTB address/size overflow: addr=0x%0" PRIx64 ", size=0x%0" PRIx64 "\n", addr, size);
    exit(EXIT_FAILURE);
  }

  // Validate DTB range against configured PMA memory regions.
  if (!model.dtb_within_configured_pma_memory(addr, size)) {
    fprintf(
      stderr,
      "DTB in '%s' does not fit in any configured PMA memory region: "
      "addr=0x%0" PRIx64 ", size=0x%0" PRIx64 " (end=0x%0" PRIx64 ")\n"
      "Hint: adjust memory.dtb_address or memory.regions in the config.\n",
      filename.c_str(),
      addr,
      size,
      end
    );
    exit(EXIT_FAILURE);
  }

  // Check for conflicts with already loaded regions.
  const auto &loaded_region_ptr =
    std::find_if(elf_info.loaded_regions.begin(), elf_info.loaded_regions.end(), [addr, size](const auto &ent) {
      return addr + size > ent.offset && ent.offset + ent.length > addr;
    });
  if (loaded_region_ptr != elf_info.loaded_regions.end()) {
    std::ostringstream msg;
    msg << "DTB in " << filename << " of size 0x" << std::hex << size << " @0x" << addr
        << " conflicts with already loaded segment from file " << loaded_region_ptr->filename << " of size 0x"
        << loaded_region_ptr->length << " @0x" << loaded_region_ptr->offset << std::endl;
    throw std::runtime_error(msg.str());
  }

  auto dtb_addr = addr;
  for (uint8_t d : dtb) {
    write_mem(addr++, d);
  }

  elf_info.loaded_regions.emplace_back(filename, dtb_addr, size);
}

// Returns the starting address in the region.
uint64_t locate_initramfs_in_region(const MemoryRegion &reg, uint64_t ramfs_size) {
  assert(reg.size >= ramfs_size);
  // Compute a placement at the top of the range, leaving a page of
  // space after. It seems most loaders (e.g. u-boot) using the
  // initramfs keep some space after.  Spike keeps one 4K page
  // after, so do the same.
  uint64_t ramfs_end = reg.base + reg.size - 0x1000U;
  return ramfs_end - ramfs_size;
}

bool load_initramfs(
  ModelImpl &model,
  const elf_info &elf_info,
  std::string initramfs_file,
  const std::vector<uint8_t> initramfs,
  bool log_locations
) {
  uint64_t ramfs_size = static_cast<uint64_t>(initramfs.size());

  // This just finds the first main memory region where it can fit,
  // locates it at the top of the range, and checks for conflicts with
  // other loaded files.
  auto regions = model.main_memory_regions();
  const auto &reg_ptr = std::find_if(regions.begin(), regions.end(), [ramfs_size, &elf_info](const auto &reg) {
    // The region should accommodate the initramfs with padding.
    if (reg.size < ramfs_size + 0x1000U) {
      return false;
    }

    auto ramfs_start = locate_initramfs_in_region(reg, ramfs_size);

    // Check for conflicts with already loaded files.
    const auto &conflict_reg = std::find_if(
      elf_info.loaded_regions.begin(),
      elf_info.loaded_regions.end(),
      [ramfs_start, ramfs_size](const auto &ent) {
        return ramfs_start + ramfs_size > ent.offset && ent.offset + ent.length > ramfs_start;
      }
    );

    // This region is okay if there is no conflict.
    return conflict_reg == elf_info.loaded_regions.end();
  });

  if (reg_ptr == regions.end()) {
    fprintf(stderr, "Could not find a suitable location in memory for initramfs from %s.\n", initramfs_file.c_str());
    return false;
  }

  auto ramfs_start = locate_initramfs_in_region(*reg_ptr, ramfs_size);
  auto addr = ramfs_start;
  for (uint8_t d : initramfs) {
    write_mem(addr++, d);
  }

  model.set_initramfs_location(ramfs_start, ramfs_size);
  if (log_locations) {
    fprintf(
      stdout,
      "Placed initramfs of size 0x%0" PRIx64 " at 0x%0" PRIx64 " (extending to 0x%0" PRIx64 ")\n",
      ramfs_size,
      ramfs_start,
      ramfs_start + ramfs_size
    );
  }
  return true;
}

void write_signature(const std::string &file, unsigned signature_granularity, const elf_info &elf_info) {
  if (elf_info.mem_sig_start >= elf_info.mem_sig_end) {
    fprintf(
      stderr,
      "Invalid signature region [0x%0" PRIx64 ",0x%0" PRIx64 "] to %s.\n",
      elf_info.mem_sig_start,
      elf_info.mem_sig_end,
      file.c_str()
    );
    return;
  }
  FILE *f = fopen(file.c_str(), "w");
  if (f == nullptr) {
    fprintf(stderr, "Cannot open file '%s': %s\n", file.c_str(), strerror(errno));
    return;
  }
  /* write out words depending on signature granularity in signature area */
  for (uint64_t addr = elf_info.mem_sig_start; addr < elf_info.mem_sig_end; addr += signature_granularity) {
    /* most-significant byte first */
    for (unsigned i = signature_granularity; i > 0; --i) {
      uint8_t byte = static_cast<uint8_t>(read_mem(addr + i - 1));
      fprintf(f, "%02x", byte);
    }
    fprintf(f, "\n");
  }
  fclose(f);
}

void write_memory_dump(const MemoryRegion &region, const std::string &prefix) {
  std::ostringstream file_os;
  file_os << prefix << ".0x" << std::hex << region.base << ".bin";
  const std::string file = file_os.str();

  FILE *f = fopen(file.c_str(), "wb");
  if (f == nullptr) {
    fprintf(stderr, "Cannot create memory dump '%s': %s\n", file.c_str(), strerror(errno));
    return;
  }

  // TODO: In C++23 we can use a literal suffix: 64 * 1024ZU
  // (upper-case due to the clang-tidy
  // `readability-uppercase-literal-suffix` check).
  constexpr size_t buffer_size = static_cast<size_t>(64 * 1024);
  std::vector<uint8_t> buffer(buffer_size);
  uint64_t offset = 0;
  while (offset < region.size) {
    size_t chunk = static_cast<size_t>(std::min<uint64_t>(buffer.size(), region.size - offset));
    for (size_t i = 0; i < chunk; ++i) {
      buffer[i] = static_cast<uint8_t>(read_mem(region.base + offset + i));
    }
    if (fwrite(buffer.data(), 1, chunk, f) != chunk) {
      fprintf(stderr, "Could not write memory dump '%s': %s\n", file.c_str(), strerror(errno));
      break;
    }
    offset += chunk;
  }

  fclose(f);
}

void write_memory_dumps(const std::vector<MemoryRegion> &regions, const std::string &prefix) {
  for (const auto &region : regions) {
    write_memory_dump(region, prefix);
  }
}

std::string describe_config(const CLIOptions &opts) {
  std::ostringstream config_desc;

  if (opts.config_file.empty()) {
    config_desc << "default configuration";
  } else {
    config_desc << "configuration in " << opts.config_file;
  }
  if (!opts.config_overrides.empty()) {
    config_desc << " merged with ";
    bool is_first = true;
    for (const auto &override_path : opts.config_overrides) {
      config_desc << (is_first ? "" : ", ") << override_path;
      is_first = false;
    }
  }

  return config_desc.str();
}

} // namespace

uint64_t load_sail(
  const CLIOptions &opts,
  ModelImpl &model,
  const std::string &filename,
  bool main_file,
  elf_info &elf_info
) {
  ELF elf = ELF::open(filename);

  switch (elf.architecture()) {
  case Architecture::RV32:
    if (model.xlen() != 32) {
      fprintf(stderr, "32-bit ELF not supported by RV%" PRIi64 " model.\n", model.xlen());
      exit(EXIT_FAILURE);
    }
    break;
  case Architecture::RV64:
    if (model.xlen() != 64) {
      fprintf(stderr, "64-bit ELF not supported by RV%" PRIi64 " model.\n", model.xlen());
      exit(EXIT_FAILURE);
    }
    break;
  }

  auto memory_regions = model.memory_regions();

  // Load into memory.
  elf.load([&filename, &elf_info, &memory_regions](uint64_t address, const uint8_t *data, uint64_t length) {
    // Ensure these ELFs are loaded into defined memory regions. Each
    // ELF segment is required to fit into a single memory
    // region. This is a conservative check: the memory regions could
    // technically be contiguous and compatible for the ELF segment,
    // but this is unlikely.
    const auto &memory_region_ptr =
      std::find_if(memory_regions.begin(), memory_regions.end(), [address, length](const auto &ent) {
        // Handle corner case where a memory region ends at 2^64 for
        // RV64. `validate_config.sail:check_pma_regions()` ensures
        // that the end of the memory region cannot exceed this bound.
        // (There is no such overflow issue for RV32.)
        return address >= ent.base && (address + length <= ent.base + ent.size || ent.base + ent.size == 0);
      });
    if (memory_region_ptr == memory_regions.end()) {
      std::ostringstream msg;
      msg << "Cannot load segment from " << filename << " of size 0x" << std::hex << length << " @0x" << address
          << " since it does not lie within any defined memory region." << std::endl;
      throw std::runtime_error(msg.str());
    }

    // Check for conflicts with already loaded regions.
    const auto &loaded_region_ptr =
      std::find_if(elf_info.loaded_regions.begin(), elf_info.loaded_regions.end(), [address, length](const auto &ent) {
        return address + length > ent.offset && ent.offset + ent.length > address;
      });
    if (loaded_region_ptr != elf_info.loaded_regions.end()) {
      std::ostringstream msg;
      msg << "Load of segment from " << filename << " of size 0x" << std::hex << length << " @0x" << address
          << " conflicts with already loaded segment from file " << loaded_region_ptr->filename << " of size 0x"
          << loaded_region_ptr->length << " @0x" << loaded_region_ptr->offset << std::endl;
      throw std::runtime_error(msg.str());
    }

    // TODO: We could definitely improve on rts.c's memory implementation
    // (which is O(N^2)) and writing one byte at a time here.
    for (uint64_t i = 0; i < length; ++i) {
      write_mem(address + i, data[i]);
    }
    elf_info.loaded_regions.emplace_back(filename, address, length);
  });

  // Load the entire symbol table.
  const auto symbols = elf.symbols();

  // Save reversed symbol table for log symbolization.
  // If multiple symbols from different ELF files have the same value the first
  // one wins.
  const auto reversed_symbols = reverse_symbol_table(symbols);
  elf_info.symbols.insert(reversed_symbols.begin(), reversed_symbols.end());

  if (main_file) {
    // Only scan for test-signature/htif symbols in the main ELF file.
    // This code might be called when generating device-tree, so do not log in that case.

    const auto &tohost = symbols.find("tohost");
    if (tohost == symbols.end()) {
      if (!opts.do_print_dts) {
        fprintf(stderr, "Unable to locate tohost symbol; disabling HTIF.\n");
      }
      elf_info.htif_tohost_address = std::nullopt;
    } else {
      elf_info.htif_tohost_address = tohost->second;
      if (!opts.do_print_dts) {
        fprintf(stdout, "HTIF located at 0x%0" PRIx64 "\n", *elf_info.htif_tohost_address);
      }
    }
    // Locate test-signature locations if any.
    const auto &begin_sig = symbols.find("begin_signature");
    if (begin_sig != symbols.end()) {
      if (!opts.do_print_dts) {
        fprintf(stdout, "begin_signature: 0x%0" PRIx64 "\n", begin_sig->second);
      }
      elf_info.mem_sig_start = begin_sig->second;
    }
    const auto &end_sig = symbols.find("end_signature");
    if (end_sig != symbols.end()) {
      if (!opts.do_print_dts) {
        fprintf(stdout, "end_signature: 0x%0" PRIx64 "\n", end_sig->second);
      }
      elf_info.mem_sig_end = end_sig->second;
    }
  }

  return elf.entry();
}

void close_logs(run_info &run_info) {
  if (run_info.close_term_fd) {
    close(run_info.term_fd);
  }
  if (run_info.trace_log != stdout) {
    fclose(run_info.trace_log);
  }
#ifdef SAILCOV
  if (sail_coverage_exit() != 0) {
    fprintf(stderr, "Could not write coverage information!\n");
    exit(EXIT_FAILURE);
  }
#endif
}

void finish(ModelImpl &model, const CLIOptions &opts, const elf_info &elf_info, run_info &run_info) {
  // Don't write a signature if there was an internal Sail exception.
  if (!model.had_exception() && !opts.sig_file.empty()) {
    write_signature(opts.sig_file, opts.signature_granularity, elf_info);
  }
  if (!opts.dump_memory_prefix.empty()) {
    write_memory_dumps(model.main_memory_regions(), opts.dump_memory_prefix);
  }

  // `model_fini()` exits with failure if there was a Sail exception.
  model.model_fini();

  if (opts.do_show_times) {
    auto run_end = steady_clock::now();
    uint64_t init_msecs = duration_cast<milliseconds>(run_info.init_end - run_info.init_start).count();
    uint64_t exec_msecs = duration_cast<milliseconds>(run_end - run_info.init_end).count();
    fprintf(stderr, "Initialization:   %" PRIu64 " ms\n", init_msecs);
    fprintf(stderr, "Execution:        %" PRIu64 " ms\n", exec_msecs);
    fprintf(stderr, "Instructions:     %" PRIu64 "\n", run_info.total_insns);
    fprintf(stderr, "Performance:      %" PRIu64 " kIPS\n", exec_msecs == 0 ? 0 : run_info.total_insns / exec_msecs);
  }
  close_logs(run_info);
  exit(model.had_exception() ? EXIT_FAILURE : EXIT_SUCCESS);
}

void flush_logs(run_info &run_info) {
  fflush(stderr);
  fflush(stdout);
  fflush(run_info.trace_log);
}

void run_sail(
  ModelImpl &model,
  const CLIOptions &opts,
  std::shared_ptr<traploop_detector> loop_detector,
  std::shared_ptr<stop_at_pc_callbacks> stop_at_pc,
  const elf_info &elf_info,
  run_info &run_info
) {
  bool is_waiting = false;
  // The emulator tick increments time by 1 at every step, so the number
  // of steps to wait is equal to the needed increment in the time CSR.
  uint64_t max_wait_steps = get_config_uint64({"platform", "max_time_to_wait"});
  uint64_t wait_steps_remaining = 0;

  /* initialize the step number */
  mach_int step_no = 0;
  uint64_t insn_cnt = 0;

  uint64_t insns_per_tick = get_config_uint64({"platform", "instructions_per_tick"});

  auto interval_start = steady_clock::now();

  while (!model.htif_done() && !(stop_at_pc && stop_at_pc->stop_requested()) &&
         (opts.insn_limit == 0 || run_info.total_insns < opts.insn_limit)) {
    if (run_info.rvfi.has_value()) {
      switch (run_info.rvfi->pre_step(opts.config_print_rvfi)) {
      case RVFI_prestep_continue:
        continue;
      case RVFI_prestep_eof:
        run_info.rvfi = std::nullopt;
        return;
      case RVFI_prestep_end_trace:
        return;
      case RVFI_prestep_ok:
        break;
      }
    }

    model.call_pre_step_callbacks(is_waiting);

    { /* run a Sail step */
      is_waiting = model.try_step(step_no, wait_steps_remaining == 0);

      std::optional<std::string> opt_str = model.string_of_current_exception();
      if (opt_str.has_value()) {
        fprintf(stdout, "%s\n", opt_str.value().c_str());
        break;
      }
      if (opts.config_print_instr) {
        flush_logs(run_info);
      }
      if (run_info.rvfi) {
        run_info.rvfi->send_trace(opts.config_print_rvfi);
      }
      if (is_waiting) {
        if (wait_steps_remaining == 0) {
          wait_steps_remaining = max_wait_steps;
        } else {
          --wait_steps_remaining;
        }
      } else {
        wait_steps_remaining = 0;
      }
    }

    model.call_post_step_callbacks(is_waiting);

    if (!is_waiting) {
      if (opts.config_print_step) {
        fprintf(run_info.trace_log, "\n");
      }
      step_no++;
      insn_cnt++;
      run_info.total_insns++;
    }

    if (opts.do_show_times && (run_info.total_insns & 0xfffff) == 0) {
      const auto now = steady_clock::now();
      const auto interval = now - interval_start;
      interval_start = now;

      uint64_t kips = 0x100000 / duration_cast<milliseconds>(interval).count();
      fprintf(stdout, "kips: %" PRIu64 "\n", kips);
    }

    if (model.htif_done()) {
      /* check exit code */
      if (model.htif_exit_code() == 0) {
        fprintf(stdout, "SUCCESS\n");
      } else {
        fprintf(stdout, "FAILURE: %" PRIu64 " (0x%08" PRIx64 ")\n", model.htif_exit_code(), model.htif_exit_code());
        exit(EXIT_FAILURE);
      }
    }

    if (insn_cnt == insns_per_tick) {
      insn_cnt = 0;
      model.tick_clock();
    } else if (wait_steps_remaining > 0) {
      model.tick_clock();
    }

    if (loop_detector->loop_detected()) {
      fprintf(
        stdout,
        "FAILURE: possible trap loop detected with MEPC=0x%" PRIx64 " and SEPC=0x%" PRIx64 "\n",
        loop_detector->mepc(),
        loop_detector->sepc()
      );
      exit(EXIT_FAILURE);
    }
  }

  // This is reached if there is a Sail exception, HTIF has indicated
  // successful completion, or the instruction limit has been reached.
  finish(model, opts, elf_info, run_info);
}

void init_logs(const CLIOptions &opts, run_info &run_info) {
  if (!opts.term_log.empty()) {
    run_info.term_fd = open(opts.term_log.c_str(), O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IRGRP | S_IROTH | S_IWUSR);
    if (run_info.term_fd < 0) {
      fprintf(stderr, "Cannot create terminal log '%s': %s\n", opts.term_log.c_str(), strerror(errno));
      exit(EXIT_FAILURE);
    }
    run_info.close_term_fd = true;
  }

  if (!opts.trace_log_path.empty()) {
    run_info.trace_log = fopen(opts.trace_log_path.c_str(), "w+");
    if (run_info.trace_log == nullptr) {
      fprintf(stderr, "Cannot create trace log '%s': %s\n", opts.trace_log_path.c_str(), strerror(errno));
      exit(EXIT_FAILURE);
    }
  }

#ifdef SAILCOV
  if (!opts.sailcov_file.empty()) {
    sail_set_coverage_file(opts.sailcov_file.c_str());
  }
#endif
}

// Processes options that don't need an initialized model and gets the
// json configuration string; returns whether to continue with model
// initialization.
InitResult preinit_args(const CLIOptions &opts, std::string &config_json_string) {
  if (opts.do_print_version) {
    std::cout << version_info::release_version() << std::endl;
    return InitResult::ExitSuccess;
  }
  if (opts.do_print_build_info) {
    print_build_info();
    return InitResult::ExitSuccess;
  }
  if (opts.do_print_default_config) {
    printf("%s", opts.use_rv32_default ? get_default_rv32_config() : get_default_config());
    return InitResult::ExitSuccess;
  }
  if (opts.do_print_config_schema) {
    printf("%s", get_config_schema());
    return InitResult::ExitSuccess;
  }

  if (opts.do_show_times) {
    fprintf(stderr, "will show execution times on completion.\n");
  }
  if (!opts.term_log.empty()) {
    fprintf(stderr, "using %s for terminal output.\n", opts.term_log.c_str());
  }
  if (!opts.sig_file.empty()) {
    fprintf(stderr, "using %s for test-signature output.\n", opts.sig_file.c_str());
  }
  if (opts.signature_granularity != DEFAULT_SIGNATURE_GRANULARITY) {
    fprintf(stderr, "setting signature-granularity to %d bytes\n", opts.signature_granularity);
  }
  if (!opts.trace_log_path.empty()) {
    fprintf(stderr, "using %s for trace output.\n", opts.trace_log_path.c_str());
  }
  if (!opts.dump_memory_prefix.empty()) {
    fprintf(stderr, "will dump main memory on completion using prefix '%s'.\n", opts.dump_memory_prefix.c_str());
  }

  if (!opts.config_file.empty()) {
    config_json_string = read_file_to_string(opts.config_file);
  } else {
    config_json_string = opts.use_rv32_default ? get_default_rv32_config() : get_default_config();
  }

  // Check json config and merge overrides
  const std::string base_source_desc =
    opts.config_file.empty() ? "default configuration" : "configuration file " + opts.config_file;
  jsoncons::json config_json = parse_json_or_exit(config_json_string, base_source_desc);
  for (const auto &override_path : opts.config_overrides) {
    std::string override_json_string = read_file_to_string(override_path);
    jsoncons::json override_item = parse_json_or_exit(override_json_string, "override file " + override_path);
    std::vector<std::string> path;
    deep_merge_json(config_json, override_item, path);
  }

  std::ostringstream os;
  os << config_json;
  config_json_string = os.str();

  // Always validate the schema conformance of the config.
  std::string config_source_desc = describe_config(opts);
  validate_config_schema(config_json, config_source_desc);

  return InitResult::Continue;
}

// Configures the model, validates the configuration, processes
// options requiring a configured model and returns whether to continue with
// model simulation.
InitResult preinit_model(
  const CLIOptions &opts,
  ModelImpl &model,
  const std::string &config_json_string,
  run_info &run_info
) {
  if (opts.rvfi_dii_port != 0) {
    run_info.rvfi.emplace(opts.rvfi_dii_port, model);
  }

  if (opts.config_enable_experimental_extensions) {
    fprintf(stderr, "enabling unratified extensions.\n");
    model.set_enable_experimental_extensions(true);
  }

  // Initialize the model.

  model.set_config_print_instr(opts.config_print_instr);
  model.set_config_print_clint(opts.config_print_clint);
  model.set_config_print_exception(opts.config_print_exception);
  model.set_config_print_interrupt(opts.config_print_interrupt);
  model.set_config_print_trigger(opts.config_print_trigger);
  model.set_config_print_htif(opts.config_print_htif);
  model.set_config_print_pma(opts.config_print_pma);
  model.set_config_print_pmp(opts.config_print_pmp);
  model.set_config_rvfi(run_info.rvfi.has_value());
  model.set_config_use_abi_names(opts.config_use_abi_names);

  model.set_config_print_step(opts.config_print_step);

  sail_config_set_string(config_json_string.c_str());

  // Initialize platform.
  model.init_platform_constants();

  model.model_init();

  // Validate the configuration; exit if that's all we were asked to do
  // or if the validation failed.
  {
    bool config_is_valid = model.config_is_valid();
    const char *s = config_is_valid ? "valid" : "invalid";
    if (!config_is_valid || opts.do_validate_config) {
      std::string config_source_desc = describe_config(opts);
      fprintf(stderr, "The %s is %s.\n", config_source_desc.c_str(), s);
      return config_is_valid ? InitResult::ExitSuccess : InitResult::ExitFailure;
    }
  }

  // Print a device tree or an ISA string only after the configuration
  // is validated above.  If there is an initramfs present, do it later
  // once it has a memory location.
  if (opts.do_print_dts && opts.initramfs_file.empty()) {
    fprintf(stdout, "%s", model.generate_dts().c_str());
    return InitResult::ExitSuccess;
  }
  if (opts.do_print_isa) {
    fprintf(stdout, "%s\n", model.generate_isa_string().c_str());
    return InitResult::ExitSuccess;
  }
  if (opts.do_print_gdb_target_xml) {
    fprintf(stdout, "%s", get_target_xml(model).c_str());
    return InitResult::ExitSuccess;
  }

  // If we get here, we need to have ELF files to run (except in RVFI mode),
  // or to place in memory for generating a device-tree with an initramfs.
  if (opts.elfs.empty() && !run_info.rvfi.has_value()) {
    fprintf(stderr, "No elf file provided.\n");
    return InitResult::ExitFailure;
  }

  init_logs(opts, run_info);
  model.set_term_fd(run_info.term_fd);
  model.set_trace_log(run_info.trace_log);

  return InitResult::Continue;
}

InitResult init_model(
  const CLIOptions &opts,
  ModelImpl &model,
  elf_info &elf_info,
  run_info &run_info,
  uint64_t &entry
) {
  run_info.init_start = steady_clock::now();

  if (run_info.rvfi.has_value()) {
    if (!run_info.rvfi->setup_socket(opts.config_print_rvfi)) {
      return InitResult::ExitFailure;
    }
    model.register_callback(std::make_shared<rvfi_callbacks>());
  }

  if (!opts.dtb_file.empty()) {
    fprintf(stderr, "using %s as DTB file.\n", opts.dtb_file.c_str());
    write_dtb_to_rom(model, opts.dtb_file, elf_info);
  }

  entry = run_info.rvfi.has_value() ? rvfi_handler::get_entry()
                                    : load_sail(opts, model, opts.elfs[0], /*main_file=*/true, elf_info);

  // Do not log if we are generating a device tree.
  if (!opts.do_print_dts) {
    fprintf(stdout, "Entry point: 0x%" PRIx64 "\n", entry);
  }

  // Load any additional ELF files into memory. If RVFI was NOT used skip
  // the first one because it was loaded above.
  for (auto it = opts.elfs.cbegin() + (run_info.rvfi.has_value() ? 0 : 1); it != opts.elfs.cend(); it++) {
    if (!opts.do_print_dts) {
      fprintf(stdout, "Loading additional ELF file %s.\n", it->c_str());
    }
    (void)load_sail(opts, model, *it, /*main_file=*/false, elf_info);
  }

  // Load the initramfs if specified after all the ELFs are loaded.
  if (!opts.initramfs_file.empty()) {
    if (!load_initramfs(model, elf_info, opts.initramfs_file, read_file(opts.initramfs_file), !opts.do_print_dts)) {
      return InitResult::ExitFailure;
    }

    // We can now print out a device-tree with the initramfs if requested.
    if (opts.do_print_dts) {
      fprintf(stdout, "%s", model.generate_dts().c_str());
      return InitResult::ExitSuccess;
    }
  }

  model.set_elf_symbols(std::move(elf_info.symbols));
  model.init_sail(entry, opts.config_file.c_str(), elf_info.htif_tohost_address);

  run_info.init_end = steady_clock::now();

  return InitResult::Continue;
}
