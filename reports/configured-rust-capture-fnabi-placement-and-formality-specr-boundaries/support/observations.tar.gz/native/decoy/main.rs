extern crate capture;
fn main() { let mut out=Vec::new(); for x in 0u16..=255 { out.push(capture::decoy(x as u8)); } println!("{:?}",out); }
