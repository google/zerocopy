#![no_std]
pub fn root(x:u8)->u8 { x.wrapping_add(1) }
