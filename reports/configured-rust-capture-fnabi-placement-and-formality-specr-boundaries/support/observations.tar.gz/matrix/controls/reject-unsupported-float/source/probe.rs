#![no_std]
pub fn root(x:u8)->u8 { x }
pub fn hidden(x:f32)->f32 { x }
