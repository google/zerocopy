pub const MASK:u8=3;
pub fn value(x:u8)->u8{x ^ MASK}
