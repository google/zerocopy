#![no_std]
mod part;
pub fn root(x:u8)->u8{part::value(x)}
