#![no_std]
trait D { fn f(&self)->u8; }
struct V(u8);
impl D for V { fn f(&self)->u8{self.0} }
pub fn root(x:u8)->u8 { let v=V(x); let d:&dyn D=&v; d.f() }
