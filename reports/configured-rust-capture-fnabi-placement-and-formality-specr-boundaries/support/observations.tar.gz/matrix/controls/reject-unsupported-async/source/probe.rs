#![no_std]
pub async fn future()->u8 {3}
pub fn root(x:u8)->u8{x}
