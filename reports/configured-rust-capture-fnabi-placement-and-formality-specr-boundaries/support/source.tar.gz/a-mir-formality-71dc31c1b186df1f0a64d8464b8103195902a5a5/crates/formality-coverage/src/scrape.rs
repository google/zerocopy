//! Discover the full set of judgments and rules in the source tree by
//! parsing `judgment_fn!` macro invocations.
//!
//! Parsing is intentionally lightweight: we do not invoke a Rust parser, we
//! only scan for `judgment_fn!` and walk the body with brace/paren matching
//! that ignores strings and `//` line comments. If the macro syntax changes,
//! the logic here must follow.
//!
//! Doc comments are masked out before scanning (see [`mask_line_comments`]),
//! since several judgments document themselves with a `judgment_fn!` or a
//! `fn main()` example that would otherwise be read as source.
//!
//! Judgments defined by tests are skipped (see [`is_test_source`] and the
//! `#[cfg(test)]` handling in [`parse_judgment_fns`]): they are fixtures for
//! the test suite, not part of the model the coverage report describes.

use anyhow::Result;
use regex::Regex;
use std::path::{Path, PathBuf};
use std::sync::LazyLock;
use walkdir::WalkDir;

/// A single judgment discovered by the scraper.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Judgment {
    pub name: String,
    pub doc_comment: String,
    pub signature: String,
    /// The `judgment_fn!` invocation as written in the source, dedented, with
    /// the rules replaced by `/* rules omitted */`. Unlike [`Judgment::signature`]
    /// this keeps the original line breaks, indentation, and any comments
    /// inside the macro, so a report page can show the judgment as its author
    /// wrote it.
    pub source_extract: String,
    pub file: String,
    pub line: u32,
    pub rules: Vec<Rule>,
}

/// A single inference rule inside a judgment.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Rule {
    pub name: String,
    pub raw_text: String,
    pub line: u32,
    /// Premises listed above the `---` separator, in source order.
    pub premises: Vec<Premise>,
}

/// One premise within a rule's body. `line` is the premise's source line,
/// used to match it against negative-coverage records (which carry the
/// failing premise's location). Infallible premises cannot fail once the
/// rule's conclusion matches, so the report renders them as N/A rather than
/// a coverage gap.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Premise {
    pub raw_text: String,
    pub kind: PremiseKind,
    pub fallible: bool,
    pub line: u32,
}

/// Coarse classification of premise syntax. A `let` premise is infallible
/// unless its body contains `?`; `if`, `if let`, and judgment-call
/// `(expr => binding)` premises are fallible.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PremiseKind {
    Let,
    If,
    IfLet,
    Judgment,
    /// Did not match any known premise shape, treated as fallible so we
    /// never mistakenly mark a rule as unblameable.
    Other,
}

/// Walk `root` recursively and scrape every `.rs` file for `judgment_fn!`
/// blocks. Results are sorted by `(file, line)` for stable output.
pub fn scrape_dir(root: &Path) -> Result<Vec<Judgment>> {
    let mut out = Vec::new();
    for entry in WalkDir::new(root) {
        let entry = match entry {
            Ok(e) => e,
            Err(err) => {
                eprintln!("warning: skipping entry under {}: {err}", root.display());
                continue;
            }
        };
        let path = entry.path();
        if path.extension().and_then(|s| s.to_str()) != Some("rs") {
            continue;
        }
        let contents = std::fs::read_to_string(path)?;
        if is_test_source(path, &contents) {
            continue;
        }
        let rel = normalize_path(path, root);
        out.extend(parse_judgment_fns(&contents, &rel));
    }
    out.sort_by(|a, b| (a.file.as_str(), a.line).cmp(&(b.file.as_str(), b.line)));
    Ok(out)
}

/// Whether a file holds test-only code, and so should be skipped: either it
/// lives under a `tests/` directory (an integration test) or it is a module
/// gated by an inner `#![cfg(test)]` attribute. Judgments defined inside an
/// inline `#[cfg(test)] mod` are skipped separately, in
/// [`parse_judgment_fns`], since the rest of such a file is real source.
pub fn is_test_source(path: &Path, contents: &str) -> bool {
    path.components().any(|c| c.as_os_str() == "tests")
        || contents.lines().any(|l| l.trim() == "#![cfg(test)]")
}

fn normalize_path(path: &Path, root: &Path) -> String {
    let rel: PathBuf = path.strip_prefix(root).unwrap_or(path).to_path_buf();
    rel.to_string_lossy().replace('\\', "/")
}

/// Scrape one file's text. `file` is the path string recorded in results.
/// Kept as a thin alias for [`parse_judgment_fns`] so existing callers and
/// tests can continue to use it.
pub fn scrape_text(text: &str, file: &str) -> Vec<Judgment> {
    parse_judgment_fns(text, file)
}

/// Find every `judgment_fn! { ... }` invocation in `content` and parse it,
/// ignoring those inside a `#[cfg(test)] mod` (see [`cfg_test_mod_ranges`]).
pub fn parse_judgment_fns(content: &str, file: &str) -> Vec<Judgment> {
    let mut judgments = Vec::new();
    // Search the mask, slice the original: offsets are the same in both.
    let masked = mask_line_comments(content);
    let cfg_test_mods = cfg_test_mod_ranges(&masked);
    let mut pos = 0;

    while let Some(start) = masked[pos..].find("judgment_fn!") {
        let abs_start = pos + start;
        if let Some(&(_, end)) = cfg_test_mods
            .iter()
            .find(|(s, e)| (*s..*e).contains(&abs_start))
        {
            pos = end;
            continue;
        }
        let jf_line = line_number(content, abs_start);

        let Some(brace_rel) = masked[abs_start..].find('{') else {
            pos = abs_start + "judgment_fn!".len();
            continue;
        };
        let brace_start = abs_start + brace_rel;

        let Some(brace_end) = find_matching_brace(content, brace_start) else {
            pos = brace_start + 1;
            continue;
        };

        if let Some(judgment) = parse_single_judgment(
            content,
            &masked,
            abs_start,
            brace_start,
            brace_end,
            file,
            jf_line,
        ) {
            judgments.push(judgment);
        }

        pos = brace_end + 1;
    }

    judgments
}

/// A copy of `content` with the body of every `//` line comment (including
/// `///` and `//!` doc comments) replaced by spaces. Byte offsets are
/// preserved, so anything found in the mask can be sliced out of the original.
/// Block comments are left alone: no judgment documents itself with one.
fn mask_line_comments(content: &str) -> String {
    let mut out = String::with_capacity(content.len());
    let mut in_string = false;
    let mut in_line_comment = false;
    let mut prev = '\0';

    for ch in content.chars() {
        if in_line_comment {
            if ch == '\n' {
                in_line_comment = false;
                out.push(ch);
            } else {
                out.extend(std::iter::repeat_n(' ', ch.len_utf8()));
            }
        } else if in_string {
            if ch == '"' && prev != '\\' {
                in_string = false;
            }
            out.push(ch);
        } else if ch == '/' && prev == '/' {
            in_line_comment = true;
            // Blank the first slash we already emitted, too.
            out.pop();
            out.push_str("  ");
        } else {
            if ch == '"' {
                in_string = true;
            }
            out.push(ch);
        }
        prev = ch;
    }

    out
}

/// Byte ranges spanned by each `#[cfg(test)] mod ... { ... }` in `content`,
/// from the attribute to the module's closing brace. A `#[cfg(test)]` on
/// anything other than a module yields no range: only a module can contain a
/// `judgment_fn!` invocation.
fn cfg_test_mod_ranges(content: &str) -> Vec<(usize, usize)> {
    const ATTR: &str = "#[cfg(test)]";
    let mut ranges = Vec::new();
    let mut pos = 0;

    while let Some(rel) = content[pos..].find(ATTR) {
        let attr_start = pos + rel;
        let after_attr = attr_start + ATTR.len();
        pos = after_attr;

        let rest = content[after_attr..].trim_start();
        if !rest.starts_with("mod ") && !rest.starts_with("pub mod ") {
            continue;
        }
        let Some(brace_rel) = content[after_attr..].find('{') else {
            continue;
        };
        let Some(close) = find_matching_brace(content, after_attr + brace_rel) else {
            continue;
        };
        ranges.push((attr_start, close));
        pos = close;
    }

    ranges
}

/// Parse the judgment defined by the `judgment_fn!` invocation that starts at
/// `macro_start` and whose block runs from `brace_start` to `brace_end`.
fn parse_single_judgment(
    content: &str,
    masked: &str,
    macro_start: usize,
    brace_start: usize,
    brace_end: usize,
    file: &str,
    jf_line: u32,
) -> Option<Judgment> {
    static FN_RE: LazyLock<Regex> = LazyLock::new(|| {
        Regex::new(r"(?s)(pub\s+)?fn\s+(\w+)\s*\((.*?)\)\s*=>\s*([^{]+)\{").unwrap()
    });

    let block = &content[brace_start + 1..brace_end];
    let doc_comment = extract_doc_comment(&content[..macro_start]);
    // Match against the masked block so a `fn` inside a doc comment cannot be
    // mistaken for the judgment's own signature, then read the captures out of
    // the real block at the same offsets.
    let captures = FN_RE.captures(&masked[brace_start + 1..brace_end])?;
    let at = |i: usize| captures.get(i).map(|m| &block[m.start()..m.end()]);

    let name = at(2)?.to_string();
    let params = at(3)?;
    let return_ty = at(4)?.trim();

    let clean_params = clean_params(params);
    let signature = format!("{name}({clean_params}) => {return_ty}");

    // The fn's opening brace ends the regex match, so everything from the
    // macro name up to there is the judgment's header.
    let header_end = brace_start + 1 + captures.get(0)?.end();
    let source_extract = source_extract(content, macro_start, header_end);

    let rules = extract_rules(block, line_number(content, brace_start + 1));

    Some(Judgment {
        name,
        doc_comment,
        signature,
        source_extract,
        file: file.to_string(),
        line: jf_line,
        rules,
    })
}

/// The judgment's header (`judgment_fn! {` through the fn's opening brace,
/// which is where `header_end` points) with the rules elided, dedented so it
/// can be dropped into a code block. The closing braces are rebuilt rather
/// than copied, since the ones in the source come after the rules.
fn source_extract(content: &str, macro_start: usize, header_end: usize) -> String {
    // Start at the beginning of the macro's line so its own indentation is
    // part of the text `dedent` measures.
    let line_start = content[..macro_start].rfind('\n').map_or(0, |i| i + 1);
    let header = dedent(&content[line_start..header_end]);
    // The header's last line closes the parameter list (`) => Foo {`), so its
    // indentation is the fn's.
    let fn_indent: String = header
        .lines()
        .next_back()
        .unwrap_or_default()
        .chars()
        .take_while(|c| c.is_whitespace())
        .collect();
    format!("{header}\n{fn_indent}    /* rules omitted */\n{fn_indent}}}\n}}")
}

/// Strip the smallest indentation shared by all non-empty lines.
fn dedent(text: &str) -> String {
    let min_indent = text
        .lines()
        .filter(|l| !l.trim().is_empty())
        .map(|l| l.len() - l.trim_start().len())
        .min()
        .unwrap_or(0);
    text.lines()
        .map(|l| {
            if l.len() >= min_indent {
                &l[min_indent..]
            } else {
                l.trim()
            }
        })
        .collect::<Vec<_>>()
        .join("\n")
}

fn extract_doc_comment(preceding: &str) -> String {
    let mut doc_lines = Vec::new();
    for line in preceding.lines().rev() {
        let trimmed = line.trim();
        if let Some(rest) = trimmed.strip_prefix("///") {
            doc_lines.push(rest.trim());
        } else if trimmed.is_empty() {
            continue;
        } else {
            break;
        }
    }
    doc_lines.reverse();
    doc_lines.join("\n")
}

fn clean_params(params: &str) -> String {
    params
        .lines()
        .map(|l| l.trim())
        .filter(|l| !l.is_empty())
        .collect::<Vec<_>>()
        .join(" ")
        .replace(" ,", ",")
}

fn extract_rules(block: &str, block_start_line: u32) -> Vec<Rule> {
    static SEPARATOR_RE: LazyLock<Regex> =
        LazyLock::new(|| Regex::new(r#"-{3,}\s*\("[^"]+"\)"#).unwrap());

    let mut rules = Vec::new();

    // Skip past an optional `debug(...)` directive at the top of the block.
    let after_debug_offset = if let Some(debug_start) = block.find("debug(") {
        let paren_close = find_matching_paren(block, debug_start + 5).unwrap_or(debug_start + 6);
        paren_close + 1
    } else {
        0
    };

    let after_debug = &block[after_debug_offset..];
    let after_debug_line_offset = block[..after_debug_offset].matches('\n').count() as u32;

    let mut pos = 0;
    while pos < after_debug.len() {
        let Some(trimmed_offset) = after_debug[pos..].find(|c: char| !c.is_whitespace()) else {
            break;
        };
        pos += trimmed_offset;

        if !after_debug[pos..].starts_with('(') {
            if let Some(nl) = after_debug[pos..].find('\n') {
                pos += nl + 1;
            } else {
                break;
            }
            continue;
        }

        let Some(close) = find_matching_paren(after_debug, pos) else {
            pos += 1;
            continue;
        };

        let rule_text = &after_debug[pos + 1..close];

        if let Some(rule_name) = extract_rule_name(rule_text) {
            let separator_line_offset = if let Some(m) = SEPARATOR_RE.find(rule_text) {
                rule_text[..m.start()].matches('\n').count() as u32
            } else {
                0
            };

            let rule_start_lines = after_debug[..pos + 1].matches('\n').count() as u32;
            // Absolute line of `rule_text`'s first character, used as the base
            // for each premise's line within the rule body.
            let rule_text_base_line = block_start_line + after_debug_line_offset + rule_start_lines;
            let abs_line = rule_text_base_line + separator_line_offset;

            let premises = extract_premises(rule_text, rule_text_base_line);

            rules.push(Rule {
                name: rule_name,
                raw_text: clean_rule_text(rule_text),
                line: abs_line,
                premises,
            });
        }

        pos = close + 1;
    }

    rules
}

/// Walk the section of `rule_text` above the `---` separator and collect
/// each parenthesized premise in source order. `base_line` is the absolute
/// source line of `rule_text`'s first character, so each premise's `line`
/// can be made absolute. A trailing `!` (match-commit marker) is tolerated
/// and dropped from the recorded text.
fn extract_premises(rule_text: &str, base_line: u32) -> Vec<Premise> {
    static SEPARATOR_RE: LazyLock<Regex> = LazyLock::new(|| Regex::new(r#"-{3,}"#).unwrap());

    let body_end = SEPARATOR_RE
        .find(rule_text)
        .map(|m| m.start())
        .unwrap_or(rule_text.len());
    let body = &rule_text[..body_end];

    let mut premises = Vec::new();
    let mut pos = 0;
    while pos < body.len() {
        let Some(trimmed) = body[pos..].find(|c: char| !c.is_whitespace()) else {
            break;
        };
        pos += trimmed;
        if !body[pos..].starts_with('(') {
            // Skip past any stray characters to the next line.
            if let Some(nl) = body[pos..].find('\n') {
                pos += nl + 1;
                continue;
            }
            break;
        }
        let Some(close) = find_matching_paren(body, pos) else {
            pos += 1;
            continue;
        };
        let inner = &body[pos + 1..close];
        let (kind, fallible) = classify_premise(inner);
        let line = base_line + body[..pos].matches('\n').count() as u32;
        premises.push(Premise {
            raw_text: inner.trim().to_string(),
            kind,
            fallible,
            line,
        });
        pos = close + 1;
        // Skip an optional `!` match-commit marker after the closing paren.
        if body[pos..].starts_with('!') {
            pos += 1;
        }
    }
    premises
}

/// Classify a premise by its leading tokens and decide whether it can fail:
/// `let` is infallible unless its body contains a `?`; every other recognized
/// shape is fallible.
fn classify_premise(inner: &str) -> (PremiseKind, bool) {
    let trimmed = inner.trim_start();
    if let Some(rest) = trimmed.strip_prefix("let ") {
        let fallible = rest.contains('?');
        return (PremiseKind::Let, fallible);
    }
    if let Some(rest) = trimmed.strip_prefix("if ") {
        if rest.trim_start().starts_with("let ") {
            return (PremiseKind::IfLet, true);
        }
        return (PremiseKind::If, true);
    }
    if trimmed.contains("=>") {
        return (PremiseKind::Judgment, true);
    }
    (PremiseKind::Other, true)
}

fn extract_rule_name(rule_text: &str) -> Option<String> {
    static NAME_RE: LazyLock<Regex> =
        LazyLock::new(|| Regex::new(r#"-{3,}\s*\("([^"]+)"\)"#).unwrap());
    let captures = NAME_RE.captures(rule_text)?;
    Some(captures.get(1)?.as_str().to_string())
}

fn clean_rule_text(rule_text: &str) -> String {
    let lines: Vec<&str> = rule_text.lines().collect();

    let min_indent = lines
        .iter()
        .filter(|l| !l.trim().is_empty())
        .map(|l| l.len() - l.trim_start().len())
        .min()
        .unwrap_or(0);

    lines
        .iter()
        .map(|l| {
            if l.trim().is_empty() {
                ""
            } else if l.len() >= min_indent {
                &l[min_indent..]
            } else {
                l.trim()
            }
        })
        .filter(|l| !l.trim_start().starts_with("//"))
        .collect::<Vec<_>>()
        .join("\n")
        .trim()
        .to_string()
}

fn find_matching_brace(content: &str, open_pos: usize) -> Option<usize> {
    find_matching(content, open_pos, '{', '}')
}

fn find_matching_paren(content: &str, open_pos: usize) -> Option<usize> {
    find_matching(content, open_pos, '(', ')')
}

fn find_matching(content: &str, open_pos: usize, open: char, close: char) -> Option<usize> {
    let mut depth = 0;
    let mut in_string = false;
    let mut in_line_comment = false;
    let mut prev_char = '\0';

    for (i, ch) in content[open_pos..].char_indices() {
        if in_line_comment {
            if ch == '\n' {
                in_line_comment = false;
            }
            prev_char = ch;
            continue;
        }

        if in_string {
            if ch == '"' && prev_char != '\\' {
                in_string = false;
            }
            prev_char = ch;
            continue;
        }

        if ch == '/' && prev_char == '/' {
            in_line_comment = true;
            prev_char = ch;
            continue;
        }

        if ch == '"' {
            in_string = true;
            prev_char = ch;
            continue;
        }

        if ch == open {
            depth += 1;
        } else if ch == close {
            depth -= 1;
            if depth == 0 {
                return Some(open_pos + i);
            }
        }

        prev_char = ch;
    }

    None
}

fn line_number(text: &str, byte_offset: usize) -> u32 {
    let upto = &text[..byte_offset.min(text.len())];
    (upto.bytes().filter(|&b| b == b'\n').count() as u32) + 1
}
