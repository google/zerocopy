//! End-to-end-ish tests for the scraper + report generator. Uses inline
//! fixtures (a fake `judgment_fn!` source snippet) so the tests don't depend
//! on the live `formality-rust` source layout.

use std::collections::{BTreeMap, BTreeSet};
use std::path::Path;

use expect_test::expect;
use formality_core::judgment::coverage::{FailedRuleNode, FailedTreeNode, ProofTreeNode};
use formality_coverage::jsonl::{
    self, Coverage, CoveredRule, NoApplicableRuleLoc, PremiseLoc, TestLoc,
};
use formality_coverage::report;
use formality_coverage::scrape::{
    is_test_source, scrape_text, Judgment, Premise, PremiseKind, Rule,
};

fn premise(raw: &str, kind: PremiseKind, fallible: bool, line: u32) -> Premise {
    Premise {
        raw_text: raw.into(),
        kind,
        fallible,
        line,
    }
}

/// A rule with one fallible premise on `premise_line`, for report snapshots.
fn rule_with_premise(name: &str, line: u32, premise_line: u32) -> Rule {
    Rule {
        name: name.into(),
        raw_text: format!("(if true)\n----- (\"{name}\")\n(prove_thing(x) => ())"),
        line,
        premises: vec![premise("if true", PremiseKind::If, true, premise_line)],
    }
}

const FIXTURE: &str = r#"
use formality_core::judgment_fn;

judgment_fn! {
    /// doc comment
    pub fn prove_thing(x: u32) => () {
        debug(x)

        (
            (if x > 0)
            --------------------------------------- ("positive")
            (prove_thing(x) => ())
        )

        (
            (if x == 0)
            --- ("zero")
            (prove_thing(x) => ())
        )
    }
}

judgment_fn! {
    fn only_one(x: u32) => () {
        debug(x)

        (
            (if x == 1)
            ----- ("one")
            (only_one(x) => ())
        )
    }
}
"#;

#[test]
fn scrapes_judgments_and_rules() {
    let got = scrape_text(FIXTURE, "fixture.rs");
    assert_eq!(got.len(), 2);

    assert_eq!(got[0].name, "prove_thing");
    assert_eq!(got[0].file, "fixture.rs");
    let rule_names: Vec<&str> = got[0].rules.iter().map(|r| r.name.as_str()).collect();
    assert_eq!(rule_names, vec!["positive", "zero"]);

    assert_eq!(got[1].name, "only_one");
    let rule_names: Vec<&str> = got[1].rules.iter().map(|r| r.name.as_str()).collect();
    assert_eq!(rule_names, vec!["one"]);
}

#[test]
fn rule_line_numbers_are_absolute() {
    let got = scrape_text(FIXTURE, "fixture.rs");
    let positive = got[0].rules.iter().find(|r| r.name == "positive").unwrap();
    let expected_line = FIXTURE
        .lines()
        .position(|l| l.contains(r#"("positive")"#))
        .unwrap() as u32
        + 1;
    assert_eq!(positive.line, expected_line);
}

#[test]
fn premises_carry_absolute_lines() {
    let got = scrape_text(FIXTURE, "fixture.rs");
    let positive = got[0].rules.iter().find(|r| r.name == "positive").unwrap();
    assert_eq!(positive.premises.len(), 1);
    let p = &positive.premises[0];
    assert_eq!(p.kind, PremiseKind::If);
    assert!(p.fallible);
    let expected_line = FIXTURE
        .lines()
        .position(|l| l.contains("if x > 0"))
        .unwrap() as u32
        + 1;
    assert_eq!(p.line, expected_line);
}

#[test]
fn scrapes_premises_with_fallibility_tags() {
    const SRC: &str = r#"
judgment_fn! {
    fn mixed(x: u32) => () {
        debug(x)

        (
            (let y = x)
            (if y > 0)
            (if let Some(z) = thing)
            (sub_judgment(y) => ())
            --- ("kitchen sink")
            (mixed(x) => ())
        )

        (
            (let y = x?)
            --- ("fallible let")
            (mixed(x) => ())
        )

        (
            (let y = x)
            --- ("all infallible")
            (mixed(x) => ())
        )
    }
}
"#;
    let got = scrape_text(SRC, "src.rs");
    assert_eq!(got.len(), 1);
    let rules = &got[0].rules;
    assert_eq!(rules.len(), 3);

    let kitchen = rules.iter().find(|r| r.name == "kitchen sink").unwrap();
    let kinds: Vec<PremiseKind> = kitchen.premises.iter().map(|p| p.kind).collect();
    assert_eq!(
        kinds,
        vec![
            PremiseKind::Let,
            PremiseKind::If,
            PremiseKind::IfLet,
            PremiseKind::Judgment,
        ]
    );
    let fallibilities: Vec<bool> = kitchen.premises.iter().map(|p| p.fallible).collect();
    assert_eq!(fallibilities, vec![false, true, true, true]);
    // Premise lines are strictly increasing within the rule body.
    let lines: Vec<u32> = kitchen.premises.iter().map(|p| p.line).collect();
    assert!(lines.windows(2).all(|w| w[0] < w[1]), "lines: {lines:?}");

    let fallible_let = rules.iter().find(|r| r.name == "fallible let").unwrap();
    assert_eq!(fallible_let.premises.len(), 1);
    assert_eq!(fallible_let.premises[0].kind, PremiseKind::Let);
    assert!(
        fallible_let.premises[0].fallible,
        "`let y = x?` must be flagged fallible because of the `?`"
    );

    let all_inf = rules.iter().find(|r| r.name == "all infallible").unwrap();
    assert!(all_inf.premises.iter().all(|p| !p.fallible));
}

#[test]
fn source_extract_keeps_the_header_and_drops_the_rules() {
    let got = scrape_text(FIXTURE, "fixture.rs");
    expect![[r#"
        judgment_fn! {
            /// doc comment
            pub fn prove_thing(x: u32) => () {
                /* rules omitted */
            }
        }"#]]
    .assert_eq(&got[0].source_extract);
}

/// A judgment whose doc comment contains a code example: the example must not
/// be read as the judgment's own source (`prove_outlives` used to be scraped
/// under the name `main` for exactly this reason).
#[test]
fn doc_comment_examples_are_not_scraped() {
    const SRC: &str = r#"
/// Documented with an example:
///
/// ```rust,ignore
/// judgment_fn! {
///     fn not_a_judgment(x: u32) => () { }
/// }
///
/// fn main() {
///     documented(1);
/// }
/// ```
judgment_fn! {
    pub fn documented(x: u32) => () {
        (
            (if x > 0)
            --- ("positive")
            (documented(x) => ())
        )
    }
}
"#;
    let got = scrape_text(SRC, "src.rs");
    let names: Vec<&str> = got.iter().map(|j| j.name.as_str()).collect();
    assert_eq!(names, vec!["documented"]);
    assert_eq!(got[0].signature, "documented(x: u32) => ()");
}

#[test]
fn skips_judgments_in_cfg_test_mods() {
    const SRC: &str = r#"
judgment_fn! {
    fn real(x: u32) => () {
        (
            (if x > 0)
            --- ("real")
            (real(x) => ())
        )
    }
}

#[cfg(test)]
mod tests {
    judgment_fn! {
        fn fixture(x: u32) => () {
            (
                (if x > 0)
                --- ("fixture")
                (fixture(x) => ())
            )
        }
    }
}
"#;
    let names: Vec<String> = scrape_text(SRC, "src.rs")
        .into_iter()
        .map(|j| j.name)
        .collect();
    assert_eq!(names, vec!["real"]);
}

#[test]
fn recognizes_test_sources() {
    assert!(is_test_source(
        Path::new("formality-core/tests/coverage.rs"),
        ""
    ));
    assert!(is_test_source(
        Path::new("formality-core/src/judgment/test_for_all.rs"),
        "#![cfg(test)]

use crate::judgment_fn;
",
    ));
    assert!(!is_test_source(
        Path::new("formality-rust/src/prove/prove_wc.rs"),
        "use crate::judgment_fn;
",
    ));
}

/// Two-rule `prove_thing` judgment: `positive` (premise on line 9, tested
/// negatively) and `zero` (premise on line 15, never tested negatively).
fn prove_thing_judgment() -> Judgment {
    Judgment {
        name: "prove_thing".into(),
        doc_comment: String::new(),
        signature: "prove_thing(x: u32) => ()".into(),
        source_extract: String::new(),
        file: "fixture.rs".into(),
        line: 4,
        rules: vec![
            rule_with_premise("positive", 10, 9),
            rule_with_premise("zero", 16, 15),
        ],
    }
}

/// Coverage where `prove_thing`'s `positive` premise (line 9) failed in a
/// negative test with cause `if_false`, but `zero`'s premise (line 15) never did.
fn prove_thing_coverage() -> Coverage {
    let positive_premise = PremiseLoc {
        file: "crates/sub/fixture.rs".into(),
        line: 9,
    };
    let mut negative_premises = BTreeMap::new();
    negative_premises.insert(
        positive_premise.clone(),
        BTreeSet::from(["if_false".to_string()]),
    );
    let mut negative_premise_tests = BTreeMap::new();
    negative_premise_tests.insert(
        positive_premise,
        BTreeSet::from([TestLoc {
            file: "tests/prove_thing.rs".into(),
            line: 99,
        }]),
    );
    Coverage {
        positive: BTreeMap::from([(
            CoveredRule {
                judgment: "prove_thing".into(),
                rule: "positive".into(),
            },
            BTreeSet::from([TestLoc {
                file: "tests/prove_thing.rs".into(),
                line: 42,
            }]),
        )]),
        negative_premises,
        negative_premise_tests,
        no_applicable_rule: BTreeSet::new(),
        ..Default::default()
    }
}

/// Base URL used in report snapshots to exercise the test-link rendering.
const GITHUB_BASE: &str = "https://github.com/example/repo/blob/main";

#[test]
fn markdown_index_snapshot() {
    let judgments = vec![prove_thing_judgment()];
    let cov = prove_thing_coverage();
    let md = report::render_index(&judgments, &cov);
    expect![[r#"
        # Coverage report

        | Judgment/Rule | Positive coverage | Negative coverage |
        | --- | --- | --- |
        | **[prove_thing](./prove_thing.md)** | - | - |
        | ↳ [positive](./prove_thing.md#positive) | [1 test](./prove_thing__positive__pos.md) | 1/1 |
        | ↳ [zero](./prove_thing.md#zero) | ✗ | 0/1 |


        ---

        [How to read this page](./coverage-how-to-read.md)
    "#]]
    .assert_eq(&md);
}

#[test]
fn markdown_subpage_snapshot() {
    let j = prove_thing_judgment();
    let cov = prove_thing_coverage();
    let md = report::render_subpage(&j, &cov, "md", None);
    expect![[r##"
        # Judgment `prove_thing`

        Source: `fixture.rs:4`

        The number on each rule's conclusion is **positive** coverage; the number on each premise is **negative** coverage. Click a number to browse the tests.

        <style>
        .cov-rule{border:1px solid var(--quote-border,#d0d0d0);border-radius:6px;margin:1rem 0;overflow:hidden}
        .cov-rule-head{padding:.4rem .8rem;background:var(--quote-bg,#f6f7f9);font-weight:600}
        table.cov-code{width:100%;border-collapse:collapse;font-family:var(--mono-font,monospace);font-size:.85em;margin:0}
        table.cov-code td{padding:.15rem .6rem;border:0}
        table.cov-code th{padding:.15rem .6rem;border:0;border-bottom:1px solid var(--quote-border,#d0d0d0);color:#888;font-weight:600;font-size:.9em}
        .cov-ln{text-align:right;color:#999;user-select:none;width:3em;white-space:nowrap}
        .cov-num{text-align:right;width:3.5em;white-space:nowrap;font-weight:600}
        .cov-num.pos a{color:#1a7f37}
        .cov-num.neg a{color:#b35900}
        .cov-none{color:#bbb}
        .cov-na{color:#bbb;font-weight:400}
        .cov-src-line{white-space:pre-wrap}
        tr.cov-sep td{color:#999}
        tr.cov-concl{background:rgba(127,127,127,.08)}
        table.cov-code tr.cov-current td{background:rgba(31,120,255,.28)}
        ul.cov-tree,ul.cov-tree ul{list-style:none;margin:0;padding-left:1.2em;font-family:var(--mono-font,monospace)}
        ul.cov-tree{font-size:.85em}
        ul.cov-tree ul{font-size:1em}
        ul.cov-tree code{font-size:inherit}
        ul.cov-tree summary{cursor:pointer}
        .cov-tree-loc{color:#888}
        .cov-tree-fail{color:#b35900}
        .cov-tree-scroll{overflow-x:auto}
        ul.cov-tree li,ul.cov-tree summary{white-space:nowrap}
        </style>

        <div class="cov-rule" id="positive">
        <div class="cov-rule-head"><code>positive</code></div>
        <table class="cov-code">
        <thead><tr><th class="cov-ln">Line</th><th class="cov-num">Coverage</th><th class="cov-src-line">Source</th></tr></thead>
        <tr><td class="cov-ln">9</td><td class="cov-num neg"><a href="./prove_thing__positive__p9__neg.md" title="failure causes: if_false">1</a></td><td class="cov-src-line">(if true)</td></tr>
        <tr class="cov-sep"><td class="cov-ln"></td><td class="cov-num"></td><td class="cov-src-line">──────── ("positive")</td></tr>
        <tr class="cov-concl"><td class="cov-ln">11</td><td class="cov-num pos"><a href="./prove_thing__positive__pos.md">1</a></td><td class="cov-src-line">(prove_thing(x) =&gt; ())</td></tr>
        </table>
        </div>

        <div class="cov-rule" id="zero">
        <div class="cov-rule-head"><code>zero</code></div>
        <table class="cov-code">
        <thead><tr><th class="cov-ln">Line</th><th class="cov-num">Coverage</th><th class="cov-src-line">Source</th></tr></thead>
        <tr><td class="cov-ln">15</td><td class="cov-num neg"><span class="cov-none">✗</span></td><td class="cov-src-line">(if true)</td></tr>
        <tr class="cov-sep"><td class="cov-ln"></td><td class="cov-num"></td><td class="cov-src-line">──────── ("zero")</td></tr>
        <tr class="cov-concl"><td class="cov-ln">17</td><td class="cov-num pos"><span class="cov-none">✗</span></td><td class="cov-src-line">(prove_thing(x) =&gt; ())</td></tr>
        </table>
        </div>



        ---

        [How to read this page](./coverage-how-to-read.md)
    "##]].assert_eq(&md);
}

#[test]
fn detail_pages_list_tests() {
    let j = prove_thing_judgment();
    let cov = prove_thing_coverage();
    let pages = report::render_detail_pages_for(&j, &cov, Some(GITHUB_BASE), None, "md");

    // One positive page for the covered `positive` rule, one negative page for
    // its negatively-tested premise. `zero` is uncovered, so it gets no page.
    let slugs: Vec<&str> = pages.iter().map(|p| p.slug.as_str()).collect();
    assert_eq!(
        slugs,
        vec![
            "prove_thing__positive__pos",
            "prove_thing__positive__p9__neg",
        ]
    );

    let pos = &pages[0];
    assert!(
        pos.content
            .contains("# Positive coverage: `prove_thing` / `positive`"),
        "{}",
        pos.content
    );
    assert!(pos.content.contains("1 test exercised this rule"));
    // Each test is listed flat with its source location linked to GitHub.
    assert!(
        pos.content.contains(
            "**Source location:** [tests/prove_thing.rs:42](https://github.com/example/repo/blob/main/tests/prove_thing.rs#L42)"
        ),
        "{}",
        pos.content
    );

    let neg = &pages[1];
    assert!(neg.content.contains("premise `if true`"), "{}", neg.content);
    assert!(
        neg.content
            .contains("Premise at line 9. Observed failure causes: if_false."),
        "{}",
        neg.content
    );
    assert!(
        neg.content.contains(
            "**Source location:** [tests/prove_thing.rs:99](https://github.com/example/repo/blob/main/tests/prove_thing.rs#L99)"
        ),
        "{}",
        neg.content
    );
}

#[test]
fn detail_pages_without_github_base_use_plain_locations() {
    let j = prove_thing_judgment();
    let cov = prove_thing_coverage();
    let pages = report::render_detail_pages_for(&j, &cov, None, None, "md");
    let pos = &pages[0];
    assert!(
        pos.content
            .contains("**Source location:** tests/prove_thing.rs:42"),
        "{}",
        pos.content
    );
    assert!(!pos.content.contains("https://"), "{}", pos.content);
}

#[test]
fn detail_pages_render_proof_trees() {
    let j = prove_thing_judgment();
    let mut cov = prove_thing_coverage();

    // The positive test (tests/prove_thing.rs:42) proved `prove_thing` via the
    // `positive` rule, which in turn proved a sub-judgment.
    cov.positive_trees.insert(
        TestLoc {
            file: "tests/prove_thing.rs".into(),
            line: 42,
        },
        vec![ProofTreeNode {
            judgment: "prove_thing".into(),
            rule: Some("positive".into()),
            file: "crates/sub/fixture.rs".into(),
            line: 11,
            attributes: vec![("x".into(), "1".into()), ("result".into(), "()".into())],
            children: vec![ProofTreeNode {
                judgment: "prove_sub".into(),
                rule: Some("sub".into()),
                file: "crates/sub/other.rs".into(),
                line: 3,
                attributes: vec![],
                children: vec![],
            }],
        }],
    );

    // The negative test (tests/prove_thing.rs:99) failed two stacks: one blaming
    // the `positive` premise on line 9 (which this page is about) and one blaming
    // the `zero` premise on line 15 (which it is not).
    cov.negative_trees.insert(
        TestLoc {
            file: "tests/prove_thing.rs".into(),
            line: 99,
        },
        vec![FailedTreeNode {
            judgment: "prove_thing".into(),
            args: "(-1)".into(),
            file: "crates/sub/fixture.rs".into(),
            line: 4,
            rules: vec![
                FailedRuleNode {
                    rule: Some("positive".into()),
                    file: "crates/sub/fixture.rs".into(),
                    line: 9,
                    cause: "if_false".into(),
                    child: None,
                },
                FailedRuleNode {
                    rule: Some("zero".into()),
                    file: "crates/sub/fixture.rs".into(),
                    line: 15,
                    cause: "if_false".into(),
                    child: None,
                },
            ],
        }],
    );

    let pages = report::render_detail_pages_for(&j, &cov, Some(GITHUB_BASE), None, "md");
    let pos = &pages[0];
    let neg = &pages[1];

    // The positive page shows the success tree behind a collapsed disclosure,
    // rendered as a nested list. The parent node (with children) is a
    // collapsible `<details>`; the leaf is a plain `<li>`. Each node's location
    // links to GitHub.
    assert!(
        pos.content.contains("<summary>Proof tree</summary>"),
        "{}",
        pos.content
    );
    assert!(
        pos.content.contains(
            "<summary><code>prove_thing (positive)</code> <a class=\"cov-tree-loc\" href=\"https://github.com/example/repo/blob/main/crates/sub/fixture.rs#L11\" target=\"_blank\" rel=\"noopener noreferrer\">fixture.rs:11</a></summary>"
        ),
        "{}",
        pos.content
    );
    assert!(
        pos.content.contains(
            "<li><code>prove_sub (sub)</code> <a class=\"cov-tree-loc\" href=\"https://github.com/example/repo/blob/main/crates/sub/other.rs#L3\" target=\"_blank\" rel=\"noopener noreferrer\">other.rs:3</a></li>"
        ),
        "{}",
        pos.content
    );
    // The `positive` node's arguments render behind a collapsed `args`
    // disclosure that is filled in lazily: the HTML carries only an empty
    // placeholder keyed by `data-arg-id`, the values live in the page's sidecar
    // JSON, and an inline script fetches that JSON on demand.
    assert!(
        pos.content
            .contains("<details class=\"cov-args\" data-arg-id=\"n0\">"),
        "positive tree should show an args placeholder: {}",
        pos.content
    );
    assert!(
        !pos.content.contains("x = 1") && !pos.content.contains("result = ()"),
        "argument values must not be inlined into the page HTML: {}",
        pos.content
    );
    assert!(
        pos.content
            .contains("./coverage-args/prove_thing__positive__pos.args.json"),
        "positive page should inject the lazy-load script: {}",
        pos.content
    );
    assert_eq!(pos.args_json, r#"{"n0":[["x","1"],["result","()"]]}"#);

    // The negative page shows the failed tree pruned to the stack that blames
    // premise line 9; the unrelated `zero` stack (line 15) is dropped.
    assert!(
        neg.content.contains("<summary>Failed proof tree</summary>"),
        "{}",
        neg.content
    );
    assert!(
        neg.content.contains(
            "<li><code>rule \"positive\"</code> <a class=\"cov-tree-loc\" href=\"https://github.com/example/repo/blob/main/crates/sub/fixture.rs#L9\" target=\"_blank\" rel=\"noopener noreferrer\">fixture.rs:9</a> <span class=\"cov-tree-fail\">(failed: if_false)</span></li>"
        ),
        "{}",
        neg.content
    );
    // The unrelated `zero` stack (line 15) is pruned from the tree; look for its
    // rule label specifically (the page's chart renders only the `positive`
    // rule, so `zero` should appear nowhere).
    assert!(
        !neg.content.contains(r#"rule "zero""#),
        "unrelated stack should be pruned: {}",
        neg.content
    );
    // The failing judgment's arguments render behind a lazily-filled `args`
    // placeholder on the negative page too, with the value carried in the
    // sidecar JSON (an empty name so it renders alone).
    assert!(
        neg.content
            .contains("<details class=\"cov-args\" data-arg-id=\"n0\">"),
        "negative tree should show an args placeholder: {}",
        neg.content
    );
    assert!(
        !neg.content.contains("<code>(-1)</code>"),
        "the failing args value must not be inlined into the page HTML: {}",
        neg.content
    );
    assert_eq!(neg.args_json, r#"{"n0":[["","(-1)"]]}"#);
}

#[test]
fn detail_pages_embed_chart_with_current_cell_highlighted() {
    let j = prove_thing_judgment();
    let cov = prove_thing_coverage();
    let pages = report::render_detail_pages_for(&j, &cov, None, None, "md");
    let pos = &pages[0];
    let neg = &pages[1];

    // Both pages open with the `positive` rule's coverage chart.
    assert!(pos
        .content
        .contains("<div class=\"cov-rule\" id=\"positive\">"));
    assert!(neg
        .content
        .contains("<div class=\"cov-rule\" id=\"positive\">"));

    // The positive page highlights the conclusion row (its cell); the negative
    // page highlights the premise row on line 9 (its cell).
    assert!(
        pos.content.contains("<tr class=\"cov-concl cov-current\">"),
        "positive page should highlight the conclusion: {}",
        pos.content
    );
    assert!(
        neg.content
            .contains("<tr class=\"cov-current\"><td class=\"cov-ln\">9</td>"),
        "negative page should highlight the premise on line 9: {}",
        neg.content
    );

    // The other cells stay clickable so the reader can hop between them: the
    // negative page's chart links to the positive cell's page and vice versa.
    assert!(
        neg.content
            .contains("href=\"./prove_thing__positive__pos.md\""),
        "negative page chart should link to the positive cell: {}",
        neg.content
    );
    assert!(
        pos.content
            .contains("href=\"./prove_thing__positive__p9__neg.md\""),
        "positive page chart should link to the negative cell: {}",
        pos.content
    );
}

#[test]
fn proof_tree_node_shows_source_hover_from_root() {
    // A judgment source file on disk so tree nodes can carry a source preview.
    let tmp = std::env::temp_dir().join(format!("formality-coverage-hover-{}", std::process::id()));
    std::fs::create_dir_all(&tmp).unwrap();
    let judgment_file = "prove.rs";
    std::fs::write(
        tmp.join(judgment_file),
        "line one\nline two\nfn target_here() {}\nline four\nline five\n",
    )
    .unwrap();

    let j = prove_thing_judgment();
    let mut cov = prove_thing_coverage();
    cov.positive_trees.insert(
        TestLoc {
            file: "tests/prove_thing.rs".into(),
            line: 42,
        },
        vec![ProofTreeNode {
            judgment: "prove_thing".into(),
            rule: Some("positive".into()),
            file: judgment_file.into(),
            line: 3,
            attributes: vec![],
            children: vec![],
        }],
    );

    // No GitHub base, so the location is a plain span; with a source root it
    // still carries a `title` tooltip of the surrounding source.
    let pages = report::render_detail_pages_for(&j, &cov, None, Some(&tmp), "md");
    let pos = &pages[0];
    assert!(
        pos.content
            .contains("<span class=\"cov-tree-loc\" title=\""),
        "tree node should carry a source-preview tooltip: {}",
        pos.content
    );
    assert!(
        pos.content.contains("fn target_here() {}"),
        "tooltip should include the target line: {}",
        pos.content
    );

    let _ = std::fs::remove_dir_all(&tmp);
}

#[test]
fn huge_proof_tree_is_capped() {
    // A degenerate 500-node chain: where-clause solving really does produce
    // trees this deep, so the renderer must cap them.
    let mut node = ProofTreeNode {
        judgment: "leaf".into(),
        rule: Some("r".into()),
        file: "f.rs".into(),
        line: 1,
        attributes: vec![],
        children: vec![],
    };
    for _ in 0..499 {
        node = ProofTreeNode {
            judgment: "j".into(),
            rule: Some("r".into()),
            file: "f.rs".into(),
            line: 1,
            attributes: vec![],
            children: vec![node],
        };
    }

    let j = prove_thing_judgment();
    let mut cov = prove_thing_coverage();
    cov.positive_trees.insert(
        TestLoc {
            file: "tests/prove_thing.rs".into(),
            line: 42,
        },
        vec![node],
    );

    let pages = report::render_detail_pages_for(&j, &cov, None, None, "md");
    let pos = &pages[0];
    assert!(
        pos.content.contains("of 500 nodes shown"),
        "tree should be capped with a note"
    );
}

#[test]
fn proof_trees_are_capped_per_cell() {
    // 12 tests exercise the `positive` rule; only the first 10 get a tree.
    let j = prove_thing_judgment();
    let mut cov = prove_thing_coverage();
    let rule = CoveredRule {
        judgment: "prove_thing".into(),
        rule: "positive".into(),
    };
    for n in 0..12u32 {
        let loc = TestLoc {
            file: "tests/many.rs".into(),
            line: 100 + n,
        };
        cov.positive.get_mut(&rule).unwrap().insert(loc.clone());
        cov.positive_trees.insert(
            loc,
            vec![ProofTreeNode {
                judgment: "prove_thing".into(),
                rule: Some("positive".into()),
                file: "f.rs".into(),
                line: 1,
                attributes: vec![],
                children: vec![],
            }],
        );
    }

    let pages = report::render_detail_pages_for(&j, &cov, None, None, "md");
    let pos = &pages[0];
    let trees_shown = pos.content.matches("<summary>Proof tree</summary>").count();
    assert_eq!(trees_shown, 10, "should cap inline trees at 10");
    assert!(
        pos.content
            .contains("Proof trees omitted for the remaining 3 tests"),
        "should note the omission (13 total: 1 original + 12 added)"
    );
}

#[test]
fn detail_pages_embed_test_source_when_root_given() {
    // A judgment with one rule, covered by one test that lives in a real file
    // on disk so the detail page can embed its source.
    let tmp = std::env::temp_dir().join(format!("formality-coverage-src-{}", std::process::id()));
    std::fs::create_dir_all(&tmp).unwrap();
    let test_file = "my_module.rs";
    let body = "// preamble\n#[test]\nfn my_test() {\n    let x = 1;\n    assert_eq!(x, 1);\n}\n";
    std::fs::write(tmp.join(test_file), body).unwrap();

    let j = Judgment {
        name: "j".into(),
        doc_comment: String::new(),
        signature: String::new(),
        source_extract: String::new(),
        file: "fixture.rs".into(),
        line: 1,
        rules: vec![rule_with_premise("r", 3, 2)],
    };
    let mut cov = Coverage::default();
    cov.positive.insert(
        CoveredRule {
            judgment: "j".into(),
            rule: "r".into(),
        },
        // The `assert_eq!` line (5) is inside `my_test`.
        BTreeSet::from([TestLoc {
            file: test_file.into(),
            line: 5,
        }]),
    );

    let pages = report::render_detail_pages_for(&j, &cov, None, Some(&tmp), "md");
    let pos = &pages[0];
    // The whole enclosing test function (including the `#[test]` attribute) is
    // embedded in a fenced code block.
    assert!(pos.content.contains("```rust,ignore"), "{}", pos.content);
    assert!(pos.content.contains("#[test]"), "{}", pos.content);
    assert!(pos.content.contains("fn my_test() {"), "{}", pos.content);
    assert!(pos.content.contains("assert_eq!(x, 1);"), "{}", pos.content);

    let _ = std::fs::remove_dir_all(&tmp);
}

#[test]
fn infallible_premise_renders_as_na() {
    let j = Judgment {
        name: "easy".into(),
        doc_comment: String::new(),
        signature: String::new(),
        source_extract: String::new(),
        file: "fixture.rs".into(),
        line: 1,
        rules: vec![Rule {
            name: "trivial".into(),
            raw_text: "(let x = y)\n----- (\"trivial\")\n(easy(y) => x)".into(),
            line: 7,
            premises: vec![premise("let x = y", PremiseKind::Let, false, 6)],
        }],
    };
    let cov = Coverage::default();

    let index = report::render_index(&[j.clone()], &cov);
    expect![[r#"
        # Coverage report

        | Judgment/Rule | Positive coverage | Negative coverage |
        | --- | --- | --- |
        | **[easy](./easy.md)** | - | - |
        | ↳ [trivial](./easy.md#trivial) | ✗ | N/A |


        ---

        [How to read this page](./coverage-how-to-read.md)
    "#]]
    .assert_eq(&index);

    let subpage = report::render_subpage(&j, &cov, "md", None);
    expect![[r##"
        # Judgment `easy`

        Source: `fixture.rs:1`

        The number on each rule's conclusion is **positive** coverage; the number on each premise is **negative** coverage. Click a number to browse the tests.

        <style>
        .cov-rule{border:1px solid var(--quote-border,#d0d0d0);border-radius:6px;margin:1rem 0;overflow:hidden}
        .cov-rule-head{padding:.4rem .8rem;background:var(--quote-bg,#f6f7f9);font-weight:600}
        table.cov-code{width:100%;border-collapse:collapse;font-family:var(--mono-font,monospace);font-size:.85em;margin:0}
        table.cov-code td{padding:.15rem .6rem;border:0}
        table.cov-code th{padding:.15rem .6rem;border:0;border-bottom:1px solid var(--quote-border,#d0d0d0);color:#888;font-weight:600;font-size:.9em}
        .cov-ln{text-align:right;color:#999;user-select:none;width:3em;white-space:nowrap}
        .cov-num{text-align:right;width:3.5em;white-space:nowrap;font-weight:600}
        .cov-num.pos a{color:#1a7f37}
        .cov-num.neg a{color:#b35900}
        .cov-none{color:#bbb}
        .cov-na{color:#bbb;font-weight:400}
        .cov-src-line{white-space:pre-wrap}
        tr.cov-sep td{color:#999}
        tr.cov-concl{background:rgba(127,127,127,.08)}
        table.cov-code tr.cov-current td{background:rgba(31,120,255,.28)}
        ul.cov-tree,ul.cov-tree ul{list-style:none;margin:0;padding-left:1.2em;font-family:var(--mono-font,monospace)}
        ul.cov-tree{font-size:.85em}
        ul.cov-tree ul{font-size:1em}
        ul.cov-tree code{font-size:inherit}
        ul.cov-tree summary{cursor:pointer}
        .cov-tree-loc{color:#888}
        .cov-tree-fail{color:#b35900}
        .cov-tree-scroll{overflow-x:auto}
        ul.cov-tree li,ul.cov-tree summary{white-space:nowrap}
        </style>

        <div class="cov-rule" id="trivial">
        <div class="cov-rule-head"><code>trivial</code></div>
        <table class="cov-code">
        <thead><tr><th class="cov-ln">Line</th><th class="cov-num">Coverage</th><th class="cov-src-line">Source</th></tr></thead>
        <tr><td class="cov-ln">6</td><td class="cov-num neg"><span class="cov-na">N/A</span></td><td class="cov-src-line">(let x = y)</td></tr>
        <tr class="cov-sep"><td class="cov-ln"></td><td class="cov-num"></td><td class="cov-src-line">──────── ("trivial")</td></tr>
        <tr class="cov-concl"><td class="cov-ln">8</td><td class="cov-num pos"><span class="cov-none">✗</span></td><td class="cov-src-line">(easy(y) =&gt; x)</td></tr>
        </table>
        </div>



        ---

        [How to read this page](./coverage-how-to-read.md)
    "##]].assert_eq(&subpage);
}

#[test]
fn no_applicable_rule_renders_in_index_and_subpage() {
    let j = prove_thing_judgment();
    let mut cov = Coverage::default();
    cov.no_applicable_rule.insert(NoApplicableRuleLoc {
        judgment: "prove_thing".into(),
        file: "crates/sub/fixture.rs".into(),
        line: 4,
    });

    let index = report::render_index(&[j.clone()], &cov);
    expect![[r#"
        # Coverage report

        | Judgment/Rule | Positive coverage | Negative coverage |
        | --- | --- | --- |
        | **[prove_thing](./prove_thing.md)** | - | no applicable rule observed |
        | ↳ [positive](./prove_thing.md#positive) | ✗ | 0/1 |
        | ↳ [zero](./prove_thing.md#zero) | ✗ | 0/1 |


        ---

        [How to read this page](./coverage-how-to-read.md)
    "#]]
    .assert_eq(&index);

    let subpage = report::render_subpage(&j, &cov, "md", None);
    assert!(subpage.contains("_No applicable rule observed:"));
}

#[test]
fn empty_rules_renders_no_rules_message() {
    let j = Judgment {
        name: "lonely".into(),
        doc_comment: String::new(),
        signature: String::new(),
        source_extract: String::new(),
        file: "fixture.rs".into(),
        line: 1,
        rules: vec![],
    };
    let cov = Coverage::default();
    let md = report::render_subpage(&j, &cov, "md", None);
    expect![[r#"
        # Judgment `lonely`

        Source: `fixture.rs:1`

        _No rules discovered._


        ---

        [How to read this page](./coverage-how-to-read.md)
    "#]]
    .assert_eq(&md);
}

#[test]
fn jsonl_reads_positive_and_negative_records() {
    let tmp = std::env::temp_dir().join(format!("formality-coverage-read-{}", std::process::id()));
    std::fs::create_dir_all(&tmp).unwrap();
    let path = tmp.join("test-coverage.jsonl");

    let body = concat!(
        r#"{"kind":"positive","test_file":"a.rs","test_line":1,"test_column":1,"rules":[{"judgment":"j1","rule":"r1","file":"f.rs","line":10}]}"#,
        "\n",
        r#"{"kind":"negative","test_file":"b.rs","test_line":2,"test_column":1,"reasons":[{"reason":"premise","judgment":"j1","rule":"r1","file":"f.rs","line":11,"cause":"if_false"},{"reason":"premise","judgment":"j1","rule":"r1","file":"f.rs","line":11,"cause":"if_let"}]}"#,
        "\n",
        r#"{"kind":"negative","test_file":"c.rs","test_line":3,"test_column":1,"reasons":[{"reason":"no_applicable_rule","judgment":"j2","file":"g.rs","line":5}]}"#,
        "\n",
    );
    std::fs::write(&path, body).unwrap();

    let cov = jsonl::read(&path).unwrap();
    assert_eq!(cov.positive.len(), 1);

    // The test location of the positive record is retained so the report can
    // link the ✓ back to the test on GitHub.
    let tests = cov
        .positive_tests("j1", "r1")
        .expect("rule r1 should be covered");
    assert!(tests.contains(&TestLoc {
        file: "a.rs".into(),
        line: 1,
    }));

    let causes = cov.premise_causes_for("f.rs", 11);
    let causes: Vec<&str> = causes.iter().map(String::as_str).collect();
    assert_eq!(causes, vec!["if_false", "if_let"]);

    // The negative record's test location is retained so the report can link
    // the failing premise back to the test that exercised it.
    let neg_tests = cov.negative_premise_tests("f.rs", 11);
    assert!(neg_tests.contains(&TestLoc {
        file: "b.rs".into(),
        line: 2,
    }));
    // Different file should not match.
    assert!(cov.premise_causes_for("other.rs", 11).is_empty());
    // Different line should not match.
    assert!(cov.premise_causes_for("f.rs", 12).is_empty());

    assert!(cov.no_applicable_rule_observed("g.rs", "j2"));
    assert!(!cov.no_applicable_rule_observed("g.rs", "jX"));

    let _ = std::fs::remove_dir_all(&tmp);
}

#[test]
fn jsonl_reads_embedded_proof_trees() {
    let tmp = std::env::temp_dir().join(format!("formality-coverage-trees-{}", std::process::id()));
    std::fs::create_dir_all(&tmp).unwrap();
    let path = tmp.join("test-coverage.jsonl");

    let body = concat!(
        r#"{"kind":"positive","test_file":"a.rs","test_line":1,"test_column":1,"rules":[{"judgment":"j1","rule":"r1","file":"f.rs","line":10}],"trees":[{"judgment":"j1","rule":"r1","file":"f.rs","line":10,"children":[{"judgment":"j2","rule":"r2","file":"g.rs","line":20}]}]}"#,
        "\n",
        r#"{"kind":"negative","test_file":"b.rs","test_line":2,"test_column":1,"reasons":[{"reason":"premise","judgment":"j1","rule":"r1","file":"f.rs","line":11,"cause":"if_false"}],"trees":[{"judgment":"j1","file":"f.rs","line":1,"rules":[{"rule":"r1","file":"f.rs","line":11,"cause":"if_false"}]}]}"#,
        "\n",
    );
    std::fs::write(&path, body).unwrap();

    let cov = jsonl::read(&path).unwrap();

    let pos = cov.positive_trees_for(&TestLoc {
        file: "a.rs".into(),
        line: 1,
    });
    assert_eq!(pos.len(), 1);
    assert_eq!(pos[0].judgment, "j1");
    assert_eq!(pos[0].rule.as_deref(), Some("r1"));
    assert_eq!(pos[0].children[0].judgment, "j2");

    let neg = cov.negative_trees_for(&TestLoc {
        file: "b.rs".into(),
        line: 2,
    });
    assert_eq!(neg.len(), 1);
    assert_eq!(neg[0].rules[0].rule.as_deref(), Some("r1"));
    assert_eq!(neg[0].rules[0].cause, "if_false");

    let _ = std::fs::remove_dir_all(&tmp);
}

#[test]
fn jsonl_reader_tolerates_malformed_lines() {
    let tmp = std::env::temp_dir().join(format!(
        "formality-coverage-malformed-{}",
        std::process::id()
    ));
    std::fs::create_dir_all(&tmp).unwrap();
    let path = tmp.join("test-coverage.jsonl");

    // First line is well-formed; second line has two JSON objects glued together
    // (the failure mode we saw in practice when parallel appends interleaved);
    // third line is well-formed again.
    let body = concat!(
        r#"{"kind":"positive","test_file":"a.rs","test_line":1,"test_column":1,"rules":[{"judgment":"j1","rule":"r1","file":"f","line":1}]}"#,
        "\n",
        r#"{"kind":"positive","test_file":"b.rs","test_line":2,"test_column":1,"rules":[{"judgment":"j2","rule":"r2","file":"f","line":1}]}{"#,
        "\n",
        r#"{"kind":"positive","test_file":"c.rs","test_line":3,"test_column":1,"rules":[{"judgment":"j3","rule":"r3","file":"f","line":1}]}"#,
        "\n",
    );
    std::fs::write(&path, body).unwrap();

    let got = jsonl::read_positive(&path).expect("malformed line should not fail the reader");
    let names: Vec<(&str, &str)> = got
        .iter()
        .map(|r| (r.judgment.as_str(), r.rule.as_str()))
        .collect();
    assert_eq!(names, vec![("j1", "r1"), ("j3", "r3")]);

    let _ = std::fs::remove_dir_all(&tmp);
}

// --- The by-test view (the same coverage organized the other way round) ---

#[test]
fn by_test_inverts_the_per_cell_maps() {
    let by_test = prove_thing_coverage().by_test();
    let locs: Vec<(&str, u32)> = by_test.keys().map(|l| (l.file.as_str(), l.line)).collect();
    assert_eq!(
        locs,
        vec![("tests/prove_thing.rs", 42), ("tests/prove_thing.rs", 99)]
    );

    // The positive test proved one rule and failed no premise; the negative
    // test is the mirror image.
    let positive = &by_test[&TestLoc {
        file: "tests/prove_thing.rs".into(),
        line: 42,
    }];
    assert_eq!(positive.rules.len(), 1);
    assert!(positive.premises.is_empty());

    let negative = &by_test[&TestLoc {
        file: "tests/prove_thing.rs".into(),
        line: 99,
    }];
    assert!(negative.rules.is_empty());
    assert_eq!(negative.premises.len(), 1);
}

#[test]
fn by_test_index_groups_tests_by_file() {
    // A second file, so the per-file heading is actually emitted more than once.
    let mut cov = prove_thing_coverage();
    cov.positive
        .get_mut(&CoveredRule {
            judgment: "prove_thing".into(),
            rule: "positive".into(),
        })
        .unwrap()
        .insert(TestLoc {
            file: "tests/other.rs".into(),
            line: 7,
        });

    let md = report::render_by_test_index(&cov, None);
    expect![[r#"
        # Coverage by test

        The same data as the [coverage report](./coverage.md), organized by test rather than by judgment: each test lists the rules it proves and the premises it is observed to fail on.

        ## `tests/other.rs`

        | Test | Rules proved | Premises failed |
        | --- | --- | --- |
        | [line 7](./test__tests_other_rs__7.md) | 1 | 0 |

        ## `tests/prove_thing.rs`

        | Test | Rules proved | Premises failed |
        | --- | --- | --- |
        | [line 42](./test__tests_prove_thing_rs__42.md) | 1 | 0 |
        | [line 99](./test__tests_prove_thing_rs__99.md) | 0 | 1 |


        ---

        [How to read this page](./coverage-how-to-read.md)
    "#]]
    .assert_eq(&md);
}

#[test]
fn by_test_index_says_so_when_nothing_was_recorded() {
    // The branch a book built without running the tests takes.
    let md = report::render_by_test_index(&Coverage::default(), None);
    expect![[r#"
        # Coverage by test

        The same data as the [coverage report](./coverage.md), organized by test rather than by judgment: each test lists the rules it proves and the premises it is observed to fail on.

        _No coverage recorded._


        ---

        [How to read this page](./coverage-how-to-read.md)
    "#]]
    .assert_eq(&md);
}

#[test]
fn test_pages_link_to_the_cells_they_cover() {
    let judgments = vec![prove_thing_judgment()];
    let cov = prove_thing_coverage();
    let pages = report::render_test_pages(&judgments, &cov, Some(GITHUB_BASE), None);

    let slugs: Vec<&str> = pages.iter().map(|p| p.slug.as_str()).collect();
    assert_eq!(
        slugs,
        vec![
            "test__tests_prove_thing_rs__42",
            "test__tests_prove_thing_rs__99",
        ]
    );

    // The positive test's page names the rule it proved and links to that
    // rule's cell page, which is where the other tests of the rule are listed.
    expect![[r#"
        # Test `tests/prove_thing.rs:42`

        <style>
        .cov-rule{border:1px solid var(--quote-border,#d0d0d0);border-radius:6px;margin:1rem 0;overflow:hidden}
        .cov-rule-head{padding:.4rem .8rem;background:var(--quote-bg,#f6f7f9);font-weight:600}
        table.cov-code{width:100%;border-collapse:collapse;font-family:var(--mono-font,monospace);font-size:.85em;margin:0}
        table.cov-code td{padding:.15rem .6rem;border:0}
        table.cov-code th{padding:.15rem .6rem;border:0;border-bottom:1px solid var(--quote-border,#d0d0d0);color:#888;font-weight:600;font-size:.9em}
        .cov-ln{text-align:right;color:#999;user-select:none;width:3em;white-space:nowrap}
        .cov-num{text-align:right;width:3.5em;white-space:nowrap;font-weight:600}
        .cov-num.pos a{color:#1a7f37}
        .cov-num.neg a{color:#b35900}
        .cov-none{color:#bbb}
        .cov-na{color:#bbb;font-weight:400}
        .cov-src-line{white-space:pre-wrap}
        tr.cov-sep td{color:#999}
        tr.cov-concl{background:rgba(127,127,127,.08)}
        table.cov-code tr.cov-current td{background:rgba(31,120,255,.28)}
        ul.cov-tree,ul.cov-tree ul{list-style:none;margin:0;padding-left:1.2em;font-family:var(--mono-font,monospace)}
        ul.cov-tree{font-size:.85em}
        ul.cov-tree ul{font-size:1em}
        ul.cov-tree code{font-size:inherit}
        ul.cov-tree summary{cursor:pointer}
        .cov-tree-loc{color:#888}
        .cov-tree-fail{color:#b35900}
        .cov-tree-scroll{overflow-x:auto}
        ul.cov-tree li,ul.cov-tree summary{white-space:nowrap}
        </style>

        <style>
        main table{width:100%;display:table}
        main table code{overflow-wrap:anywhere;white-space:normal}
        </style>

        **Source location:** [tests/prove_thing.rs:42](https://github.com/example/repo/blob/main/tests/prove_thing.rs#L42)

        ## Rules proved (1)

        | Judgment | Rule | All tests of this rule |
        | --- | --- | --- |
        | [prove_thing](./prove_thing.md) | [positive](./prove_thing.md#positive) | [1 test](./prove_thing__positive__pos.md) |

        ## Premises failed (0)

        _This test records no negative coverage._



        ---

        [How to read this page](./coverage-how-to-read.md)
    "#]]
    .assert_eq(&pages[0].content);

    // The negative test's page names the premise it blamed and links to that
    // premise's cell page.
    expect![[r#"
        # Test `tests/prove_thing.rs:99`

        <style>
        .cov-rule{border:1px solid var(--quote-border,#d0d0d0);border-radius:6px;margin:1rem 0;overflow:hidden}
        .cov-rule-head{padding:.4rem .8rem;background:var(--quote-bg,#f6f7f9);font-weight:600}
        table.cov-code{width:100%;border-collapse:collapse;font-family:var(--mono-font,monospace);font-size:.85em;margin:0}
        table.cov-code td{padding:.15rem .6rem;border:0}
        table.cov-code th{padding:.15rem .6rem;border:0;border-bottom:1px solid var(--quote-border,#d0d0d0);color:#888;font-weight:600;font-size:.9em}
        .cov-ln{text-align:right;color:#999;user-select:none;width:3em;white-space:nowrap}
        .cov-num{text-align:right;width:3.5em;white-space:nowrap;font-weight:600}
        .cov-num.pos a{color:#1a7f37}
        .cov-num.neg a{color:#b35900}
        .cov-none{color:#bbb}
        .cov-na{color:#bbb;font-weight:400}
        .cov-src-line{white-space:pre-wrap}
        tr.cov-sep td{color:#999}
        tr.cov-concl{background:rgba(127,127,127,.08)}
        table.cov-code tr.cov-current td{background:rgba(31,120,255,.28)}
        ul.cov-tree,ul.cov-tree ul{list-style:none;margin:0;padding-left:1.2em;font-family:var(--mono-font,monospace)}
        ul.cov-tree{font-size:.85em}
        ul.cov-tree ul{font-size:1em}
        ul.cov-tree code{font-size:inherit}
        ul.cov-tree summary{cursor:pointer}
        .cov-tree-loc{color:#888}
        .cov-tree-fail{color:#b35900}
        .cov-tree-scroll{overflow-x:auto}
        ul.cov-tree li,ul.cov-tree summary{white-space:nowrap}
        </style>

        <style>
        main table{width:100%;display:table}
        main table code{overflow-wrap:anywhere;white-space:normal}
        </style>

        **Source location:** [tests/prove_thing.rs:99](https://github.com/example/repo/blob/main/tests/prove_thing.rs#L99)

        ## Rules proved (0)

        _This test records no positive coverage._

        ## Premises failed (1)

        The last column links to the premise's page when the judgment view counts this failure against that premise. It does not when the premise is read as infallible, or when the failure was blamed inside a multi-line premise that carries no record on its own first line.

        | Judgment | Rule | Premise | All tests of this premise |
        | --- | --- | --- | --- |
        | [prove_thing](./prove_thing.md) | [positive](./prove_thing.md#positive) | `if true` (line 9) | [1 test](./prove_thing__positive__p9__neg.md) |



        ---

        [How to read this page](./coverage-how-to-read.md)
    "#]]
    .assert_eq(&pages[1].content);
}

#[test]
fn detail_pages_link_back_to_the_test_page() {
    let j = prove_thing_judgment();
    let cov = prove_thing_coverage();
    let pages = report::render_detail_pages_for(&j, &cov, Some(GITHUB_BASE), None, "md");
    for page in &pages {
        assert!(
            page.content
                .contains("([all coverage from this test](./test__tests_prove_thing_rs__"),
            "{}",
            page.content
        );
    }
}

#[test]
fn test_pages_render_the_tests_own_proof_trees() {
    let judgments = vec![prove_thing_judgment()];
    let mut cov = prove_thing_coverage();
    cov.positive_trees.insert(
        TestLoc {
            file: "tests/prove_thing.rs".into(),
            line: 42,
        },
        vec![ProofTreeNode {
            judgment: "prove_thing".into(),
            rule: Some("positive".into()),
            file: "crates/sub/fixture.rs".into(),
            line: 11,
            attributes: vec![("x".into(), "1".into())],
            children: vec![],
        }],
    );
    // Both stacks of the negative test's failed tree, including the one blaming
    // `zero` that a premise's detail page prunes away.
    cov.negative_trees.insert(
        TestLoc {
            file: "tests/prove_thing.rs".into(),
            line: 99,
        },
        vec![FailedTreeNode {
            judgment: "prove_thing".into(),
            args: "(-1)".into(),
            file: "crates/sub/fixture.rs".into(),
            line: 4,
            rules: vec![
                FailedRuleNode {
                    rule: Some("positive".into()),
                    file: "crates/sub/fixture.rs".into(),
                    line: 9,
                    cause: "if_false".into(),
                    child: None,
                },
                FailedRuleNode {
                    rule: Some("zero".into()),
                    file: "crates/sub/fixture.rs".into(),
                    line: 15,
                    cause: "if_false".into(),
                    child: None,
                },
            ],
        }],
    );

    let pages = report::render_test_pages(&judgments, &cov, Some(GITHUB_BASE), None);

    assert!(
        pages[0].content.contains("<summary>Proof tree</summary>"),
        "{}",
        pages[0].content
    );
    // The tree markup is styled by rules that live only in the shared
    // stylesheet, so a test page carrying a tree has to carry that too or the
    // tree renders as a plain bulleted list.
    assert!(
        pages[0].content.contains("ul.cov-tree,ul.cov-tree ul{"),
        "{}",
        pages[0].content
    );
    // Arguments are lazily loaded here as on the cell pages: the placeholder is
    // in the HTML, the values in the page's own sidecar JSON.
    assert!(
        pages[0]
            .content
            .contains("./coverage-args/test__tests_prove_thing_rs__42.args.json"),
        "{}",
        pages[0].content
    );
    assert_eq!(pages[0].args_json, r#"{"n0":[["x","1"]]}"#);

    // A test page shows the test's whole failed tree, unpruned: both the stack
    // blaming `positive` and the one blaming `zero` are present, which is the
    // point of this view.
    assert!(
        pages[1]
            .content
            .contains("<summary>Failed proof tree</summary>"),
        "{}",
        pages[1].content
    );
    assert!(
        pages[1].content.contains(r#"rule "positive""#)
            && pages[1].content.contains(r#"rule "zero""#),
        "{}",
        pages[1].content
    );
}

#[test]
fn test_pages_do_not_link_rules_the_scraper_never_found() {
    // Coverage can name a rule the report has no page for: `overlap_check` in
    // the real tree builds its `ProofTree` by hand rather than through
    // `judgment_fn!`, so the scraper never sees it. Such a row must render
    // without a link, or the by-test page points at a page that was never
    // written.
    let judgments = vec![prove_thing_judgment()];
    let mut cov = prove_thing_coverage();
    cov.positive.insert(
        CoveredRule {
            judgment: "hand_rolled".into(),
            rule: "made_up".into(),
        },
        BTreeSet::from([TestLoc {
            file: "tests/prove_thing.rs".into(),
            line: 42,
        }]),
    );

    let pages = report::render_test_pages(&judgments, &cov, Some(GITHUB_BASE), None);
    let content = &pages[0].content;
    assert!(
        content.contains("| `hand_rolled` | `made_up` | 1 test (not in the report) |"),
        "{content}"
    );
    assert!(
        !content.contains("hand_rolled__made_up__pos.md"),
        "must not link to a page that is never written: {content}"
    );
}

#[test]
fn test_pages_do_not_link_premises_the_report_reads_as_infallible() {
    // Real coverage data blames premises the scraper classifies as infallible
    // (a `let` with no `?`). The judgment view renders those `N/A` and writes no
    // detail page, so the by-test row must not link to one.
    let mut j = prove_thing_judgment();
    j.rules[0].premises = vec![premise(
        "let y = f(x)",
        PremiseKind::Let,
        false, // infallible: no detail page is ever written for it
        9,
    )];
    let judgments = vec![j];
    let cov = prove_thing_coverage();

    let pages = report::render_test_pages(&judgments, &cov, Some(GITHUB_BASE), None);
    let content = &pages[1].content;
    assert!(
        content.contains("| not counted by the judgment view |"),
        "{content}"
    );
    assert!(
        !content.contains("__p9__neg.md"),
        "must not link to a page that is never written: {content}"
    );
}

#[test]
fn test_pages_attribute_a_failure_blamed_inside_a_multi_line_premise() {
    // The macro respans a failure onto the exact sub-premise that failed, so a
    // record can name a line inside a `for_all` block that the scraper reads as
    // one premise starting earlier. The row still belongs under that premise.
    let mut j = prove_thing_judgment();
    j.rules[0].premises = vec![premise(
        "for_all(i in 0..n)\n    (prove_thing(i) => ())",
        PremiseKind::Other,
        true,
        8, // spans lines 8-9; the record below blames line 9
    )];
    let judgments = vec![j];
    let cov = prove_thing_coverage();

    let pages = report::render_test_pages(&judgments, &cov, Some(GITHUB_BASE), None);
    let content = &pages[1].content;
    // The row sits under the premise that spans the blamed line, and names both
    // lines so the reader can check the span match against the source.
    assert!(
        content.contains("[prove_thing](./prove_thing.md)")
            && content
                .contains("for_all(i in 0..n) (prove_thing(i) => ())` (line 8, blamed at line 9)"),
        "{content}"
    );
    // The judgment view keys pages by the premise's own first line, and no test
    // failed there, so there is no page for this row to link to.
    assert!(
        content.contains("| not counted by the judgment view |"),
        "{content}"
    );
}
