use crate::grammar::Predicate;
use crate::rust::term;
use expect_test::expect;
use formality_macros::test;
use std::sync::Arc;

use crate::prove::{decls::Program, prove};

/// Simple example decls consisting only of two trait declarations.
fn decls() -> Program {
    Program {
        crates: Arc::new(Program::program_from_items(vec![
            term("trait Debug where {}"),
            term("impl<T> Debug for Vec<T> where T : Debug {}"),
            term("impl Debug for u32 {}"),
        ])),
        ..Program::empty()
    }
}

#[test]
fn vec_u32_debug() {
    let goal: Predicate = term("Debug(Vec<u32>)");
    prove(decls(), (), (), goal).assert_ok(expect!["{Constraints { env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: false }, known_true: true, substitution: {} }}"]);
}

#[test]
fn vec_vec_u32_debug() {
    let goal: Predicate = term("Debug(Vec<Vec<u32>>)");
    prove(decls(), (), (), goal).assert_ok(expect!["{Constraints { env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: false }, known_true: true, substitution: {} }}"]);
}
