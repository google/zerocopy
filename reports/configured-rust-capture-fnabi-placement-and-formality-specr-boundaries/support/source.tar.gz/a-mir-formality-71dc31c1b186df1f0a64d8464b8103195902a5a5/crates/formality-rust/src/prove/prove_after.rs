use crate::grammar::Predicates;
use formality_core::judgment_fn;

use crate::prove::{decls::Program, prove};

use super::constraints::Constraints;

judgment_fn! {
    pub fn prove_after(
        _decls: Program,
        constraints: Constraints,
        assumptions: Predicates,
        goal: Predicates,
    ) => Constraints {
        debug(constraints, goal, assumptions)

        (
            (let (assumptions, goal) = c1.substitution().apply((assumptions, goal)))
            (prove(decls, c1.env(), assumptions, goal) => c2)
            --- ("prove_after")
            (prove_after(decls, c1, assumptions, goal) => c1.seq(c2))
        )
    }
}
