#![allow(dead_code)]

use std::fmt::Debug;

use crate::prove::{is_definitely_not_proveable, Constraints, Env, Program};
use crate::rust::Visit;
use crate::{
    grammar::{
        Crate, CrateId, CrateItem, Crates, Fallible, FeatureGateName, Predicates, Test,
        TestBoundData,
    },
    prove::ToPredicates,
};
use anyhow::{anyhow, bail};
use formality_core::{judgment::ProofTree, judgment_fn, ProvenSet, Set};

use adts::check_adt;
use coherence::check_coherence;
use fns::check_free_fn;
use impls::{check_drop_impl_always_applicable, check_neg_trait_impl, check_trait_impl};
use traits::check_trait;

pub mod borrow_check;

mod adts;
mod coherence;
mod core_crate;
mod fns;
mod impls;
mod traits;
mod where_clauses;

/// Prepend the core crate if the first crate isn't already named `core`.
pub fn with_core_crate(crates: &Crates) -> Crates {
    let Crates { mut crates } = crates.clone();
    if Some("core") != crates.first().map(|first| &**first.id) {
        crates.insert(0, core_crate::krate());
    }
    Crates { crates }
}

judgment_fn! {
    pub fn check_all_crates(
        crates: Crates,
    ) => () {
        debug(crates)

        (
            (let crates = with_core_crate(&crates))
            // Check that all crates up to and including crate #i are valid.
            // Crate #i will be considered the "current crate".
            (for_all(i in 0..crates.len())
                (let program = crates.prefix(i).to_prove_decls())
                (check_crate(program, &crates.crates[i]) => ()))
            ------------------------------------------------------------ ("check all prefixes")
            (check_all_crates(crates) => ())
        )
    }
}

judgment_fn! {
    /// Check that the current crate `c` is valid,
    /// given the complete program (which includes dependencies).
    fn check_crate(
        program: Program,
        c: Crate,
    ) => () {
        debug(program, c)

        (
            (check_for_duplicate_items(program) => ())
            (check_for_non_lifetime_binders(c) => ())
            (for_all(item in &c.items)
                (check_crate_item(program, item, &c.id) => ()))
            (check_coherence(program, c) => ())
            ------------------------------------------------------------ ("check crate")
            (check_crate(program, Crate { id: _id, items: _items }) => ())
        )
    }
}

fn check_for_duplicate_items(program: &Program) -> Fallible<ProofTree> {
    let Crates { crates } = program.program();
    for c in crates.iter() {
        let mut items = Set::new();
        let mut traits = Set::new();
        let mut functions = Set::new();
        let mut impl_decls = Set::new();
        let mut neg_impl_decls = Set::new();
        let mut feature_gates = Set::new();
        for item in c.items.iter() {
            match item {
                CrateItem::AdtItem(s) => {
                    if !items.insert(s.name()) {
                        bail!("the item name `{:?}` is defined multiple times", s.name());
                    }
                }
                CrateItem::Trait(t) => {
                    if !traits.insert(&t.id) {
                        bail!("the trait name `{:?}` is defined multiple times", t.id);
                    }
                }
                CrateItem::Fn(f) => {
                    if !functions.insert(&f.id) {
                        bail!("the function name `{:?}` is defined multiple times", f.id);
                    }
                }
                CrateItem::TraitImpl(impl_decl) => {
                    if !impl_decls.insert(impl_decl) {
                        bail!("`{:?}` is defined multiple times", impl_decl);
                    }
                }
                CrateItem::NegTraitImpl(neg_impl_decl) => {
                    if !neg_impl_decls.insert(neg_impl_decl) {
                        bail!("`{:?}` is defined multiple times", neg_impl_decl);
                    }
                }
                CrateItem::FeatureGate(fg) => {
                    if !feature_gates.insert(fg) {
                        bail!("the feature `{:?}` is declared multiple times", fg)
                    }
                }
                CrateItem::Test(_) => {}
            }
        }
    }

    Ok(ProofTree::leaf(
        "check_for_duplicate_items: no duplicates found",
    ))
}

fn check_for_non_lifetime_binders(c: &Crate) -> Fallible<ProofTree> {
    let is_non_lifetime_binder_enabled = c.items.iter().any(|item|
        matches!(item, CrateItem::FeatureGate(fg) if fg.name == FeatureGateName::NonLifetimeBinders)
    );

    if is_non_lifetime_binder_enabled {
        return Ok(ProofTree::leaf(
            "check_for_non_lifetime_binders: feature enabled",
        ));
    }

    if c.items.iter().any(item_has_non_lifetime_binder) {
        bail!("non lifetime binders require #![feature(non_lifetime_binders)]");
    }

    Ok(ProofTree::leaf("check_for_non_lifetime_binders: ok"))
}

fn item_has_non_lifetime_binder(item: &CrateItem) -> bool {
    let where_clauses = match item {
        CrateItem::Trait(t) => &t.binder.explicit_binder.peek().where_clauses,
        CrateItem::AdtItem(adt) => &adt.where_clauses(),
        CrateItem::TraitImpl(t) => &t.binder.peek().where_clauses,
        CrateItem::NegTraitImpl(nt) => &nt.binder.peek().where_clauses,
        CrateItem::Fn(f) => &f.binder.peek().where_clauses,
        CrateItem::FeatureGate(_) | CrateItem::Test(_) => return false,
    };

    where_clauses.iter().any(|wc| wc.has_non_lifetime_binder())
}

/// Checks if *any* crate in the program has the given feature gate enabled.
// FIXME: ideally, these "global" feature gates should either be on the Program itself,
// or we should thread through the *active* crate for things like borrowck and allow
// different crates within a program to have different semantics.
pub(crate) fn feature_gate_enabled_in_program(
    program: &Program,
    feature_gate_name: &FeatureGateName,
) -> bool {
    program.crates.crates.iter().any(|c| {
        c.items
            .iter()
            .any(|item| matches!(item, CrateItem::FeatureGate(fg) if fg.name == *feature_gate_name))
    })
}

judgment_fn! {
    fn check_crate_item(
        program: Program,
        c: CrateItem,
        crate_id: CrateId,
    ) => () {
        debug(program, c, crate_id)

        (
            (check_trait(program, Env::default(), v, crate_id) => ())
            ------------------------------------------------------------ ("trait")
            (check_crate_item(program, CrateItem::Trait(v), crate_id) => ())
        )

        (
            (check_trait_impl(program, v, crate_id) => ())
            (check_drop_impl_always_applicable(program, v, crate_id) => ())
            ------------------------------------------------------------ ("trait impl")
            (check_crate_item(program, CrateItem::TraitImpl(v), crate_id) => ())
        )

        (
            (check_adt(program, &s.to_adt()) => ())
            ------------------------------------------------------------ ("adt")
            (check_crate_item(program, CrateItem::AdtItem(s), crate_id) => ())
        )

        (
            (check_free_fn(program, f, crate_id) => ())
            ------------------------------------------------------------ ("free fn")
            (check_crate_item(program, CrateItem::Fn(f), crate_id) => ())
        )

        (
            (check_neg_trait_impl(program, i) => ())
            ------------------------------------------------------------ ("neg trait impl")
            (check_crate_item(program, CrateItem::NegTraitImpl(i), crate_id) => ())
        )

        (
            (check_test(program, t) => ())
            ------------------------------------------------------------ ("test")
            (check_crate_item(program, CrateItem::Test(t), crate_id) => ())
        )

        (
            ------------------------------------------------------------ ("feature gate")
            (check_crate_item(program, CrateItem::FeatureGate(_feature_gate), crate_id) => ())
        )
    }
}

fn check_test(program: &Program, test: &Test) -> Fallible<ProofTree> {
    let (env, TestBoundData { assumptions, goals }) =
        Env::default().instantiate_universally(&test.binder);
    prove_goal(program, &env, assumptions, goals)
}

fn prove_goal(
    program: &Program,
    env: &Env,
    assumptions: impl ToPredicates,
    goal: impl ToPredicates + Debug,
) -> Fallible<ProofTree> {
    let goal: Predicates = goal.to_predicates();
    prove_judgment(
        program,
        env,
        assumptions,
        goal.to_predicates(),
        crate::prove::prove,
    )
}

fn prove_judgment<G>(
    program: &Program,
    env: &Env,
    assumptions: impl ToPredicates,
    goal: G,
    judgment_fn: impl FnOnce(Program, Env, Predicates, G) -> ProvenSet<Constraints>,
) -> Fallible<ProofTree>
where
    G: Debug + Visit + Clone,
{
    let assumptions: Predicates = assumptions.to_predicates();

    assert!(
        env.only_universal_variables(),
        "env contains existential variables `{env:?}`"
    );
    assert!(env.encloses((&assumptions, &goal)));

    let cs = judgment_fn(
        program.clone(),
        env.clone(),
        assumptions.clone(),
        goal.clone(),
    );
    let cs = cs.into_map()?;
    cs.iter()
        .find_map(|(c, proof_tree)| c.unconditionally_true().then_some(proof_tree))
        .cloned()
        .ok_or_else(|| {
            let constraints: Vec<_> = cs.keys().collect();
            anyhow!("failed to prove `{goal:?}` given `{assumptions:?}`: got {constraints:?}")
        })
}

#[tracing::instrument(level = "Debug", skip(program, assumptions, goal))]
fn prove_not_goal(
    program: &Program,
    env: &Env,
    assumptions: impl ToPredicates,
    goal: impl ToPredicates,
) -> Fallible<ProofTree> {
    let goal: Predicates = goal.to_predicates();
    let assumptions: Predicates = assumptions.to_predicates();

    assert!(env.only_universal_variables());
    assert!(env.encloses((&assumptions, &goal)));

    let cs = is_definitely_not_proveable(env, &assumptions, &goal, |env, assumptions, goal| {
        crate::prove::prove(program, env, &assumptions, &goal)
    });
    let cs = cs.into_map()?;
    if let Some((_, proof_tree)) = cs.iter().find(|(c, _)| c.unconditionally_true()) {
        return Ok(proof_tree.clone());
    }

    let constraints: Vec<_> = cs.keys().collect();
    bail!("failed to prove {goal:?} given {assumptions:?}, got {constraints:?}")
}
