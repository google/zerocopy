use crate::grammar::Predicates;
use formality_core::{judgment_fn, Cons};

use crate::prove::{constraints::Constraints, decls::Program, prove_after::prove_after};

use super::{env::Env, prove_predicate::prove_predicate};

judgment_fn! {
    /// Prove that all elements in `goals`, a list of where-clauses, are true, one after the other.
    pub fn prove_predicate_list(
        _decls: Program,
        env: Env,
        assumptions: Predicates,
        goals: Predicates,
    ) => Constraints {
        debug(goals, assumptions, env)

        assert(env.encloses((assumptions, goals)))

        (
            --- ("none")
            (prove_predicate_list(_decls, env, _assumptions, ()) => Constraints::none(env))
        )

        (
            (prove_predicate(decls, env, assumptions, wc0) => c)
            (prove_after(decls, c, assumptions, wcs1) => c)
            --- ("some")
            (prove_predicate_list(decls, env, assumptions, Cons(wc0, wcs1)) => c)
        )
    }
}
