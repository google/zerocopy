use crate::grammar::{
    AliasName, AliasTy, AtomicPredicate, Const, Lt, Parameter, Parameters, Predicates, RigidName,
    RigidTy, Ty, UniversalVar,
};
use formality_core::{judgment_fn, Downcast, ProvenSet, Upcast};

use crate::prove::{combinators::for_all, decls::Program, prove, prove_after::prove_after};

use super::{constraints::Constraints, env::Env};

judgment_fn! {
    pub fn prove_wf(
        _decls: Program,
        env: Env,
        assumptions: Predicates,
        goal: Parameter,
    ) => Constraints {
        debug(goal, assumptions, env)

        assert(env.encloses((assumptions, goal)))

        (
            // Always assume that universal variables are WF. This is debatable, it implies
            // that we ensure by construction that the values we infer for existential variables
            // are WF. An alternative would be to add explicit assumptions into the environment
            // for every universal variable. That just seems tedious.
            --- ("universal variables")
            (prove_wf(_decls, env, _assumptions, UniversalVar { .. }) => Constraints::none(env))
        )

        (
            // `&'a T` is well-formed if `T: 'a`
            (let (lt, ty) = parameters.downcast_err::<(Lt, Ty)>()?)
            (prove_wf_recursive(decls, env, assumptions, ty) => c)
            (prove_after(decls, c, assumptions, AtomicPredicate::outlives(ty, lt)) => c)
            --- ("references")
            (prove_wf(decls, env, assumptions, RigidTy { name: RigidName::Ref(_), parameters }) => c)
        )

        (
            // `*const T`/`*mut T` is well-formed if `T` is.
            (let (ty,) = parameters.downcast_err::<(Ty,)>()?)
            (prove_wf_recursive(decls, env, assumptions, ty) => c)
            --- ("raw-pointers")
            (prove_wf(decls, env, assumptions, RigidTy { name: RigidName::Raw(_), parameters }) => c)
        )

        (
            (for_all(decls, env, assumptions, parameters, &prove_wf_recursive) => c)
            --- ("tuples")
            (prove_wf(decls, env, assumptions, RigidTy { name: RigidName::Tuple(_), parameters }) => c)
        )

        (
            (for_all(decls, env, assumptions, parameters, &prove_wf_recursive) => c)
            --- ("integers and booleans")
            (prove_wf(decls, env, assumptions, RigidTy { name: RigidName::ScalarId(_), parameters }) => c)
        )

        (
            (for_all(decls, env, assumptions, parameters, &prove_wf_recursive) => c)
            (let t = decls.program().adt_item_named(adt_id)?.to_adt())
            (let t = t.binder.instantiate_with(parameters).unwrap())
            (prove_after(decls, c, assumptions, &t.where_clauses) => c)
            --- ("ADT")
            (prove_wf(decls, env, assumptions, RigidTy { name: RigidName::AdtId(adt_id), parameters }) => c)
        )

        (
            --- ("static lifetime")
            (prove_wf(_decls, env, _assumptions, Lt::Static) => Constraints::none(env))
        )

        (
            --- ("scalar constants are always wf")
            (prove_wf(_decls, env, _assumptions, Const::Scalar(_)) => Constraints::none(env))
        )

        (
            (prove_alias_wf(decls, env, assumptions, name, parameters) => c)
            --- ("aliases")
            (prove_wf(decls, env, assumptions, AliasTy { name, parameters }) => c)
        )
    }
}

pub fn prove_alias_wf(
    decls: &Program,
    env: &Env,
    assumptions: &Predicates,
    _name: &AliasName,
    parameters: &Parameters,
) -> ProvenSet<Constraints> {
    // FIXME(#217): verify self type implements trait
    for_all(decls, env, assumptions, parameters, &prove_wf_recursive)
}

pub fn prove_wf_recursive(
    program: impl Upcast<Program>,
    env: impl Upcast<Env>,
    assumptions: impl Upcast<Predicates>,
    param: impl Upcast<Parameter>,
) -> ProvenSet<Constraints> {
    prove(
        program,
        env,
        assumptions,
        AtomicPredicate::well_formed(param),
    )
}
