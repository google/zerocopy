#![cfg(test)]

use crate::rust::{term, try_term};
use formality_macros::test;

use crate::grammar::expr::{Expr, Literal, PlaceExpr};
use crate::grammar::{Crates, Fallible, ScalarId};

#[test]
fn test_parse_rust_like_trait_impl_syntax() {
    let r: Crates = term(
        "[
            crate core {
                impl<A, B> PartialEq<A> for B {

                }
            }
        ]",
    );

    // Note: the for etc are correctly accounted.
    expect_test::expect![[r#"
        Crates {
            crates: [
                Crate {
                    id: core,
                    items: [
                        TraitImpl(
                            TraitImpl {
                                safety: Safe,
                                binder: Binder {
                                    kinds: [
                                        Ty,
                                        Ty,
                                    ],
                                    term: TraitImplBoundData {
                                        trait_id: PartialEq,
                                        self_ty: Variable(
                                            ^ty0_1,
                                        ),
                                        trait_parameters: [
                                            Ty(
                                                Variable(
                                                    ^ty0_0,
                                                ),
                                            ),
                                        ],
                                        where_clauses: [],
                                        impl_items: [],
                                    },
                                },
                            },
                        ),
                    ],
                },
            ],
        }
    "#]]
    .assert_debug_eq(&r);
}

#[test]
fn test_parse_rust_like_trait_syntax() {
    let r: Crates = term(
        "[
            crate core {
                trait Foo<A> where A : Bar<Self> {

                }
            }
        ]",
    );

    // Note: two type parameters, and the 0th one is self:
    expect_test::expect![[r#"
        Crates {
            crates: [
                Crate {
                    id: core,
                    items: [
                        Trait(
                            Trait {
                                safety: Safe,
                                id: Foo,
                                binder: <ty, ty> where ^ty0_1 : Bar <^ty0_0> { },
                            },
                        ),
                    ],
                },
            ],
        }
    "#]]
    .assert_debug_eq(&r);
}

#[test]
fn test_parse_rust_like_struct_syntax() {
    let r: Crates = term(
        "[
            crate core {
                struct Foo<A> {
                    a : A,
                }
            }
        ]",
    );

    expect_test::expect![[r#"
        Crates {
            crates: [
                Crate {
                    id: core,
                    items: [
                        AdtItem(
                            Struct(
                                Struct {
                                    id: Foo,
                                    binder: Binder {
                                        kinds: [
                                            Ty,
                                        ],
                                        term: StructBoundData {
                                            where_clauses: [],
                                            fields: [
                                                Field {
                                                    name: Id(
                                                        a,
                                                    ),
                                                    ty: Variable(
                                                        ^ty0_0,
                                                    ),
                                                },
                                            ],
                                        },
                                    },
                                },
                            ),
                        ),
                    ],
                },
            ],
        }
    "#]]
    .assert_debug_eq(&r);
}

#[test]
fn test_parse_trusted_fn() {
    let r: Crates = term(
        "[
            crate core {
              fn run() -> () {trusted}
            }
        ]",
    );

    expect_test::expect![[r#"
        Crates {
            crates: [
                Crate {
                    id: core,
                    items: [
                        Fn(
                            Fn {
                                id: run,
                                safety: Safe,
                                binder: Binder {
                                    kinds: [],
                                    term: FnBoundData {
                                        input_args: [],
                                        output_ty: RigidTy(
                                            (),
                                        ),
                                        where_clauses: [],
                                        body: FnBody(
                                            TrustedFnBody,
                                        ),
                                    },
                                },
                            },
                        ),
                    ],
                },
            ],
        }
    "#]]
    .assert_debug_eq(&r);
}

#[test]
fn test_parse_fn_without_return_type() {
    // Same as `test_parse_trusted_fn`, but the return type is omitted. The
    // parsed structure is identical `output_ty` defaults to the unit type
    // `()`, exactly as if `-> ()` had been written.
    let r: Crates = term(
        "[
            crate core {
              fn run() {trusted}
            }
        ]",
    );

    expect_test::expect![[r#"
        Crates {
            crates: [
                Crate {
                    id: core,
                    items: [
                        Fn(
                            Fn {
                                id: run,
                                safety: Safe,
                                binder: Binder {
                                    kinds: [],
                                    term: FnBoundData {
                                        input_args: [],
                                        output_ty: RigidTy(
                                            (),
                                        ),
                                        where_clauses: [],
                                        body: FnBody(
                                            TrustedFnBody,
                                        ),
                                    },
                                },
                            },
                        ),
                    ],
                },
            ],
        }
    "#]]
    .assert_debug_eq(&r);
}

#[test]
fn test_parse_fn_rejects_incomplete_return_type() {
    for text in ["fn f() - {}", "fn f() -> {}"] {
        assert!(
            try_term::<crate::grammar::Fn>(text).is_err(),
            "incomplete return type should not default to unit: {text}",
        );
    }
}

#[test]
fn test_place_expr_ambiguity_deref_vs_field() {
    let p: PlaceExpr = term("*p.f");
    expect_test::expect![[r#"
        Deref {
            prefix: Field {
                prefix: Var(
                    p,
                ),
                field_name: Id(
                    f,
                ),
            },
        }
    "#]]
    .assert_debug_eq(&p);
}

#[test]
fn test_place_expr_parens_override() {
    let p: PlaceExpr = term("(*p).f");
    expect_test::expect![[r#"
        Field {
            prefix: Parens(
                Deref {
                    prefix: Var(
                        p,
                    ),
                },
            ),
            field_name: Id(
                f,
            ),
        }
    "#]]
    .assert_debug_eq(&p);
}

#[test]
fn test_place_expr_field_left_associativity() {
    let p: PlaceExpr = term("p.f.g");
    expect_test::expect![[r#"
        Field {
            prefix: Field {
                prefix: Var(
                    p,
                ),
                field_name: Id(
                    f,
                ),
            },
            field_name: Id(
                g,
            ),
        }
    "#]]
    .assert_debug_eq(&p);
}

#[test]
fn test_place_expr_deref_with_field_chain() {
    let p: PlaceExpr = term("*p.f.g");
    expect_test::expect![[r#"
        Deref {
            prefix: Field {
                prefix: Field {
                    prefix: Var(
                        p,
                    ),
                    field_name: Id(
                        f,
                    ),
                },
                field_name: Id(
                    g,
                ),
            },
        }
    "#]]
    .assert_debug_eq(&p);
}

#[test]
fn test_parse_literals() {
    let expr_data: Fallible<Expr> = try_term("0 _ bool");
    assert!(expr_data.is_err());

    let expr_data: Fallible<Expr> = try_term("0_bool");
    assert!(expr_data.is_err());

    let expr_data: Expr = try_term("0_u8").unwrap();
    assert!(matches!(
        expr_data,
        Expr::Literal(Literal {
            value: 0,
            ty: ScalarId::U8
        })
    ));

    // The older syntax still accepts.
    let expr_data: Expr = try_term("0 _ u8").unwrap();
    assert!(matches!(
        expr_data,
        Expr::Literal(Literal {
            value: 0,
            ty: ScalarId::U8
        })
    ));

    let expr_data: Expr = try_term("false").unwrap();
    assert!(matches!(expr_data, Expr::False));

    let expr_data: Expr = try_term("true").unwrap();
    assert!(matches!(expr_data, Expr::True));
}
