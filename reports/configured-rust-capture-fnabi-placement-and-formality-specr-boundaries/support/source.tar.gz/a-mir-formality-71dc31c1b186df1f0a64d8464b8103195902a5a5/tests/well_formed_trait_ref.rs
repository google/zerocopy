use a_mir_formality::{crates, test_program_ok, FormalityTest};

#[test]
fn dependent_where_clause() {
    FormalityTest::new(crates![crate foo {
        trait Trait1 {}

        trait Trait2 {}

        struct S1<T> where T: Trait1 {
            dummy: T,
        }

        struct S2<T> where T: Trait1, S1<T> : Trait2 {
            dummy: T,
        }
    }])
    .skip_execute()
    .ok()
}

#[test]
fn missing_dependent_where_clause() {
    FormalityTest::new(crates![crate foo {
        trait Trait1 {}

        trait Trait2 {}

        struct S1<T> where T: Trait1 {
            dummy: T,
        }

        struct S2<T> where S1<T> : Trait2 {
            dummy: T,
        }
    }])
    .err(expect_test::expect![[r#"
        crates/formality-rust/src/prove/prove_via.rs:8:1: no applicable rules for prove_via { goal: @ WellFormedTraitRef(Trait2(S1<!ty_0>)), via: Trait2(S1<!ty_0>), assumptions: {Trait2(S1<!ty_0>)}, env: Env { variables: [!ty_0], bias: Soundness, pending: [], allow_pending_outlives: false } }

        crates/formality-rust/src/prove/prove_via.rs:8:1: no applicable rules for prove_via { goal: Trait1(!ty_0), via: Trait2(S1<!ty_0>), assumptions: {Trait2(S1<!ty_0>)}, env: Env { variables: [!ty_0], bias: Soundness, pending: [], allow_pending_outlives: false } }

        the rule "trait implied bound" at (prove_predicate.rs) failed because
          expression evaluated to an empty collection: `decls.trait_invariants()`"#]])
}

#[test]
fn lifetime_param() {
    FormalityTest::new(crates![crate foo {
        trait Trait1<'a> {}

        struct S1 {}

        struct S2<'a> where S1: Trait1<'a> {}
    }])
    .skip_execute()
    .ok()
}

#[test]
fn static_lifetime_param() {
    FormalityTest::new(crates![crate foo {
        trait Trait1<'a> {}

        struct S1 {}

        impl Trait1<'static> for S1 {}

        struct S2 where S1: Trait1<'static> {}
    }])
    .skip_execute()
    .ok()
}

#[test]
fn const_param() {
    FormalityTest::new(crates![crate foo {
        trait Trait1<const C> where type_of_const C is u32 {}

        struct S1 {}

        impl Trait1<u32(3)> for S1 {}

        struct S2 where S1: Trait1<u32(3)> {}
    }])
    .skip_execute()
    .ok()
}

#[test]
#[should_panic(expected = "wrong number of parameters")]
fn type_with_wrong_number_of_parameters() {
    let _ = test_program_ok(
        " [
            crate foo {
                trait Trait1 {}

                struct S1 {}

                struct S2<T> where S1<T> : Trait1 {
                    dummy: T,
                }
            }
        ] ",
    )
    .unwrap();
}

#[test]
#[should_panic(expected = "no ADT named `Nonex`")]
fn where_clause_with_nonexistent_type() {
    let _ = test_program_ok(
        " [
            crate foo {
                trait Trait1 {}

                struct S1 where Nonex: Trait1 {}
            }
        ] ",
    )
    .unwrap();
}
