use a_mir_formality::{crates, FormalityTest};
use formality_core::test;

/// Test assign statement with locals at rhs.
#[test]
fn test_assign_statement_local_only() {
    FormalityTest::new(crates![crate Foo {
        fn foo (v1: u32) -> u32 {
            return v1;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

// Test assign statement with constant at rhs.
#[test]
fn test_assign_constant() {
    FormalityTest::new(crates![crate Foo {
        fn foo () -> u8 {
            let v1: u16 = 5_u16;
            let v2: u32 = 5_u32;
            let v3: u64 = 5_u64;
            let v4: usize = 5_usize;
            let v5: i8 = 5_i8;
            let v6: i16 = 5_i16;
            let v7: i32 = 5_i32;
            let v8: i64 = 5_i64;
            let v9: isize = 5_isize;
            let v10: bool = false;
            return 5_u8;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

// Test valid program with Terminator::Switch.
#[test]
#[ignore = "needs switch/branching constructs in expr grammar"]
fn test_switch_statment() {
    FormalityTest::new(crates![crate Foo {
        fn foo () -> u32 = minirust {
            exists {
                let v1: u32;

                bb0: {
                    statements {
                        local(v1) = constant(0: u32);
                    }
                    switch(load(local(v1))) -> [(0: bb1), (1: bb2)] otherwise: bb3;
                }

                bb1: {
                    statements {
                        local(_return) = constant(1: u32);
                    }
                    return;
                }

                bb2: {
                    statements {
                        local(_return) = constant(2: u32);
                    }
                    return;
                }

                bb3: {
                    statements {
                    }
                    return;
                }
            }
        };
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Test returning a parameter (previously tested goto terminator in MIR).
#[test]
fn test_goto_terminator() {
    FormalityTest::new(crates![crate Foo {
        fn foo (v1: u32) -> u32 {
            return v1;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Test cyclic control flow (a loop).
/// A silly but valid infinite loop that reads and writes a variable.
#[test]
fn test_cyclic_goto() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> u32 {
            let v0: u32 = 0_u32;
            loop {
                v0 = v0;
            }
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Returns true (Expr::True) type-checking coverage
#[test]
fn test_ret_true() {
    FormalityTest::new(crates![crate Foo {
        fn foo () -> bool {
            return true;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

// if / else (Stmt::If) bool condition, each arm returns a u32.
#[test]
fn if_else() {
    FormalityTest::new(crates![crate Foo {
        fn foo (b: bool) -> u32 {
            if b {
                return 1_u32;
            } else {
                return 2_u32;
            }
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

// if / else (Stmt::If) with different return types.
#[test]
fn if_else_different_return_types() {
    FormalityTest::new(crates![crate Foo {
        fn foo (b: bool) -> u32 {
            if b {
                return 1_u32;
            } else {
                return false;
            }
        }
    }])
        .rustc_err(expect_test::expect![[r#"
            error[E0308]: mismatched types
             --> lib.rs
              |
            1 | pub fn foo(mut b: bool) -> u32 {
              |                            --- expected `u32` because of return type
            ...
            5 |         return false;
              |                ^^^^^ expected `u32`, found `bool`

            For more information about this error, try `rustc --explain E0308`.
            error: could not compile `Foo` (lib) due to 1 previous error
        "#]])
        .err(expect_test::expect![[r#"
                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: bool, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: u32, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: bool, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: u32, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }"#]])
}

/// Test valid call: bar calls foo.
#[test]
fn test_call_terminator() {
    FormalityTest::new(crates![crate Foo {
        fn foo(v1: u32) -> u32 {
            return v1;
        }

        fn bar(v1: u32) -> u32 {
            let v0: u32 = foo(v1);
            return v0;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Test valid place mention statement.
/// This is equivalent to:
/// ```
///    fn foo(v1: u32) -> u32 {
///      _return;
///      return v1;
///    }
///
/// ```
#[test]
fn test_place_mention_statement() {
    FormalityTest::new(crates![crate Foo {
        fn foo (v1: u32) -> u32 {
            return v1;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Test valid StorageLive and StorageDead statements.
#[test]
#[ignore = "needs StorageLive/StorageDead in expr grammar"]
fn test_storage_live_dead() {
    FormalityTest::new(crates![crate Foo {
        fn foo (v1: u32) -> u32 = minirust {
            exists {
                let v2: u32;

                bb0: {
                    statements {
                        local(_return) = load(local(v1));
                        StorageLive(v2);
                        StorageDead(v2);
                    }
                    return;
                }
            }
        };
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Test valid program that uses struct.
#[test]
fn test_struct() {
    FormalityTest::new(crates![crate Foo {
        struct Dummy {
            value: u32,
            is_true: bool,
        }

        fn foo (v1: u32) -> u32 {
            let v2: Dummy = Dummy { value: 1_u32, is_true: false };
            v2.value = 2_u32;
            return v1;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Test let statement with well-formed type
#[test]
fn test_let_with_well_formed_type() {
    FormalityTest::new(crates![crate Foo {
        trait Trait1 {}
        struct S1<T> {
            t: T,
        }
        fn foo() -> () {
            let s1: S1<u8>;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Test let statement with ill-formed type
#[test]
fn test_let_with_ill_formed_type() {
    FormalityTest::new(crates![crate Foo {
        trait Trait1 {}
        struct S1 {}
        struct S2<T> where T: Trait1 {
            t: T,
        }
        fn foo() -> () {
            let s2: S2<S1>;
        }
    }])
    .rustc_err(expect_test::expect![[r#"
        error[E0277]: the trait bound `S1: Trait1` is not satisfied
          --> lib.rs
           |
        13 |     let mut s2: S2<S1>;
           |                 ^^^^^^ unsatisfied trait bound
           |
        help: the trait `Trait1` is not implemented for `S1`
          --> lib.rs
           |
         3 | pub struct S1 {}
           | ^^^^^^^^^^^^^
        help: this trait has no implementations, consider adding one
          --> lib.rs
           |
         1 | pub trait Trait1 {}
           | ^^^^^^^^^^^^^^^^
        note: required by a bound in `S2`
          --> lib.rs
           |
         5 | pub struct S2<T00>
           |            -- required by a bound in this struct
         6 | where
         7 |     T00: Trait1,
           |          ^^^^^^ required by this bound in `S2`

        For more information about this error, try `rustc --explain E0277`.
        error: could not compile `Foo` (lib) due to 1 previous error
    "#]])
    .err(expect_test::expect![[r#"
                the rule "trait implied bound" at (prove_predicate.rs) failed because
                  expression evaluated to an empty collection: `decls.trait_invariants()`"#]])
}

// Test calling a function that does not exist.
#[test]
fn test_call_invalid_fn() {
    FormalityTest::new(crates![crate Foo {
        fn bar() -> u32 {
            let v1: u32 = foo(0_u32);
            return v1;
        }
    }])
    .rustc_err(expect_test::expect![[r#"
        error[E0425]: cannot find function `foo` in this scope
         --> lib.rs
          |
        2 |     let mut v1: u32 = foo(0_u32);
          |                       ^^^ not found in this scope

        For more information about this error, try `rustc --explain E0425`.
        error: could not compile `Foo` (lib) due to 1 previous error
    "#]])
    .err(expect_test::expect![[r#"
            the rule "fn-name" at (nll.rs) failed because
              no fn named `foo`

            the rule "local" at (nll.rs) failed because
              unknown local variable `foo`"#]])
}

#[test]
// Test what will happen if the type of arguments passed in is not subtype of what is expected.
fn test_pass_non_subtype_arg() {
    FormalityTest::new(crates![crate Foo {
                fn foo(v1: u32) -> u32 {
                    return v1;
                }

                fn bar(v1: ()) -> () {
                    let v0: () = foo(v1);
                    return v0;
                }
            }])
        .rustc_err(expect_test::expect![[r#"
            error[E0308]: mismatched types
             --> lib.rs
              |
            6 |     let mut v0: () = foo(v1);
              |                      --- ^^ expected `u32`, found `()`
              |                      |
              |                      arguments to this function are incorrect
              |
            note: function defined here
             --> lib.rs
              |
            1 | pub fn foo(mut v1: u32) -> u32 {
              |        ^^^ -----------

            error[E0308]: mismatched types
             --> lib.rs
              |
            6 |     let mut v0: () = foo(v1);
              |                 --   ^^^^^^^ expected `()`, found `u32`
              |                 |
              |                 expected due to this

            For more information about this error, try `rustc --explain E0308`.
            error: could not compile `Foo` (lib) due to 2 previous errors
        "#]])
        .err(expect_test::expect![[r#"
                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: (), assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: u32, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: (), assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: u32, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }"#]])
}

/// Test calling a generic function without turbofish (wrong number of type args: 0 vs 1).
#[test]
fn test_call_generic_fn_without_turbofish() {
    FormalityTest::new(crates![crate Foo {
        fn identity<T>(v1: T) -> T {
            return v1;
        }

        fn bar(v1: u32) -> u32 {
            let v0: u32 = identity(v1);
            return v0;
        }
    }])
    .rustc_ok() // rustc can deduce the generic type
    .err(expect_test::expect![[r#"
            the rule "fn-name" at (nll.rs) failed because
              condition evaluated to false: `fn_decl.binder.len() == 0`

            the rule "local" at (nll.rs) failed because
              unknown local variable `identity`"#]])
}

/// Test calling a generic function with correct turbofish.
#[test]
fn test_call_generic_fn_with_turbofish() {
    FormalityTest::new(crates![crate Foo {
        fn identity<T>(v1: T) -> T {
            return v1;
        }

        fn bar(v1: u32) -> u32 {
            let v0: u32 = identity::<u32>(v1);
            return v0;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Test calling a generic function with incorrect turbofish type.
#[test]
fn test_call_generic_fn_wrong_type_with_turbofish() {
    FormalityTest::new(crates![crate Foo {
                fn identity<T>(v1: T) -> T {
                    return v1;
                }

                fn bar(v1: u32) -> u32 {
                    let v0: u32 = identity::<bool>(v1);
                    return v0;
                }
            }])
        .rustc_err(expect_test::expect![[r#"
            error[E0308]: mismatched types
             --> lib.rs
              |
            6 |     let mut v0: u32 = identity::<bool>(v1);
              |                       ---------------- ^^ expected `bool`, found `u32`
              |                       |
              |                       arguments to this function are incorrect
              |
            help: the return type of this call is `u32` due to the type of the argument passed
             --> lib.rs
              |
            6 |     let mut v0: u32 = identity::<bool>(v1);
              |                       ^^^^^^^^^^^^^^^^^--^
              |                                        |
              |                                        this argument influences the return type of `identity`
            note: function defined here
             --> lib.rs
              |
            1 | pub fn identity<T00>(mut v1: T00) -> T00 {
              |        ^^^^^^^^      -----------

            error[E0308]: mismatched types
             --> lib.rs
              |
            6 |     let mut v0: u32 = identity::<bool>(v1);
              |                 ---   ^^^^^^^^^^^^^^^^^^^^ expected `u32`, found `bool`
              |                 |
              |                 expected due to this

            For more information about this error, try `rustc --explain E0308`.
            error: could not compile `Foo` (lib) due to 2 previous errors
        "#]])
        .err(expect_test::expect![[r#"
                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: u32, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: bool, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: u32, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: bool, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }"#]])
}

/// Test calling a generic function using turbofish syntax with an incorrect number of parameters.
#[test]
fn test_call_generic_fn_wrong_parameters_number_with_turbofish() {
    FormalityTest::new(crates![crate Foo {
        fn identity<T>(v1: T) -> T {
            return v1;
        }

        fn bar(v1: u32) -> u32 {
            let v0: u32 = identity::<u32>(v1, v1);
            return v0;
        }
    }])
    .rustc_err(expect_test::expect![[r#"
        error[E0061]: this function takes 1 argument but 2 arguments were supplied
         --> lib.rs
          |
        6 |     let mut v0: u32 = identity::<u32>(v1, v1);
          |                       ^^^^^^^^^^^^^^^     -- unexpected argument #2 of type `u32`
          |
        note: function defined here
         --> lib.rs
          |
        1 | pub fn identity<T00>(mut v1: T00) -> T00 {
          |        ^^^^^^^^
        help: remove the extra argument
          |
        6 -     let mut v0: u32 = identity::<u32>(v1, v1);
        6 +     let mut v0: u32 = identity::<u32>(v1);
          |

        For more information about this error, try `rustc --explain E0061`.
        error: could not compile `Foo` (lib) due to 1 previous error
    "#]])
    .err(expect_test::expect![[r#"
            the rule "call" at (nll.rs) failed because
              condition evaluated to false: `input_tys.len() == args.len()`"#]])
}

/// Test calling a generic function with wrong number of type args via turbofish.
#[test]
fn test_call_generic_fn_wrong_arity() {
    FormalityTest::new(crates![crate Foo {
        fn identity<T>(v1: T) -> T {
            return v1;
        }

        fn bar(v1: u32) -> u32 {
            let v0: u32 = identity::<u32, u32>(v1);
            return v0;
        }
    }])
    .rustc_err(expect_test::expect![[r#"
        error[E0107]: function takes 1 generic argument but 2 generic arguments were supplied
         --> lib.rs
          |
        6 |     let mut v0: u32 = identity::<u32, u32>(v1);
          |                       ^^^^^^^^      ----- help: remove the unnecessary generic argument
          |                       |
          |                       expected 1 generic argument
          |
        note: function defined here, with 1 generic parameter: `T00`
         --> lib.rs
          |
        1 | pub fn identity<T00>(mut v1: T00) -> T00 {
          |        ^^^^^^^^ ---

        For more information about this error, try `rustc --explain E0107`.
        error: could not compile `Foo` (lib) due to 1 previous error
    "#]])
    .err(expect_test::expect![[r#"
            the rule "turbofish" at (nll.rs) failed because
              condition evaluated to false: `fn_decl.binder.len() == args.len()`"#]])
}

/// Test what will happen if the declared and actual return type are not compatible.
/// This is equivalent to:
/// ```
/// fn foo(v1: ()) -> u32 {
///     let v0: ();
///     v0 = v1;
///     return v0;
/// }
/// ```
#[test]
fn test_incompatible_return_type() {
    FormalityTest::new(crates![crate Foo {
                fn foo (v1: ()) -> u32 {
                    return v1;
                }
            }])
        .rustc_err(expect_test::expect![[r#"
            error[E0308]: mismatched types
             --> lib.rs
              |
            1 | pub fn foo(mut v1: ()) -> u32 {
              |                           --- expected `u32` because of return type
            2 |     return v1;
              |            ^^ expected `u32`, found `()`

            For more information about this error, try `rustc --explain E0308`.
            error: could not compile `Foo` (lib) due to 1 previous error
        "#]])
        .err(expect_test::expect![[r#"
                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: (), assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: u32, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: (), assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: u32, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }"#]])
}

// Test the behaviour of having unitialised return local variable.
// FIXME(#209, #296): This test should fail but currently passes due to removed return place initialization check
#[test]
#[ignore = "needs uninitialized return detection in expr grammar"]
fn test_uninitialised_return_type() {
    FormalityTest::new(crates![crate Foo {
        fn foo () -> u32 = minirust {
            exists {
                bb0: {
                    statements {
                    }
                    return;
                }
            }
        };
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Test switch terminator with invalid type in Terminator::Switch.
#[test]
#[ignore = "needs switch/branching constructs in expr grammar"]
fn test_invalid_value_in_switch_terminator() {
    FormalityTest::new(crates![crate Foo {
        fn foo () -> bool = minirust {
            exists {
                bb0: {
                    statements {
                        local(_return) = constant(false);
                    }
                    switch(load(local(_return))) -> [(0: bb1), (1: bb2)] otherwise: bb3;
                }

                bb1: {
                    statements {
                    }
                    return;
                }

                bb2: {
                    statements {
                    }
                    return;
                }

                bb3: {
                    statements {
                    }
                    return;
                }
            }
        };
    }])
    .rustc_err(expect_test::expect![[r#""#]])
    .err(expect_test::expect![[r#"
            MaybeFnBody expected

            Caused by:
                0: = minirust
                       {
                           exists
                           {
                               bb0:
                               {
                                   statements { local(_return) = constant(false); }
                                   switch(load(local(_return))) -> [(0: bb1), (1: bb2)]
                                   otherwise: bb3;
                               } bb1: { statements {} return; } bb2: { statements {} return; }
                               bb3: { statements {} return; }
                           }
                       };
                   }]
                1: failed to parse [crate Foo
                   {
                       fn foo() -> bool = minirust
                       {
                           exists
                           {
                               bb0:
                               {
                                   statements { local(_return) = constant(false); }
                                   switch(load(local(_return))) -> [(0: bb1), (1: bb2)]
                                   otherwise: bb3;
                               } bb1: { statements {} return; } bb2: { statements {} return; }
                               bb3: { statements {} return; }
                           }
                       };
                   }]"#]])
}

/// Test the behaviour of having return place in StorageDead.
#[test]
#[ignore = "needs StorageDead in expr grammar"]
fn test_ret_place_storage_dead() {
    FormalityTest::new(crates![crate Foo {
        fn foo (v1: u32) -> u32 = minirust {
            exists {
                bb0: {
                    statements {
                        StorageDead(v1);
                    }
                    return;
                }
            }
        };
    }])
    .rustc_err(expect_test::expect![[r#""#]])
    .err(expect_test::expect![[r#"
            MaybeFnBody expected

            Caused by:
                0: = minirust
                       { exists { bb0: { statements { StorageDead(v1); } return; } } };
                   }]
                1: failed to parse [crate Foo
                   {
                       fn foo(v1: u32) -> u32 = minirust
                       { exists { bb0: { statements { StorageDead(v1); } return; } } };
                   }]"#]])
}

/// Test the behaviour of having function argument in StorageDead.
#[test]
#[ignore = "needs StorageDead in expr grammar"]
fn test_fn_arg_storage_dead() {
    FormalityTest::new(crates![crate Foo {
        fn foo (v1: u32) -> u32 = minirust {
            exists {
                bb0: {
                    statements {
                        StorageDead(_return);
                    }
                    return;
                }
            }
        };
    }])
    .rustc_err(expect_test::expect![[r#""#]])
    .err(expect_test::expect![[r#"
            MaybeFnBody expected

            Caused by:
                0: = minirust
                       { exists { bb0: { statements { StorageDead(_return); } return; } } };
                   }]
                1: failed to parse [crate Foo
                   {
                       fn foo(v1: u32) -> u32 = minirust
                       { exists { bb0: { statements { StorageDead(_return); } return; } } };
                   }]"#]])
}

/// Test the behaviour of using invalid field name for the struct field.
#[test]
fn test_invalid_struct_field() {
    FormalityTest::new(crates![crate Foo {
        struct Dummy {
            value: u32,
        }

        fn foo (v1: u32) -> u32 {
            let v2: Dummy = Dummy { value: 1_u32 };
            v2.nonexistent = 2_u32;
            return v1;
        }
    }])
    .rustc_err(expect_test::expect![[r#"
        error[E0609]: no field `nonexistent` on type `Dummy`
         --> lib.rs
          |
        7 |     v2.nonexistent = 2_u32;
          |        ^^^^^^^^^^^ unknown field
          |
          = note: available field is: `value`

        For more information about this error, try `rustc --explain E0609`.
        error: could not compile `Foo` (lib) due to 1 previous error
    "#]])
    .err(expect_test::expect![[r#"
            the rule "struct field" at (nll.rs) failed because
              condition evaluated to false: `field.name == *field_name`"#]])
}

/// Test the behaviour of using non-adt local for field projection.
#[test]
fn test_field_projection_root_non_adt() {
    FormalityTest::new(crates![crate Foo {
                struct Dummy {
                    value: u32,
                }

                fn foo (v1: u32) -> u32 {
                    let v2: Dummy = Dummy { value: 1_u32 };
                    v1.value = 2_u32;
                    return v1;
                }
            }])
        .rustc_err(expect_test::expect![[r#"
            error[E0610]: `u32` is a primitive type and therefore doesn't have fields
             --> lib.rs
              |
            7 |     v1.value = 2_u32;
              |        ^^^^^

            For more information about this error, try `rustc --explain E0610`.
            error: could not compile `Foo` (lib) due to 1 previous error
        "#]])
        .err(expect_test::expect![[r#"
                the rule "struct field" at (nll.rs) failed because
                  pattern `(RigidTy { name: RigidName::AdtId(adt_id), parameters }, state)` did not match value `(u32, flow_state([scope(none, None, {}, None, [(v1, u32)], [v1 : u32]), scope(none, None, {}, None, [(v2, Dummy)], [v2 : Dummy])], point_flow_state({}, {}, {}), {}, {}, {}))`"#]])
}

/// Test the behaviour of initialising the struct with wrong type.
#[test]
fn test_struct_wrong_type_in_initialisation() {
    FormalityTest::new(crates![crate Foo {
                struct Dummy {
                    value: u32,
                }

                fn foo (v1: u32) -> u32 {
                    let v2: Dummy = Dummy { value: false };
                    return v1;
                }
            }])
        .rustc_err(expect_test::expect![[r#"
            error[E0308]: mismatched types
             --> lib.rs
              |
            6 |     let mut v2: Dummy = Dummy { value: false };
              |                                        ^^^^^ expected `u32`, found `bool`

            For more information about this error, try `rustc --explain E0308`.
            error: could not compile `Foo` (lib) due to 1 previous error
        "#]])
        .err(expect_test::expect![[r#"
                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: bool, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }

                crates/formality-rust/src/prove/prove_normalize.rs:21:1: no applicable rules for prove_normalize { p: u32, assumptions: {}, env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: true } }"#]])
}

/// Test the behaviour of having non-adt as the type for struct construction.
/// In the new expr syntax, using a scalar type name as a struct constructor
/// would be a parse error since AdtId and ScalarId are distinct.
/// We keep the intent of the test by using a made-up ADT name that doesn't exist.
#[test]
fn test_non_adt_ty_for_struct() {
    FormalityTest::new(crates![crate Foo {
        fn foo (v1: u32) -> u32 {
            let v2: u32 = Nonexistent { value: false };
            return v1;
        }
    }])
    .rustc_err(expect_test::expect![[r#"
        error[E0422]: cannot find struct, variant or union type `Nonexistent` in this scope
         --> lib.rs
          |
        2 |     let mut v2: u32 = Nonexistent { value: false };
          |                       ^^^^^^^^^^^ not found in this scope

        For more information about this error, try `rustc --explain E0422`.
        error: could not compile `Foo` (lib) due to 1 previous error
    "#]])
    .err(expect_test::expect![[r#"
            the rule "struct" at (nll.rs) failed because
              no ADT named `Nonexistent`"#]])
}

/// Test that the `false` literal type-checks as `bool`.
///
/// ```rust,ignore
/// fn foo() -> bool {
///     let v1: bool = false;
///     return v1;
/// }
/// ```
#[test]
fn test_false_literal() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> bool {
            let v1: bool = false;
            return v1;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Basic pass test for lifetime.
///
/// The test is equivalent to:
/// ```rust,ignore
/// fn pick<'a>(v1: &'a u32) -> &'a u32 {
///     let v2 = v1;
///     v2
/// }
/// ```
#[test]
fn test_ref_identity() {
    FormalityTest::new(crates![crate Foo {
        fn foo<'a>(v1: &'a u32) -> &'a u32 {
            exists<'r0> {
                let v2: &'r0 u32 = v1;
                return v2;
            }
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Test ref and deref
#[test]
fn test_ref_deref() {
    FormalityTest::new(crates![crate Foo {
        fn foo () -> u32 {
            exists<'a> {
                let v0: u32 = 0_u32;
                let v1: &'a u32 = &'a v0;
                let v2: u32 = *v1;
                return v2;
            }
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// Test generic deref should be permitted when the pointee type is known Copy.
#[test]
fn test_ref_deref_generic_copy_bound() {
    FormalityTest::new(crates![crate Foo {
        fn foo<'a, T>(v1: &'a T) -> T
        where
            T: Copy,
            T: 'a,
        {
            exists<'r0> {
                let v2: T = *v1;
                return v2;
            }
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

// ---- Scoping tests ----

/// `break` targeting a valid loop label should pass.
///
/// ```rust
/// fn foo() -> u32 {
///     'a: loop {
///         break 'a;
///     }
///     return 0;
/// }
/// ```
#[test]
fn test_break_valid_loop_label() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> u32 {
            'a: loop {
                break 'a;
            }
            return 0_u32;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// `break` targeting a non-existent label should fail.
///
/// ```rust
/// fn foo() -> u32 {
///     loop {
///         break 'nonexistent; // error: no such label
///     }
/// }
/// ```
#[test]
fn test_break_nonexistent_label() {
    FormalityTest::new(crates![crate Foo {
                fn foo() -> u32 {
                    loop {
                        break 'nonexistent;
                    }
                    return 0_u32;
                }
            }])
        .rustc_err(expect_test::expect![[r#"
            error[E0426]: use of undeclared label `'nonexistent`
             --> lib.rs
              |
            3 |         break 'nonexistent;
              |               ^^^^^^^^^^^^ undeclared label `'nonexistent`

            For more information about this error, try `rustc --explain E0426`.
            error: could not compile `Foo` (lib) due to 1 previous error
        "#]])
        .err(expect_test::expect![[r#"
                crates/formality-rust/src/check/borrow_check/nll.rs:177:1: no applicable rules for borrow_check_statement { state: flow_state([scope(none, None, {}, None, [], []), scope(none, None, {}, None, [], []), scope(none, None, {}, Some({}), [], []), scope(none, None, {}, None, [], [])], point_flow_state({}, {}, {}), {}, {}, {}), statement: break 'nonexistent ;, places_live_on_exit: {}, assumptions: {}, env: TypeckEnv { env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: false }, output_ty: Some(u32) } }

                crates/formality-rust/src/check/borrow_check/nll.rs:177:1: no applicable rules for borrow_check_statement { state: flow_state([scope(none, None, {}, None, [], []), scope(none, None, {}, None, [], []), scope(none, None, {}, Some({}), [], []), scope(none, None, {}, None, [], [])], point_flow_state({}, {}, {}), {}, {}, {}), statement: break 'nonexistent ;, places_live_on_exit: {}, assumptions: {}, env: TypeckEnv { env: Env { variables: [], bias: Soundness, pending: [], allow_pending_outlives: false }, output_ty: Some(u32) } }"#]])
}

/// `continue` targeting a valid loop label should pass.
///
/// ```rust
/// fn foo() {
///     'a: loop {
///         continue 'a;
///     }
/// }
/// ```
#[test]
fn test_continue_valid_loop_label() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> u32 {
            'a: loop {
                continue 'a;
            }
            return 0_u32;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// `continue` targeting a block (not a loop) should fail.
///
/// ```rust,compile_fail
/// fn foo() -> u32 {
///     'a: {
///         continue 'a; // error: can only continue loops
///     }
///     0
/// }
/// ```
#[test]
fn test_continue_block_label() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> u32 {
            'a: {
                continue 'a;
            }
            return 0_u32;
        }
    }])
    .rustc_err(expect_test::expect![[r#"
        error[E0696]: `continue` pointing to a labeled block
         --> lib.rs
          |
        2 | /     'a: {
        3 | |         continue 'a;
          | |         ^^^^^^^^^^^ labeled blocks cannot be `continue`'d
        4 | |     }
          | |_____- labeled block the `continue` points to

        For more information about this error, try `rustc --explain E0696`.
        error: could not compile `Foo` (lib) due to 1 previous error
    "#]])
    .err(expect_test::expect![[r#"
            the rule "continue" at (nll.rs) failed because
              pattern `Some(places_live_on_continue)` did not match value `None`"#]])
}

/// Test parenthesized place expression: `(*v).field`.
///
/// The parens around `*v1` are required so the deref applies before
/// the field projection (without them, `*v1.value` would try to
/// project first and then deref).
///
/// ```rust,ignore
/// fn foo(v1: &Pair) -> u32 {
///     let v2: u32 = (*v1).value;
///     v2
/// }
/// ```
#[test]
fn test_parens_place_expr() {
    FormalityTest::new(crates![crate Foo {
        struct Pair {
            value: u32,
        }

        fn foo<'a>(v1: &'a Pair) -> u32 {
            exists<'r0> {
                let v2: u32 = (*v1).value;
                return v2;
            }
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// `break` targeting a block label (not a loop) should pass.
/// In Rust, you can `break` out of a labeled block.
///
/// ```rust
/// fn foo() -> u32 {
///     'a: {
///         break 'a;
///     }
///     0
/// }
/// ```
#[test]
fn test_break_block_label() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> u32 {
            'a: {
                break 'a;
            }
            return 0_u32;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}
