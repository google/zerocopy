use a_mir_formality::{crates, FormalityTest};

/// Tests for issue #209: ensuring functions return a value on all paths.
///
/// These tests verify that a-mir-formality matches rustc's behavior
/// for return validation. All error cases have been verified against
/// rustc to ensure we accept a correct subset of Rust.

/// A function that declares a return type of u32 but has an empty body
/// should be an error — no value is returned.
/// rustc: "implicitly returns `()` as its body has no tail or `return` expression"
#[test]
#[ignore = "needs return validation (#209)"]
fn empty_body_non_unit_return() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> u32 {
        }
    }])
    .rustc_err(expect_test::expect![[r#""#]])
    .err(expect_test::expect![[r#"function may not return a value"#]])
}

/// A function returning () with an empty body is fine — unit is implicit.
/// rustc: compiles with no error
#[test]
fn empty_body_unit_return() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> () {
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// If/else where both branches return — all paths return, so this is fine.
/// rustc: compiles with no error
#[test]
fn if_else_both_branches_return() {
    FormalityTest::new(crates![crate Foo {
        fn foo(b: bool) -> u32 {
            if b {
                return 1_u32;
            } else {
                return 2_u32;
            }
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// If/else where only one branch returns — the other path falls through
/// without returning, so this should be an error.
/// rustc: "expected `u32`, found `()`"
#[test]
#[ignore = "needs return validation (#209)"]
fn if_else_one_branch_returns() {
    FormalityTest::new(crates![crate Foo {
        fn foo(b: bool) -> u32 {
            if b {
                return 1_u32;
            } else {
            }
        }
    }])
    .rustc_err(expect_test::expect![[r#""#]])
    .err(expect_test::expect![[r#"function may not return a value"#]])
}

/// An infinite loop never terminates, so it never needs to return.
/// rustc: compiles with no error (loop {} has type !)
#[test]
fn infinite_loop_no_return_needed() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> u32 {
            loop {
            }
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// A loop with break exits the loop, but then there's no return after it.
/// This should be an error.
/// rustc: "expected `u32`, found `()`"
#[test]
#[ignore = "needs return validation (#209)"]
fn loop_with_break_no_return() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> u32 {
            'a: loop {
                break 'a;
            }
        }
    }])
    .rustc_err(expect_test::expect![[r#""#]])
    .err(expect_test::expect![[r#"function may not return a value"#]])
}

/// A loop with break followed by a return is fine — all paths return.
/// rustc: compiles with no error
#[test]
fn loop_with_break_then_return() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> u32 {
            'a: loop {
                break 'a;
            }
            return 0_u32;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}

/// A simple function that returns a value on all paths.
/// rustc: compiles with no error
#[test]
fn simple_return() {
    FormalityTest::new(crates![crate Foo {
        fn foo() -> u32 {
            return 42_u32;
        }
    }])
    .skip_execute()
    .rustc_ok()
    .ok()
}
