import sys,json,subprocess,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
check=sys.argv[2];module=sys.argv[3];assert check in ['01','02','03'];assert module in ['ByteBinding','ByteBindingAudit','ByteDiagnostic']
freeze=json.loads((root.parent/'sail-runtime/integration-build-freeze.json').read_text())
x={'check':check,'module':module,'source':(root/sys.argv[1]).read_text(),'artifacts':freeze['artifacts'],'prior':sys.argv[4] if len(sys.argv)>4 else None}
remote=r'''
import sys,json,subprocess,time,resource,hashlib,os,shutil
from pathlib import Path
x=json.load(sys.stdin);base=Path('/home/opam/anneal-sail-output/byte-binding-development')
if x['check']=='01':base.mkdir(exist_ok=False)
else:
 if not base.is_dir():raise RuntimeError('missing owned root')
results=[json.loads(p.read_text()) for p in base.glob('check-*/result.json')]
if len(results)>=3:raise RuntimeError('check cap')
used=sum(p['seconds'] for p in results)
if used>=300:raise RuntimeError('native time cap')
root=base/('check-'+x['check']);root.mkdir(exist_ok=False)
lean=Path('/home/opam/anneal-sail-tools/lean-4.29.0-linux_aarch64/bin/lean')
imports=Path('/home/opam/anneal-sail-output/serial-build-integration')
proof=Path('/home/opam/anneal-sail-output/proof-development/check-05')
expected=[(lean,'e215cbe9eab0914b49761e9e486d388e2e701cf876d1079d1ba733c48edb2d7b',None),
(proof/'Proof.lean','f62057489d30152c39dcfab87c5b7ecbb43dd2e6bbe14d0368c4cbc832b6f2d4',3744),
(proof/'Proof.olean','a37ef2b0d8f2ed3613a85ae666e89771464e2453df0929f9f80fb44397faa3bf',297080)]
if len(x['artifacts'])!=143:raise RuntimeError('wrong import manifest count')
expected += [(imports/q['path'],q['sha256'],q['bytes']) for q in x['artifacts']]
controls=Path('/home/opam/anneal-sail-output/controls-parent-1')
if x['module']=='ByteDiagnostic':
 expected += [(controls/'Controls.lean','7c9301d8c6080cd8cd1cf1a4ae356532b92de8378e416fd7ed48f35945d5635b',9930),(controls/'Controls.olean','b2fbb76b44f7eb0ad57ca724d959a62dc0ddd7594df0db0a4b26b129fe9aa0b7',254400)]
pre=[]
for p,h,n in expected:
 b=p.read_bytes();actual=hashlib.sha256(b).hexdigest()
 pre.append({'path':str(p),'bytes':len(b),'sha256':actual,'ok':actual==h and (n is None or len(b)==n)})
 if not pre[-1]['ok']:
  (root/'preflight.json').write_text(json.dumps(pre,indent=2));raise RuntimeError('identity mismatch '+str(p))
(root/'preflight.json').write_text(json.dumps(pre,indent=2)+'\n')
for name in ['Proof.lean','Proof.olean']:shutil.copyfile(proof/name,root/name)
if x['module']=='ByteDiagnostic':
 for name in ['Controls.lean','Controls.olean']:shutil.copyfile(controls/name,root/name)
if x['prior']:
 prior=base/x['prior']
 for name in ['ByteBinding.lean','ByteBinding.olean']:shutil.copyfile(prior/name,root/name)
src=root/(x['module']+'.lean');src.write_text(x['source'])
argv=['timeout','--signal=TERM','--kill-after=5',str(min(120,max(1,int(300-used)))),str(lean),'-j1','-M4500','--tstack=400000','-t0','-R',str(root),'-o',str(root/(x['module']+'.olean')),str(src)]
env=dict(os.environ);env['LEAN_PATH']=str(imports/'olean')+':'+str(root);env['LEAN_NUM_THREADS']='1'
start=time.monotonic()
with (root/'stdout').open('wb') as out,(root/'stderr').open('wb') as err:ret=subprocess.run(argv,env=env,stdout=out,stderr=err)
r={'status':ret.returncode,'seconds':time.monotonic()-start,'maxrss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'argv':argv,'lean_path':env['LEAN_PATH'],'preflight_count':len(pre),'preflight_all_ok':all(p['ok'] for p in pre),'files':{}}
for p in sorted(root.iterdir()):
 if p.is_file():
  b=p.read_bytes();r['files'][p.name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(root/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'result':r,'preflight':pre,'stdout':(root/'stdout').read_text(),'stderr':(root/'stderr').read_text()}))
'''
r=subprocess.run(['docker','exec','-i','0af066858d96349334304f51ea631ea4c2496694952ea17f7dca1b5e8ecf6715','python3','-c',remote],input=json.dumps(x),text=True,capture_output=True)
(root/('byte-check-'+check+'-driver.stderr')).write_text(r.stderr)
(root/('byte-check-'+check+'.json')).write_text(r.stdout)
if r.returncode:print('driver failed',r.returncode,r.stderr);sys.exit(r.returncode)
j=json.loads(r.stdout)
for k in ['stdout','stderr']:(root/f'byte-check-{check}.{k}').write_text(j[k])
(root/f'byte-check-{check}-result.json').write_text(json.dumps(j['result'],indent=2)+'\n')
print(json.dumps(j['result'],indent=2));print(j['stdout'][:8000]);print(j['stderr'])
