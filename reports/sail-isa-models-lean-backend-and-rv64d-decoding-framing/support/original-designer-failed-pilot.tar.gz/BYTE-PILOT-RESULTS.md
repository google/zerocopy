# Bounded byte pilot: source boundary identified, proof still incomplete

**No ByteBinding or ByteDiagnostic module was accepted.** The three-check grant is exhausted, with no further native check performed. The checked AST Proof/Controls artifacts and the frozen generated/support/import/tool subject remain unchanged. This pilot is incomplete and must not be counted as a decoded-instruction or checked-counterexample result.

All three invocations used the exact official Lean binary with -t0, -j1, -M4500, --tstack=400000, a 120-second timeout and explicit LEAN_PATH containing only the 143 completed imports plus the create-only owned check directory. The initial preflight independently verified 143 olean sizes/hashes against integration-build-freeze, compiler SHA256, accepted Proof source and artifact. The two diagnostic checks additionally verified accepted Controls source/artifact before making owned copies. Every identity matched: 146 entries for check 01 and 148 for each diagnostic check. No native failure was panic/assertion/invariant, timeout or OOM; all were ordinary elaboration/conversion failures. Total measured native wall time was 4.186358652 seconds, below the five-minute cap.

| Check | Input | Status | Seconds | Peak RSS KiB | Observed outcome |
| --- | --- | --- | --- | --- | --- |
|01|Exact original ByteBinding.lean|1|1.217379872|1,536,600|Three decoder-to-pure rfl equalities fail|
|02|ByteDiagnostic-v1.lean|1|1.487878672|1,543,228|Existential continuation placeholder cannot be synthesized|
|03|ByteDiagnostic-v2.lean|1|1.481100108|1,545,424|Prefix equality still not accepted by rfl in Exists.intro|

## Source-backed boundary

The original next-pilot proposal assumed that decoding 0x002081b3 into ADD would be a pure computation on the word. Actual generated InstsEnd.lean:350ff evaluates currentlyEnabled(Ext_Zicfilp) **before** testing that guard's nonmatching opcode. PlatformConfig.lean:6067–6069 implements that enabled check using a cur_privilege read and get_xLPE. get_xLPE:6208ff reads privilege-dependent CSR state, including mseccfg in Machine mode. The selected fixed configuration supports Zicfilp and the preceding Zihintpause/Zicsr checks. These reads cannot be erased merely because the ADD word does not match LPAD.

This source explains why x1/x2-only AST premises cannot simply be carried into a success claim for actual decode→execute. A future theorem must account for decoder effects, their missing-register error cases and any necessary privilege/CSR presence premises. That is an explicit additional semantic domain, not an optimization to the accepted AST theorem.

## Exact remaining proof obligation

The parent narrowed the last two checks to a diagnostic preserving the actual encoder/decoder/executor. Its intended central lemma is:

```
∃ k : Privilege → SailM instruction,
  Functions.ext_decode (0x002081b3 : BitVec 32) =
  FreeM.impure (read cur_privilege effect) k
```

The real fully typed effect appears in ByteDiagnostic-v2.lean; the display above is explanatory. Check 03's exact residual is that rfl cannot establish this equation when constructing the existential witness. The downstream generic missing-privilege error lemmas, accepted-fixture counterexample and not-pure claim all depend on that unaccepted lemma. They therefore remain unproved here. The full stdout prints diagnostic sorryAx closures; those are not accepted theorem results.

A likely further proof-development step is to inspect the actual propositional equations for generated mutual currentlyEnabled/get_xLPE, whose termination hints implement well-founded recursion. Their source bodies support the proposed effect prefix, but kernel conversion need not unfold well-founded calls by rfl. This is a hypothesis explaining the remaining conversion failure, not a newly observed accepted proof. No equation names or tactics were guessed into another native attempt after the cap.

Encoder and closed byte-layout declarations produced no separate diagnostics in failed files. Because no file completed, this report claims no accepted encoder artifact or theorem package either. There were no separate false-claim native probes and no accepted semantic counterexample to the original domain. The original stronger candidate and all failed inputs remain preserved rather than silently weakened.

## Retained evidence

- Original source: ByteBinding.lean, SHA256 `25cec5df60fb024d87765d58461b0b3bacec34b6d73a9f598fd10f6d53fff57e`.
- Diagnostic v1 source: ByteDiagnostic-v1.lean, SHA256 `3239568ae73f8d34ccf2d4e24ec7bab60e16f4c1ed23e49e860771e89b7df23e`.
- Diagnostic v2 source: ByteDiagnostic-v2.lean, SHA256 `9641c31e3f0372f72ec8d591df45e2dd7cda18cc605a3a02e2a4fc94371b01d5`.
- byte-check-01/02/03.json preserve complete result, preflight, stdout and stderr; separate .stdout/.stderr/-result.json/-preflight.json files make inspection direct. Exact source, copied accepted inputs, logs and receipts also remain in the three create-only remote byte-binding-development/check directories.
- BYTE-CHECK-01-DIAGNOSIS.md preserves the first source diagnosis. BYTE-PILOT-RESULTS.json consolidates status, timings, arguments, identities and artifact absence. run-byte-check-v1.py and run-byte-check.py preserve the initial and Controls-aware driver versions.

No accepted artifact was available to copy locally. No report or previously accepted source/artifact was rewritten to imply byte-pilot success. Parent can independently review this bounded failure and decide the next source/proof goal; there is no request for automatic resource or repair escalation.
