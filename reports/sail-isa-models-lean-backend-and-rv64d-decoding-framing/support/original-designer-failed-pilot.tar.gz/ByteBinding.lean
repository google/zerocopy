/- SOURCE-ONLY NEXT-PILOT CANDIDATE: never compiled or executed by its author.
   Retains full actual model/Proof imports. No replacement ISA or decoder.
   Positive decoder equations must check before any rejection claim is made. -/
import LeanRV64D
import Proof

open Sail.ArchSem LeanRV64D

namespace AnnealSail.ByteBinding

set_option maxHeartbeats 10000000
set_option maxRecDepth 10000

/-- Explicit low-address-first bytes b3 81 20 00 correspond to this word.
    This bitvector equality is not a memory/fetch theorem. -/
theorem selected_little_endian_word :
    (((0x00 : BitVec 8).append (0x20 : BitVec 8)).append
      (0x81 : BitVec 8)).append (0xb3 : BitVec 8) =
    (0x002081b3 : BitVec 32) := by
  decide

/-- Actual generated encoder for the selected register ADD. -/
theorem encode_add :
    Functions.encdec_forwards
      (instruction.RTYPE
        (regidx.Regidx 2, regidx.Regidx 1, regidx.Regidx 3, rop.ADD)) =
    (FreeM.pure (0x002081b3 : BitVec 32) : SailM (BitVec 32)) := by
  rfl

/-- Actual generated decoder, including its preceding branch checks. -/
theorem encdec_add :
    Functions.encdec_backwards (0x002081b3 : BitVec 32) =
    (FreeM.pure
      (instruction.RTYPE
        (regidx.Regidx 2, regidx.Regidx 1, regidx.Regidx 3, rop.ADD)) :
      SailM instruction) := by
  rfl

/-- Actual extension decoder wrapper, rather than a newly defined decoder. -/
theorem decode_add :
    Functions.ext_decode (0x002081b3 : BitVec 32) =
    (FreeM.pure
      (instruction.RTYPE
        (regidx.Regidx 2, regidx.Regidx 1, regidx.Regidx 3, rop.ADD)) :
      SailM instruction) := by
  exact encdec_add

/-- Preserve the checked universal state claim when the actual decoded word
    supplies the instruction. This still starts after instruction fetching. -/
theorem decode_then_execute_add
    (a b : BitVec 64) (s : SequentialState RegisterType)
    (h1 : s.regs.get? Register.x1 = some a)
    (h2 : s.regs.get? Register.x2 = some b) :
    (interpretSailEffects
      (show SailM ExecutionResult from do
        let inst ← Functions.ext_decode (0x002081b3 : BitVec 32)
        Functions.execute inst)).run s =
    EStateM.Result.ok (ExecutionResult.Retire_Success ())
      {s with regs := s.regs.insert Register.x3 (a + b)} := by
  rw [decode_add]
  change (interpretSailEffects
    (Functions.execute
      (instruction.RTYPE
        (regidx.Regidx 2, regidx.Regidx 1, regidx.Regidx 3, rop.ADD)))).run s = _
  exact AnnealSail.execute_add_full_state a b s h1 h2

/-- Destination mutant: rd4 word, bytes 33 82 20 00. -/
theorem decode_rd4 :
    Functions.ext_decode (0x00208233 : BitVec 32) =
    (FreeM.pure
      (instruction.RTYPE
        (regidx.Regidx 2, regidx.Regidx 1, regidx.Regidx 4, rop.ADD)) :
      SailM instruction) := by
  rfl

/-- Opcode bits change 0x33 to 0x13, giving ADDI x3,x1,2.
    Other relevant word bits are unchanged; bytes 93 81 20 00. -/
theorem decode_changed_opcode :
    Functions.ext_decode (0x00208193 : BitVec 32) =
    (FreeM.pure
      (instruction.ITYPE
        ((2 : BitVec 12), regidx.Regidx 1, regidx.Regidx 3, iop.ADDI)) :
      SailM instruction) := by
  rfl

/-- The changed destination cannot satisfy the selected ADD decode equation. -/
theorem rd4_is_not_selected_add :
    Functions.ext_decode (0x00208233 : BitVec 32) ≠
    (FreeM.pure
      (instruction.RTYPE
        (regidx.Regidx 2, regidx.Regidx 1, regidx.Regidx 3, rop.ADD)) :
      SailM instruction) := by
  rw [decode_rd4]
  intro h
  have hi := FreeM.pure.inj h
  have hd : (4 : BitVec 5) = (3 : BitVec 5) :=
    congrArg (fun inst : instruction =>
      match inst with
      | .RTYPE (_, _, .Regidx rd, _) => rd
      | _ => (0 : BitVec 5)) hi
  exact (by decide : (4 : BitVec 5) ≠ (3 : BitVec 5)) hd

/-- The changed opcode cannot satisfy the selected ADD decode equation. -/
theorem changed_opcode_is_not_selected_add :
    Functions.ext_decode (0x00208193 : BitVec 32) ≠
    (FreeM.pure
      (instruction.RTYPE
        (regidx.Regidx 2, regidx.Regidx 1, regidx.Regidx 3, rop.ADD)) :
      SailM instruction) := by
  rw [decode_changed_opcode]
  intro h
  have hi := FreeM.pure.inj h
  cases hi

#print encode_add
#print axioms encode_add
#print encdec_add
#print axioms encdec_add
#print decode_then_execute_add
#print axioms decode_then_execute_add
#print axioms decode_rd4
#print axioms decode_changed_opcode
#print axioms rd4_is_not_selected_add
#print axioms changed_opcode_is_not_selected_add

end AnnealSail.ByteBinding
