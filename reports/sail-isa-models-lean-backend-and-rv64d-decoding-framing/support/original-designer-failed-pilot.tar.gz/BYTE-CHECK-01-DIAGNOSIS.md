# First byte-binding check: actual decoder reads privilege state

The exact original ByteBinding.lean candidate was checked once with official pinned Lean 4.29.0, -t0, -j1, -M4500, --tstack=400000 and 120-second timeout. It rejected normally (status 1) in 1.217379872 seconds, peak RSS 1,536,600 KiB. There was no panic/assertion/invariant, timeout or OOM. No ByteBinding.olean was produced. All 143 completed import artifacts, compiler hash and accepted Proof source/artifact independently passed preflight (146 identities). Complete receipts/streams/source hashes are in byte-check-01.json and byte-check-01-result.json, with separate stdout/stderr files.

Three decoder-to-FreeM.pure equalities failed rfl: original ADD word 0x002081b3, rd4 word 0x00208233 and opcode-mutant word 0x00208193. This is not an observed counterexample theorem, but source inspection explains why a pure decoder theorem is not appropriate for this full model. Generated InstsEnd.lean:350ff tries the PAUSE/LPAD guards before ordinary ADD/ADDI:

```
if ((← currentlyEnabled Ext_Zihintpause) && word == PAUSE_bits) then ...
else if ((← currentlyEnabled Ext_Zicfilp) && extract_low_bits word == LPAD_opcode) then ...
else ...
```

The monadic guard calls occur before the nonmatching bit tests. Generated PlatformConfig.lean:6067–6069 currentlyEnabled(Zicfilp) reads cur_privilege and calls get_xLPE, regardless of the unrelated word's opcode. get_xLPE:6208ff reads privilege-dependent CSR state: Machine→mseccfg, Supervisor→menvcfg, User→extension/S/envcfg state, virtual modes→read_henvcfg/read_senvcfg. hartSupports(Zicfilp), Zicsr and Zihintpause are true in the selected fixed config (PlatformConfig:1266ff), so this is not a disabled platform feature removed by constant propagation. The generated free computation therefore contains real register effects even when the LPAD bit comparison is false. The actual sequential interpreter may reject on missing privilege/CSR entries before reaching ADD.

Consequences:

- The candidate's encdec_add/decode_rd4/decode_changed_opcode free-program equality to pure is not merely missing an annotation. Dropping those effects would be a different decoder.
- The original accepted AST theorem deliberately needs only x1/x2 presence. A decoder-then-execute success theorem on precisely that domain cannot be assumed: decoder state dependencies must be represented.
- A potential next scoped theorem would retain the exact decoder effect prefix and quantify arbitrary values for its required entries. A Machine-privilege specialization needs at least cur_privilege=Machine and a present arbitrary mseccfg value, in addition to source operands for execution. That would be a newly explicit domain, requiring parent agreement before a changed claim/check.
- An alternative all-state statement can retain actual decoder failure/success cases, rather than silently assert success on missing decoder state. This too changes the proposed statement and should be selected explicitly.

The encoder and closed byte-layout theorem did not report errors in this rejected file; that is not an accepted module/artifact result. All dependent decoded/composed/negative constants printed in this failed file are diagnostics, not accepted proofs; their sorryAx must not be treated as a successful closure. No false-claim native probe ran. Accepted AST Proof/Controls and all model/support/import/tool bytes remain unchanged.

Two of the three allocated checks remain. Native checks are paused pending parent selection of the actual decoder domain/effect statement; no automatic repair, new premises, reduced decoder or model mutation is authorized by this diagnosis.
