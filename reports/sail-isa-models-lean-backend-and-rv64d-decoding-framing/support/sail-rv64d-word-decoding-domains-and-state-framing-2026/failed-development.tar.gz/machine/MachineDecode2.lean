/- UNCOMPILED source-only candidate. No native grant for this file.
   It proposes a new, explicitly stronger positive domain. The accepted
   x1/x2-only-domain refutation remains unchanged in ByteDiagnostic5. -/
import LeanRV64D
import Proof
import ByteDiagnostic5

open Sail.ArchSem LeanRV64D

namespace AnnealSail.MachineDecode

set_option maxHeartbeats 10000000
set_option maxRecDepth 10000

theorem machine_lpe_reads_seccfg :
    Functions.get_xLPE Privilege.Machine =
    (show SailM Bool from do
      let csr ← readReg Register.mseccfg
      pure (Functions.bool_bit_backwards (Functions._get_Seccfg_MLPE csr))) := by
  rw [Functions.get_xLPE.eq_def]

theorem decoder_machine_effects :
    ∃ k : Privilege → SailM instruction,
      Functions.ext_decode (0x002081b3 : BitVec 32) =
        FreeM.impure
          (.inl (.ok (@InstructionEffect.regRead (inferInstance : Arch)
            Register.cur_privilege none))) k ∧
      k Privilege.Machine =
        (show SailM instruction from do
          let _ ← readReg Register.mseccfg
          pure (instruction.RTYPE
            (regidx.Regidx 2, regidx.Regidx 1, regidx.Regidx 3, rop.ADD))) := by
  unfold Functions.ext_decode Functions.encdec_backwards
  rw [ByteDiagnostic.enabled_pause, ByteDiagnostic.enabled_cfilp]
  refine ⟨?_, ?_, ?_⟩
  case refine_2 => rfl
  case refine_3 =>
    change (show SailM instruction from do
      let lpe ← Functions.get_xLPE Privilege.Machine
      if lpe && false then pure (instruction.LPAD 520)
      else pure (instruction.RTYPE
        (regidx.Regidx 2, regidx.Regidx 1, regidx.Regidx 3, rop.ADD))) = _
    rw [machine_lpe_reads_seccfg]
    simp [FreeM.bind, Bind.bind, Pure.pure, readReg]

#check decoder_machine_effects
#print axioms decoder_machine_effects
#check machine_lpe_reads_seccfg
#print axioms machine_lpe_reads_seccfg

end AnnealSail.MachineDecode
