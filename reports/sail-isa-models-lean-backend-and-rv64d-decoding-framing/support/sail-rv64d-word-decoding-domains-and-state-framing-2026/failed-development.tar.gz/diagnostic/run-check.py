from pathlib import Path
import subprocess,json,hashlib,sys
host=Path(__file__).resolve().parent
name=sys.argv[1]
assert name.endswith('.lean') and '/' not in name
source=(host/name).read_bytes()
script=r'''
from pathlib import Path
import os,subprocess,time,resource,json,hashlib,shutil
root=Path('/home/opam/anneal-sail-output/byte-diagnostic-proof')
name=NAME
data=bytes.fromhex(DATA)
assert hashlib.sha256(data).hexdigest()==HASH
lean=Path('/home/opam/anneal-sail-tools/lean-4.29.0-linux_aarch64/bin/lean')
assert hashlib.sha256(lean.read_bytes()).hexdigest()=='e215cbe9eab0914b49761e9e486d388e2e701cf876d1079d1ba733c48edb2d7b'
if name=='Inspect.lean':
    build=Path('/home/opam/anneal-sail-output/serial-build-integration')
    recs=json.loads((build/'results.json').read_text())
    complete=json.loads((build/'complete.json').read_text())
    assert len(recs)==143 and complete['status']==0 and complete['modules']==143
    for row in recs:
        p=build/'olean'/Path(*row['module'].split('.')).with_suffix('.olean')
        assert row['status']==0 and p.stat().st_size==row['olean_bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['olean_sha256']
    root.mkdir()
    copied=[]
    for parent,f,h in [('independent-proof','Proof.lean','f62057489d30152c39dcfab87c5b7ecbb43dd2e6bbe14d0368c4cbc832b6f2d4'),('independent-proof','Proof.olean','a37ef2b0d8f2ed3613a85ae666e89771464e2453df0929f9f80fb44397faa3bf'),('independent-controls-v4','Controls.lean','7c9301d8c6080cd8cd1cf1a4ae356532b92de8378e416fd7ed48f35945d5635b'),('independent-controls-v4','Controls.olean','b2fbb76b44f7eb0ad57ca724d959a62dc0ddd7594df0db0a4b26b129fe9aa0b7')]:
        p=Path('/home/opam/anneal-sail-output')/parent/f
        assert hashlib.sha256(p.read_bytes()).hexdigest()==h
        shutil.copyfile(p,root/f);copied.append({'file':f,'sha256':h})
    (root/'identity.json').write_text(json.dumps({'compiler_sha256':hashlib.sha256(lean.read_bytes()).hexdigest(),'verified_imports':recs,'copied_inputs':copied},indent=2)+'\n')
with (root/name).open('xb') as f:f.write(data)
stem=Path(name).stem
argv=['timeout','--signal=TERM','--kill-after=5','120',str(lean),'-j1','-M4500','--tstack=400000','-t0','-R',str(root),'-o',str(root/(stem+'.olean')),str(root/name)]
env=os.environ.copy();env['LEAN_PATH']='/home/opam/anneal-sail-output/serial-build-integration/olean:'+str(root);env['LEAN_NUM_THREADS']='1'
t=time.monotonic()
with (root/(stem+'.stdout')).open('xb') as so,(root/(stem+'.stderr')).open('xb') as se:
    result=subprocess.run(argv,cwd=root,env=env,stdout=so,stderr=se)
u=resource.getrusage(resource.RUSAGE_CHILDREN)
files={}
for f in [name,stem+'.olean',stem+'.stdout',stem+'.stderr']:
    p=root/f
    if p.exists():files[f]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
rec={'argv':argv,'cwd':str(root),'lean_path':env['LEAN_PATH'],'status':result.returncode,'seconds':time.monotonic()-t,'maxrss_kib':u.ru_maxrss,'user_seconds':u.ru_utime,'system_seconds':u.ru_stime,'files':files}
(root/(stem+'-check.json')).write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps({'result':rec,'stdout':(root/(stem+'.stdout')).read_text(),'stderr':(root/(stem+'.stderr')).read_text()}))
'''.replace('NAME',repr(name)).replace('DATA',repr(source.hex())).replace('HASH',repr(hashlib.sha256(source).hexdigest()))
r=subprocess.run(['docker','exec','0af066858d96349334304f51ea631ea4c2496694952ea17f7dca1b5e8ecf6715','python3','-c',script],capture_output=True,text=True)
(host/(Path(name).stem+'-native.json')).write_text(r.stdout)
(host/(Path(name).stem+'-docker.stderr')).write_text(r.stderr)
print('docker_status',r.returncode)
if r.returncode==0:
    d=json.loads(r.stdout)
    (host/(Path(name).stem+'.stdout')).write_text(d['stdout'])
    (host/(Path(name).stem+'.stderr')).write_text(d['stderr'])
    print(json.dumps(d['result'],indent=2))
    lines=d['stdout'].splitlines()
    for i,line in enumerate(lines):
        if ': error' in line:print('\n'.join(lines[i:i+18]))
else:print(r.stderr)
