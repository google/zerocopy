import LeanRV64D
import Proof
import Controls
open Sail.ArchSem LeanRV64D
#check Functions.currentlyEnabled.eq_def
#check Functions.get_xLPE.eq_def
#print Functions.ext_decode
#print Functions.currentlyEnabled.eq_def
#print Functions.get_xLPE.eq_def
